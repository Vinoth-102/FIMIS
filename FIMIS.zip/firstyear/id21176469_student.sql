-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 28, 2023 at 11:27 AM
-- Server version: 10.5.20-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id21176469_student`
--

-- --------------------------------------------------------

--
-- Table structure for table `automobilecy3151`
--

CREATE TABLE `automobilecy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `automobilege3151`
--

CREATE TABLE `automobilege3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `automobilege3152`
--

CREATE TABLE `automobilege3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `automobilehs3152`
--

CREATE TABLE `automobilehs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `automobilema3151`
--

CREATE TABLE `automobilema3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `automobileph3151`
--

CREATE TABLE `automobileph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `biotechcy3151`
--

CREATE TABLE `biotechcy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `biotechge3151`
--

CREATE TABLE `biotechge3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `biotechge3151`
--

INSERT INTO `biotechge3151` (`regno`, `name`, `ge3151_mark`, `ge3151_attendance`) VALUES
(810023214001, 'PREM PRADHYUSH B A', '67', 15),
(810023214002, 'ABISHEK S', '92', 18),
(810023214003, 'NATRAJ R', '75', 18),
(810023214004, 'PRIYADHARSHINI P', '89', 17),
(810023214005, 'SURYASELVAN E', '81', 17),
(810023214006, 'RAYAN AFRIN S', '97', 18),
(810023214007, 'PRIYADHARSHINI B', '86', 17),
(810023214008, 'VENKATESHWARI S', '86', 18),
(810023214009, 'KAMALIKA M', '83', 18),
(810023214010, 'AAQIF ALI N R', '79', 15),
(810023214011, 'PREETHI JESSICA K', '93', 17),
(810023214013, 'DHANUJA SRI N', '76', 16),
(810023214014, 'SRIDHAR M', '70', 18),
(810023214015, 'GOPIKRISHNAN A', '94', 18),
(810023214016, 'MOURIYA J', '91', 18),
(810023214017, 'GUNA S', '78', 17),
(810023214018, 'ARUNADEVI R', '73', 17),
(810023214019, 'LOGESHWARI P', '85', 18),
(810023214020, 'NAVEEN KARTHIKEYAN R', '79', 16),
(810023214021, 'MATHIVATHANI U', '72', 15),
(810023214022, 'MADHUSRI V', '90', 18),
(810023214023, 'SANKARIYYA S', '82', 17),
(810023214024, 'KIRUBASANKARI J', '84', 18),
(810023214025, 'PRIYADHARSHINI A', '86', 16),
(810023214026, 'SUBIKSHA J', '85', 17),
(810023214027, 'FLORENCE HINRIKA B', '82', 17),
(810023214028, 'DHANUSH J U', '86', 18),
(810023214029, 'SOWMIYA S', '85', 16),
(810023214030, 'ABIRAMI S', '86', 18),
(810023214031, 'SANCHITHA R S', '88', 18),
(810023214032, 'HEMA SHALINI S', '87', 18),
(810023214033, 'PRIYADHARSHINI V', '77', 18),
(810023214034, 'DHARANI M', '81', 18),
(810023214035, 'MAHESHWARAN S', '71', 16),
(810023214036, 'DIVAHAR S', '87', 17),
(810023214037, 'DHANYA M', '77', 18),
(810023214038, 'JASMINE SHARMILA S', '75', 17),
(810023214039, 'NANDHINI S', '86', 16),
(810023214040, 'BAVATHARANI S', '80', 17),
(810023214041, 'SHREYA B', '85', 18),
(810023214042, 'SHILVIYA R', '89', 14),
(810023214043, 'LOGESHWARAN K', '83', 17),
(810023214044, 'DARWIN NAAKENDIRAN D', '87', 18),
(810023214045, 'SARANYAESHWARI S', '88', 17),
(810023214046, 'ABARNA P S', '83', 16),
(810023214047, 'KEERTHIKA R', '79', 17),
(810023214048, 'DEEPIKA T', '78', 18),
(810023214049, 'GLADSON RAJ I', '81', 16),
(810023214050, 'MAHABUNISHA M', '97', 18),
(810023214051, 'JANANI S', '89', 18),
(810023214053, 'SELVAKUMAR S', '75', 18),
(810023214054, 'SURUTHI M', '78', 17);

-- --------------------------------------------------------

--
-- Table structure for table `biotechge3152`
--

CREATE TABLE `biotechge3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `biotechhs3152`
--

CREATE TABLE `biotechhs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `biotechhs3152`
--

INSERT INTO `biotechhs3152` (`regno`, `name`, `hs3152_mark`, `hs3152_attendance`) VALUES
(810023214001, 'PREM PRADHYUSH B A', '84', 20),
(810023214002, 'ABISHEK S', '86', 23),
(810023214003, 'NATRAJ R', '87', 21),
(810023214004, 'PRIYADHARSHINI P', '87', 22),
(810023214005, 'SURYASELVAN E', '94', 21),
(810023214006, 'RAYAN AFRIN S', '86', 22),
(810023214007, 'PRIYADHARSHINI B', '88', 22),
(810023214008, 'VENKATESHWARI S', '89', 23),
(810023214009, 'KAMALIKA M', '90', 23),
(810023214010, 'AAQIF ALI N R', '88', 18),
(810023214011, 'PREETHI JESSICA K', '91', 23),
(810023214013, 'DHANUJA SRI N', '78', 22),
(810023214014, 'SRIDHAR M', '70', 22),
(810023214015, 'GOPIKRISHNAN A', '79', 22),
(810023214016, 'MOURIYA J', '88', 22),
(810023214017, 'GUNA S', '68', 19),
(810023214018, 'ARUNADEVI R', '67', 21),
(810023214019, 'LOGESHWARI P', '78', 22),
(810023214020, 'NAVEEN KARTHIKEYAN R', '84', 19),
(810023214021, 'MATHIVATHANI U', '73', 19),
(810023214022, 'MADHUSRI V', '86', 23),
(810023214023, 'SANKARIYYA S', '84', 21),
(810023214024, 'KIRUBASANKARI J', '78', 22),
(810023214025, 'PRIYADHARSHINI A', '79', 21),
(810023214026, 'SUBIKSHA J', '83', 22),
(810023214027, 'FLORENCE HINRIKA B', '90', 20),
(810023214028, 'DHANUSH J U', '92', 23),
(810023214029, 'SOWMIYA S', '79', 21),
(810023214030, 'ABIRAMI S', '75', 23),
(810023214031, 'SANCHITHA R S', '86', 23),
(810023214032, 'HEMA SHALINI S', '87', 22),
(810023214033, 'PRIYADHARSHINI V', '91', 23),
(810023214034, 'DHARANI M', '89', 22),
(810023214035, 'MAHESHWARAN S', '89', 21),
(810023214036, 'DIVAHAR S', '84', 23),
(810023214037, 'DHANYA M', '75', 22),
(810023214038, 'JASMINE SHARMILA S', '55', 18),
(810023214039, 'NANDHINI S', '91', 22),
(810023214040, 'BAVATHARANI S', '88', 22),
(810023214041, 'SHREYA B', '84', 23),
(810023214042, 'SHILVIYA R', '90', 21),
(810023214043, 'LOGESHWARAN K', '86', 20),
(810023214044, 'DARWIN NAAKENDIRAN D', '91', 22),
(810023214045, 'SARANYAESHWARI S', '81', 22),
(810023214046, 'ABARNA P S', '88', 21),
(810023214047, 'KEERTHIKA R', '60', 20),
(810023214048, 'DEEPIKA T', '85', 22),
(810023214049, 'GLADSON RAJ I', '91', 20),
(810023214050, 'MAHABUNISHA M', '86', 22),
(810023214051, 'JANANI S', '84', 21),
(810023214053, 'SELVAKUMAR S', '74', 21),
(810023214054, 'SURUTHI M', '78', 19);

-- --------------------------------------------------------

--
-- Table structure for table `biotechma3151`
--

CREATE TABLE `biotechma3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `biotechph3151`
--

CREATE TABLE `biotechph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilacy3151`
--

CREATE TABLE `civilacy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilage3151`
--

CREATE TABLE `civilage3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilage3152`
--

CREATE TABLE `civilage3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilahs3152`
--

CREATE TABLE `civilahs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilama3151`
--

CREATE TABLE `civilama3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilaph3151`
--

CREATE TABLE `civilaph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `civilaph3151`
--

INSERT INTO `civilaph3151` (`regno`, `name`, `ph3151_mark`, `ph3151_attendance`) VALUES
(810023103001, 'JEEVA N', '24', 25),
(810023103002, 'JAYASHREE N', '63 ', 26),
(810023103003, 'NADHIYA T', '76 ', 29),
(810023103004, 'YUVASHREE G', '80 ', 26),
(810023103005, 'KAVIRAJAN K', '33', 21),
(810023103006, 'RAGUL KANTH B', '59', 25),
(810023103007, 'ABARNA A', '91', 28),
(810023103008, 'BALAJI S', '73', 25),
(810023103010, 'SIVABALAN G', '62', 25),
(810023103011, 'KRITHIKRAJAN P', '59', 26),
(810023103012, 'SHAHITHYA R', '88', 28),
(810023103013, 'ARUL K', '45', 26),
(810023103014, 'PARKAVI B', '42', 25),
(810023103015, 'RITHICK P M', '69', 27),
(810023103016, 'SRINESH S', '65', 27),
(810023103017, 'SIVASANKARI V', '56', 25),
(810023103018, 'ASWATHI G', '66', 27),
(810023103019, 'HARINI M', '81', 27),
(810023103020, 'NISHA A', '78', 25),
(810023103021, 'PRADEEP N', '69', 22),
(810023103022, 'RAJKUMAR S I', '47', 26),
(810023103023, 'MONISHA S', '59', 29),
(810023103024, 'RAMKUMAR R', '40', 28),
(810023103025, 'HARISH R', '58', 29),
(810023103026, 'MATHAN KUMAR A', '63', 28),
(810023103027, 'SURYA DHARSHINI M', '82', 29),
(810023103028, 'KABILAN S', '53', 25),
(810023103029, 'KEERTHANA K', '58', 27),
(810023103030, 'KESAVAKUMARI S', '27', 18),
(810023103031, 'LOKESHWARAN V B', '44', 25),
(810023103032, 'ABHISHEK R', '52', 29),
(810023103033, 'DHARANI S', '42', 27),
(810023103034, 'NITHINARVINTH A', '61', 26),
(810023103035, 'BHARANIDHARAN V', '54', 26),
(810023103036, 'NEELAVANNAN R', '53', 26),
(810023103037, 'NISHANTH S', '56', 29),
(810023103038, 'ARUN P', '71', 29),
(810023103039, 'KALIVIGNESH G', '27', 26),
(810023103040, 'MOHAMED HALITH A', '53', 26),
(810023103041, 'ABDUL KALAM A', '39', 29),
(810023103042, 'BHARATHI R K', '36', 28),
(810023103043, 'JAGADESAN T', '52', 24),
(810023103044, 'NITHIYASRI M', '78', 29),
(810023103045, 'ABINAYA R', '64', 28),
(810023103046, 'HAARINI S', '67', 26),
(810023103047, 'SRIRAM NATTAR P', '57', 29),
(810023103048, 'YOGESHWARAN V', '71', 25),
(810023103049, 'VAISHNAVI T', '75', 27),
(810023103050, 'KAMALNATH A', '63', 28),
(810023103051, 'VIMAL KUMAR M', '41', 25),
(810023103053, 'SRUTHI A', '53', 27),
(810023103054, 'PRITHIKA R T', '79', 29),
(810023103055, 'AJAY SUNDAR A', '49', 24);

-- --------------------------------------------------------

--
-- Table structure for table `civilbcy3151`
--

CREATE TABLE `civilbcy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilbge3152`
--

CREATE TABLE `civilbge3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilbhs3152`
--

CREATE TABLE `civilbhs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilbma3151`
--

CREATE TABLE `civilbma3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `civilbma3151`
--

INSERT INTO `civilbma3151` (`regno`, `name`, `ma3151_mark`, `ma3151_attendance`) VALUES
(810023103056, 'KARTHICK S', '65', 22),
(810023103057, 'GANGA K', '80', 24),
(810023103058, 'SHAMUNDESHWARI T', '88', 26),
(810023103059, 'DHANUSHA S', '68', 24),
(810023103060, 'ARTHI S', '69', 27),
(810023103061, 'DHIVYA DHARSHINI G', '65', 19),
(810023103062, 'HARIHARAN N', '65', 25),
(810023103063, 'ROHINI G K', '81', 22),
(810023103064, 'DHEJESH KUMAR P', '70', 23),
(810023103065, 'SUNITHA K', '64', 22),
(810023103066, 'LINGESH KUMAR', '65', 24),
(810023103067, 'MOHAMED ANIF S', '65', 18),
(810023103068, 'LATCHATHAN T', '63', 20),
(810023103069, 'THILAK S', '65', 22),
(810023103070, 'AARTHI K', '65', 26),
(810023103071, 'SASIKUMAR S', '63', 26),
(810023103072, 'ABDUL AJEES M', '65', 24),
(810023103073, 'BANU SRI VARTHANI V', '85', 24),
(810023103074, 'SANTHOSH M', '63', 24),
(810023103075, 'AATHISESAN S', '63', 19),
(810023103076, 'ANBUMANI M', '65', 23),
(810023103077, 'PRIYADHARSHINI M', '75', 23),
(810023103078, 'KODESHWARI M', '79', 26),
(810023103079, 'APOORVA N', '77', 26),
(810023103080, 'SHANMUGA PRIYA K', '69', 25),
(810023103082, 'JANANISRI G', '65', 24),
(810023103083, 'SAMINATHAN M', '68', 26),
(810023103084, 'PRAVEEN S', '63', 27),
(810023103085, 'JEEVA M', '63', 27),
(810023103086, 'YUVARAJ R', '65', 24),
(810023103087, 'PRASANYA D', '75', 30),
(810023103088, 'YUGANIKHI G', '78', 20),
(810023103089, 'MARIA AKASH A', '65', 24),
(810023103090, 'RESHIKA V', '68', 26),
(810023103091, 'NIRANJAN S', '63', 21),
(810023103092, 'GOKUL S', '65', 26),
(810023103093, 'VINOTHA R', '75', 25),
(810023103094, 'BALAMURUGAN S', '64', 19),
(810023103095, 'HARIHARAN A', '65', 24),
(810023103096, 'VINOCHAN M', '63', 26),
(810023103097, 'AZHARUDEEN R', '65', 27),
(810023103098, 'JEYAKISHORE S S', '64', 18),
(810023103099, 'AYYAPPAN S', '64', 24),
(810023103100, 'BASKAR A', '65', 26),
(810023103101, 'KATHIRAVAN K', '63', 25),
(810023103102, 'KAVIPRIYA R', '78', 20),
(810023103103, 'PRAVINRAJ D', '63', 27),
(810023103104, 'VASANTH A', '64', 24),
(810023103105, 'PRIYA V', '78', 26);

-- --------------------------------------------------------

--
-- Table structure for table `civilbph3151`
--

CREATE TABLE `civilbph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `civilbph3151`
--

INSERT INTO `civilbph3151` (`regno`, `name`, `ph3151_mark`, `ph3151_attendance`) VALUES
(810023103056, 'KARTHICK S', '49', 19),
(810023103057, 'GANGA K', '78', 23),
(810023103058, 'SHAMUNDESHWARI T', '67', 24),
(810023103059, 'DHANUSHA S', '57', 21),
(810023103060, 'ARTHI S', '53', 24),
(810023103061, 'DHIVYA DHARSHINI G', '46', 15),
(810023103062, 'HARIHARAN N', '37', 20),
(810023103063, 'ROHINI G K', '54', 21),
(810023103064, 'DHEJESH KUMAR P', '49', 22),
(810023103065, 'SUNITHA K', '50', 20),
(810023103066, 'LINGESH KUMAR', '55', 23),
(810023103067, 'MOHAMED ANIF S', '57', 20),
(810023103068, 'LATCHATHAN T', '43', 18),
(810023103069, 'THILAK S', '57', 22),
(810023103070, 'AARTHI K', '63', 23),
(810023103071, 'SASIKUMAR S', '69', 21),
(810023103072, 'ABDUL AJEES M', '55', 24),
(810023103073, 'BANU SRI VARTHANI V', '51', 23),
(810023103074, 'SANTHOSH M', '37', 23),
(810023103075, 'AATHISESAN S', '19', 17),
(810023103076, 'ANBUMANI M', '25', 23),
(810023103077, 'PRIYADHARSHINI M', '36', 21),
(810023103078, 'KODESHWARI M', '55', 23),
(810023103079, 'APOORVA N', '49', 20),
(810023103080, 'SHANMUGA PRIYA K', '51', 26),
(810023103082, 'JANANISRI G', '41', 19),
(810023103083, 'SAMINATHAN M', '46', 24),
(810023103084, 'PRAVEEN S', '43', 24),
(810023103085, 'JEEVA M', '41', 24),
(810023103086, 'YUVARAJ R', '52', 23),
(810023103087, 'PRASANYA D', '59', 26),
(810023103088, 'YUGANIKHI G', '64', 21),
(810023103089, 'MARIA AKASH A', '40', 19),
(810023103090, 'RESHIKA V', '51', 20),
(810023103091, 'NIRANJAN S', '51', 17),
(810023103092, 'GOKUL S', '50', 23),
(810023103093, 'VINOTHA R', '31', 22),
(810023103094, 'BALAMURUGAN S', '18', 17),
(810023103095, 'HARIHARAN A', '37', 21),
(810023103096, 'VINOCHAN M', '43', 23),
(810023103097, 'AZHARUDEEN R', '35', 25),
(810023103098, 'JEYAKISHORE S S', '23', 16),
(810023103099, 'AYYAPPAN S', '53', 22),
(810023103100, 'BASKAR A', '33', 22),
(810023103101, 'KATHIRAVAN K', '50', 24),
(810023103102, 'KAVIPRIYA R', '48', 21),
(810023103103, 'PRAVINRAJ D', '30', 24),
(810023103104, 'VASANTH A', '31', 23),
(810023103105, 'PRIYA V', '62', 21);

-- --------------------------------------------------------

--
-- Table structure for table `civilmechanicaltmcy3151`
--

CREATE TABLE `civilmechanicaltmcy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilmechanicaltmge3151`
--

CREATE TABLE `civilmechanicaltmge3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilmechanicaltmge3152`
--

CREATE TABLE `civilmechanicaltmge3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilmechanicaltmhs3152`
--

CREATE TABLE `civilmechanicaltmhs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `civilmechanicaltmma3151`
--

CREATE TABLE `civilmechanicaltmma3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `civilmechanicaltmma3151`
--

INSERT INTO `civilmechanicaltmma3151` (`regno`, `name`, `ma3151_mark`, `ma3151_attendance`) VALUES
(810023126001, 'TAMILSELVAN M', '57', 34),
(810023126002, 'MUTHULAKSHMI G', '84', 34),
(810023126003, 'NANDHINI K', '85', 34),
(810023126004, 'SRIPRIYA B', '94', 34),
(810023126005, 'KIRUTHIGA S', '95', 34),
(810023126006, 'DINESH P', '71', 34),
(810023126007, 'KAVI ARASU C', '78', 34),
(810023126008, 'SARANYA S', '100', 34),
(810023126009, 'JANANI K', '67', 27),
(810023126010, 'RUBASRI M', '80', 34),
(810023126011, 'MADHUMITHA S', '57', 34),
(810023126012, 'GANGANADHI P', '91', 32),
(810023126013, 'SUVETHA V', '97', 34),
(810023126014, 'ABIRAMI A', '71', 32),
(810023126015, 'GOWTHAM V', '88', 34),
(810023126017, 'KRISHNAVENI R', '66', 33),
(810023126018, 'KARTHIKEYAN S', '40', 26),
(810023126019, 'BUVANESH C', '57', 34),
(810023126020, 'PATHMAVATHI L', '57', 34),
(810023126021, 'MOHANA DEVI S', '81', 28),
(810023126022, 'DHANUSHRAJAN K', '70', 31),
(810023126023, 'PRADEEP V', '53', 31),
(810023126024, 'AARTHY K', '98', 33),
(810023126025, 'SELVAPRIYA P', '90', 34),
(810023126026, 'PRABHA P', '100', 34),
(810023126027, 'THIRUPATHI N', '64', 31),
(810023126028, 'PRAVEENKUMAR S', '54', 34),
(810023126029, 'AAKASH P', '52', 34),
(810023126030, 'ABIRAMI B', '73', 29),
(810023126031, 'HEMALATHA P', '57', 34),
(810023126032, 'GUNA R', '48', 34),
(810023126033, 'SHARUKHAN M', '44', 33),
(810023126034, 'MATHIBALAN P', '68', 34),
(810023126036, 'AJAY N', '66', 34),
(810023126037, 'NAVEEN KUMAR S', '52', 34),
(810023126038, 'PACHAIYAPPAN P', '49', 34),
(810023126039, 'DHARNISH K', '48', 34),
(810023126040, 'KANSHIYA S', '65', 34),
(810023126041, 'KAVITHASAN M', '57', 31),
(810023126042, 'SHARMILI M', '56', 31),
(810023126043, 'VANISRI R', '54', 34),
(810023126044, 'YOGESH J', '47', 32),
(810023126045, 'PRAVEEN KUMAR M', '52', 34),
(810023126046, 'KIRAN SANKAR R', '53', 34),
(810023126047, 'ABINAYA A', '70', 34),
(810023126048, 'HARISH R V', '54', 34),
(810023126049, 'ADHITHYA A', '55', 34),
(810023127001, 'AMUDHAN S', '42', 32),
(810023127002, 'SEVVELJAYAM S', '52', 22),
(810023127003, 'ANDAVAR K', '00', 0),
(810023127004, 'ASHWIN G', '47', 32),
(810023127005, 'NAWINKUMAAR V', '42', 34),
(810023127006, 'XAVIER AKASH A', '43', 32),
(810023127007, 'KAVEENA M', '58', 34),
(810023127008, 'NAVEEN S', '56', 29),
(810023127009, 'BALAKRISHNAN R', '47', 32),
(810023127010, 'MOHAN PANDI D', '49', 32),
(810023127011, 'DHANARANGAN R', '42', 20),
(810023127012, 'SAKTHIVEL P', '46', 34),
(810023127013, 'PUNITH S', '44', 30),
(810023127014, 'SRIDHAR T', '00', 0),
(810023127015, 'VENKATARAJ V', '55', 32),
(810023127016, 'SHAMEER AKTHAR S', '40', 31),
(810023127017, 'GOWSHIKKUMAR S', '67', 41);

-- --------------------------------------------------------

--
-- Table structure for table `civilmechanicaltmph3151`
--

CREATE TABLE `civilmechanicaltmph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cseacy3151`
--

CREATE TABLE `cseacy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cseacy3151`
--

INSERT INTO `cseacy3151` (`regno`, `name`, `cy3151_mark`, `cy3151_attendance`) VALUES
(810023104001, 'DARSNA S', '84', 22),
(810023104002, 'CHARLIN ASHINI A D', '92', 24),
(810023104003, 'SRINIDHI K', '75', 17),
(810023104004, 'ARUL JASMINE D', '93', 24),
(810023104005, 'SANTHIYA S', '92', 21),
(810023104006, 'ARUL JEBARAJ M', '84', 24),
(810023104007, 'YUVARANI S', '92', 23),
(810023104008, 'VISHNUPRIYA K', '94', 24),
(810023104009, 'MONISHA JENCY J', '96', 24),
(810023104010, 'NISHASRI A', '83', 24),
(810023104011, 'VIVEKANANDAN A', '58', 21),
(810023104012, 'SAKTHIVEL K', '58', 20),
(810023104013, 'DIVYA K', '69', 23),
(810023104014, 'SARAVANAKUMAR P', '68', 23),
(810023104015, 'DEEPIKA A', '94', 24),
(810023104016, 'RAJESH S', '87', 23),
(810023104017, 'SHOBANA V', '84', 23),
(810023104018, 'SOWMIYA S', '91', 22),
(810023104019, 'MATHAN KUMAR G', '89', 22),
(810023104020, 'AKASH A', '65', 18),
(810023104021, 'VAITHEESHWARAN P', '94', 23),
(810023104022, 'ASIN T', '96', 22),
(810023104023, 'ASHOK RAJ A', '40', 17),
(810023104024, 'BALAMURUGAN K', '59', 20),
(810023104025, 'DEEPAK RAJ E', '79', 22),
(810023104026, 'GOMATHI S', '77', 18),
(810023104027, 'ARUVI V', '95', 24),
(810023104028, 'VIMAL RAJ J', '73', 22),
(810023104029, 'NIRMALKUMAR', '51', 18),
(810023104030, 'VIJAY V', '92', 24),
(810023104031, 'VAISHNAVI P', '96', 22),
(810023104032, 'MUTHAZHAGI P', '79', 24),
(810023104033, 'DHANALAKSHMI J', '78', 20),
(810023104034, 'GOKUL RAJAN T', '70', 20),
(810023104036, 'AYISHA H', '77', 23),
(810023104037, 'AKSHAYA S', '83', 23),
(810023104038, 'HARINI S', '87', 23),
(810023104039, 'INBAN V', '56', 19),
(810023104040, 'SARATHY V', '88', 24),
(810023104041, 'PUGAZHVADIVU E', '99', 24),
(810023104042, 'VEERAMANI S', '65', 24),
(810023104043, 'SNOW SELVA RAFIKA S', '91', 23),
(810023104044, 'MAHENDIRAN M', '72', 24),
(810023104045, 'MUTHAMIZHSELVI M', '91', 23),
(810023104046, 'MOHANADHARSHINI S', '74', 18),
(810023104047, 'DEEPANRAJA S', '89', 22),
(810023104048, 'KATHIRAVAN P', '77', 24),
(810023104049, 'SANGEETHA J', '70', 22),
(810023104050, 'MUGESHKUMAR M', '64', 24),
(810023104051, 'INDRA SANTHOSHI B', '85', 23),
(810023104052, 'RENUGA S', '80', 24),
(810023104053, 'HONIXA AFFRIN G A', '80', 23),
(810023104054, 'KELLTENA D', '79', 23),
(810023104055, 'WILMA ROSARY D', '90', 23),
(810023104056, 'RADHIKA R', '89', 23),
(810023104057, 'ROFEENA J', '84', 22),
(810023104058, 'MUTHURAJA P', '80', 23),
(810023104059, 'YOKESWARAN P', '50', 18),
(810023104060, 'RIFAYA PARVEEN S', '92', 24);

-- --------------------------------------------------------

--
-- Table structure for table `cseage3151`
--

CREATE TABLE `cseage3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cseage3151`
--

INSERT INTO `cseage3151` (`regno`, `name`, `ge3151_mark`, `ge3151_attendance`) VALUES
(810023104001, 'DARSNA S', '96', 17),
(810023104002, 'CHARLIN ASHINI A D', '92', 19),
(810023104003, 'SRINIDHI K', '76', 19),
(810023104004, 'ARUL JASMINE D', '90', 19),
(810023104005, 'SANTHIYA S', '97', 17),
(810023104006, 'ARUL JEBARAJ M', '92', 19),
(810023104007, 'YUVARANI S', '79', 19),
(810023104008, 'VISHNUPRIYA K', '92', 19),
(810023104009, 'MONISHA JENCY J', '98', 19),
(810023104010, 'NISHASRI A', '95', 19),
(810023104011, 'VIVEKANANDAN A', '85', 17),
(810023104012, 'SAKTHIVEL K', '88', 17),
(810023104013, 'DIVYA K', '82', 19),
(810023104014, 'SARAVANAKUMAR P', '75', 19),
(810023104015, 'DEEPIKA A', '86', 19),
(810023104016, 'RAJESH S', '97', 19),
(810023104017, 'SHOBANA V', '94', 19),
(810023104018, 'SOWMIYA S', '87', 19),
(810023104019, 'MATHAN KUMAR G', '85', 19),
(810023104020, 'AKASH A', '73', 16),
(810023104021, 'VAITHEESHWARAN P', '93', 19),
(810023104022, 'ASIN T', '84', 17),
(810023104023, 'ASHOK RAJ A', '73', 16),
(810023104024, 'BALAMURUGAN K', '83', 18),
(810023104025, 'DEEPAK RAJ E', '78', 19),
(810023104026, 'GOMATHI S', '89', 16),
(810023104027, 'ARUVI V', '96', 19),
(810023104028, 'VIMAL RAJ J', '88', 18),
(810023104029, 'NIRMALKUMAR', '75', 16),
(810023104030, 'VIJAY V', '94', 19),
(810023104031, 'VAISHNAVI P', '95', 19),
(810023104032, 'MUTHAZHAGI P', '94', 19),
(810023104033, 'DHANALAKSHMI J', '92', 19),
(810023104034, 'GOKUL RAJAN T', '79', 19),
(810023104036, 'AYISHA H', '82', 19),
(810023104037, 'AKSHAYA S', '89', 19),
(810023104038, 'HARINI S', '75', 19),
(810023104039, 'INBAN V', '77', 17),
(810023104040, 'SARATHY V', '79', 19),
(810023104041, 'PUGAZHVADIVU E', '96', 19),
(810023104042, 'VEERAMANI S', '75', 19),
(810023104043, 'SNOW SELVA RAFIKA S', '93', 19),
(810023104044, 'MAHENDIRAN M', '77', 19),
(810023104045, 'MUTHAMIZHSELVI M', '80', 19),
(810023104046, 'MOHANADHARSHINI S', '82', 17),
(810023104047, 'DEEPANRAJA S', '83', 19),
(810023104048, 'KATHIRAVAN P', '86', 19),
(810023104049, 'SANGEETHA J', '86', 19),
(810023104050, 'MUGESHKUMAR M', '70', 19),
(810023104051, 'INDRA SANTHOSHI B', '93', 18),
(810023104052, 'RENUGA S', '91', 19),
(810023104053, 'HONIXA AFFRIN G A', '98', 19),
(810023104054, 'KELLTENA D', '87', 19),
(810023104055, 'WILMA ROSARY D', '92', 19),
(810023104056, 'RADHIKA R', '89', 19),
(810023104057, 'ROFEENA J', '95', 18),
(810023104058, 'MUTHURAJA P', '93', 19),
(810023104059, 'YOKESWARAN P', '72', 17),
(810023104060, 'RIFAYA PARVEEN S', '92', 18);

-- --------------------------------------------------------

--
-- Table structure for table `cseage3152`
--

CREATE TABLE `cseage3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cseahs3152`
--

CREATE TABLE `cseahs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cseama3151`
--

CREATE TABLE `cseama3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cseama3151`
--

INSERT INTO `cseama3151` (`regno`, `name`, `ma3151_mark`, `ma3151_attendance`) VALUES
(810023104001, 'DARSNA S', '84', 36),
(810023104002, 'CHARLIN ASHINI A D', '88', 37),
(810023104003, 'SRINIDHI K', '45', 27),
(810023104004, 'ARUL JASMINE D', '80', 37),
(810023104005, 'SANTHIYA S', '94', 34),
(810023104006, 'ARUL JEBARAJ M', '67', 37),
(810023104007, 'YUVARANI S', '80', 37),
(810023104008, 'VISHNUPRIYA K', '75', 37),
(810023104009, 'MONISHA JENCY J', '86', 37),
(810023104010, 'NISHASRI A', '86', 37),
(810023104011, 'VIVEKANANDAN A', '55', 34),
(810023104012, 'SAKTHIVEL K', '40', 26),
(810023104013, 'DIVYA K', '49', 29),
(810023104014, 'SARAVANAKUMAR P', '90', 35),
(810023104015, 'DEEPIKA A', '97', 35),
(810023104016, 'RAJESH S', '73', 37),
(810023104017, 'SHOBANA V', '90', 37),
(810023104018, 'SOWMIYA S', '79', 33),
(810023104019, 'MATHAN KUMAR G', '79', 33),
(810023104020, 'AKASH A', '51', 33),
(810023104021, 'VAITHEESHWARAN P', '81', 37),
(810023104022, 'ASIN T', '91', 37),
(810023104023, 'ASHOK RAJ A', '40', 34),
(810023104024, 'BALAMURUGAN K', '53', 35),
(810023104025, 'DEEPAK RAJ E', '65', 37),
(810023104026, 'GOMATHI S', '88', 34),
(810023104027, 'ARUVI V', '100', 37),
(810023104028, 'VIMAL RAJ J', '55', 31),
(810023104029, 'NIRMALKUMAR', '56', 32),
(810023104030, 'VIJAY V', '74', 37),
(810023104031, 'VAISHNAVI P', '93', 33),
(810023104032, 'MUTHAZHAGI P', '58', 37),
(810023104033, 'DHANALAKSHMI J', '57', 37),
(810023104034, 'GOKUL RAJAN T', '67', 35),
(810023104036, 'AYISHA H', '70', 37),
(810023104037, 'AKSHAYA S', '82', 33),
(810023104038, 'HARINI S', '69', 36),
(810023104039, 'INBAN V', '40', 28),
(810023104040, 'SARATHY V', '85', 33),
(810023104041, 'PUGAZHVADIVU E', '100', 37),
(810023104042, 'VEERAMANI S', '59', 37),
(810023104043, 'SNOW SELVA RAFIKA S', '100', 37),
(810023104044, 'MAHENDIRAN M', '76', 37),
(810023104045, 'MUTHAMIZHSELVI M', '86', 37),
(810023104046, 'MOHANADHARSHINI S', '59', 25),
(810023104047, 'DEEPANRAJA S', '97', 35),
(810023104048, 'KATHIRAVAN P', '98', 37),
(810023104049, 'SANGEETHA J', '69', 31),
(810023104050, 'MUGESHKUMAR M', '76', 35),
(810023104051, 'INDRA SANTHOSHI B', '87', 35),
(810023104052, 'RENUGA S', '80', 37),
(810023104053, 'HONIXA AFFRIN G A', '89', 37),
(810023104054, 'KELLTENA D', '75', 37),
(810023104055, 'WILMA ROSARY D', '95', 37),
(810023104056, 'RADHIKA R', '94', 34),
(810023104057, 'ROFEENA J', '89', 33),
(810023104058, 'MUTHURAJA P', '86', 35),
(810023104059, 'YOKESWARAN P', '56', 34),
(810023104060, 'RIFAYA PARVEEN S', '79', 35);

-- --------------------------------------------------------

--
-- Table structure for table `cseaph3151`
--

CREATE TABLE `cseaph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `csebcy3151`
--

CREATE TABLE `csebcy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `csebge3151`
--

CREATE TABLE `csebge3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `csebge3152`
--

CREATE TABLE `csebge3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `csebhs3152`
--

CREATE TABLE `csebhs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `csebma3151`
--

CREATE TABLE `csebma3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `csebph3151`
--

CREATE TABLE `csebph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eceacy3151`
--

CREATE TABLE `eceacy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `eceacy3151`
--

INSERT INTO `eceacy3151` (`regno`, `name`, `cy3151_mark`, `cy3151_attendance`) VALUES
(810023106001, 'DEVISRI P', '79', 24),
(810023106002, 'MADHAVAN S', '81', 28),
(810023106003, 'SHAFANA YASMIN K', '91', 26),
(810023106004, 'SARANYA G', '82', 27),
(810023106006, 'SARAVANAN A', '65', 24),
(810023106008, 'SANTHOSH KUMAR A', '81', 25),
(810023106009, 'BALAJI V', '95', 26),
(810023106010, 'NIVETHA K', '82', 28),
(810023106011, 'UMAR H', '68', 26),
(810023106012, 'NAVAMALIKA B', '91', 26),
(810023106013, 'AMARNATH P', '87', 28),
(810023106014, 'KAVINESAN M', '79', 25),
(810023106015, 'VIJAYAKUMARI D', '72', 26),
(810023106016, 'VIGNESHWARI A', '87', 26),
(810023106017, 'AMIRTHAMBIKA R', '93', 28),
(810023106018, 'RENUKA K', '68', 25),
(810023106019, 'GOWTHAM R', '65', 25),
(810023106020, 'CHARULATHA B', '69', 24),
(810023106021, 'KRISHNARAJ M', '63', 28),
(810023106022, 'PRIYADHARSHINI B', '60', 28),
(810023106023, 'AKASH A', '67', 25),
(810023106024, 'RAJIV K', '61', 24),
(810023106025, 'SRI LAKSHMI R', '87', 27),
(810023106026, 'LAVANAYA K', '81', 28),
(810023106027, 'SONIYA T', '88', 22),
(810023106028, 'VEDHACHALAM K', '89', 28),
(810023106029, 'KANISHKA S', '63', 26),
(810023106030, 'VENKATESH H', '83', 27),
(810023106031, 'KAVI KUMAR K', '86', 20),
(810023106032, 'VIDHUBALA K', '85', 27),
(810023106033, 'ANBUSELVAN A', '68', 26),
(810023106034, 'ARCHANA M', '83', 24),
(810023106035, 'RITHISH B', '88', 26),
(810023106036, 'DHARSHINI P S', '91', 27),
(810023106037, 'ASIYA T', '72', 27),
(810023106038, 'IRFAN T SHADIL', '77', 25),
(810023106039, 'DAYANITHI C', '69', 25),
(810023106040, 'YUVARAJ T', '71', 24),
(810023106041, 'VANCHINATHAN S S', '70', 28),
(810023106042, 'DEVIBALA K', '86', 25),
(810023106043, 'HARINI B', '84', 25),
(810023106044, 'DHUVARIKA S', '72', 24),
(810023106045, 'AKALYA M', '92', 28),
(810023106046, 'PON KARTHIKA V', '77', 25),
(810023106047, 'DIVYASRI S', '70', 15),
(810023106048, 'KESHAV VIJAYAN K R', '86', 26),
(810023106049, 'KEERTHIKA S', '78', 25),
(810023106050, 'SURYA S', '92', 25),
(810023106051, 'NISHANTHI S V', '75', 27),
(810023106052, 'SIVARAMAN K', '84', 24),
(810023106053, 'SARANYA A', '76', 26),
(810023106054, 'KALAIYARASAN V', '60', 20),
(810023106055, 'RAJESHWARI P', '64', 24),
(810023106056, 'KARTHIKEYAN S', '73', 23),
(810023106057, 'MENAKA M', '85', 26),
(810023106058, 'LAKSHMI PRABHA M', '95', 25);

-- --------------------------------------------------------

--
-- Table structure for table `eceage3151`
--

CREATE TABLE `eceage3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `eceage3151`
--

INSERT INTO `eceage3151` (`regno`, `name`, `ge3151_mark`, `ge3151_attendance`) VALUES
(810023106001, 'DEVISRI P', '80', 15),
(810023106002, 'MADHAVAN S', '78', 16),
(810023106003, 'SHAFANA YASMIN K', '90', 15),
(810023106004, 'SARANYA G', '91', 15),
(810023106006, 'SARAVANAN A', '70', 14),
(810023106008, 'SANTHOSH KUMAR A', '75', 15),
(810023106009, 'BALAJI V', '93', 14),
(810023106010, 'NIVETHA K', '80', 16),
(810023106011, 'UMAR H', '81', 16),
(810023106012, 'NAVAMALIKA B', '94', 16),
(810023106013, 'AMARNATH P', '92', 16),
(810023106014, 'KAVINESAN M', '81', 15),
(810023106015, 'VIJAYAKUMARI D', '92', 15),
(810023106016, 'VIGNESHWARI A', '93', 16),
(810023106017, 'AMIRTHAMBIKA R', '93', 16),
(810023106018, 'RENUKA K', '80', 13),
(810023106019, 'GOWTHAM R', '82', 14),
(810023106020, 'CHARULATHA B', '83', 14),
(810023106021, 'KRISHNARAJ M', '88', 16),
(810023106022, 'PRIYADHARSHINI B', '73', 16),
(810023106023, 'AKASH A', '78', 14),
(810023106024, 'RAJIV K', '80', 14),
(810023106025, 'SRI LAKSHMI R', '83', 15),
(810023106026, 'LAVANAYA K', '85', 16),
(810023106027, 'SONIYA T', '93', 13),
(810023106028, 'VEDHACHALAM K', '84', 16),
(810023106029, 'KANISHKA S', '92', 16),
(810023106030, 'VENKATESH H', '93', 15),
(810023106031, 'KAVI KUMAR K', '93', 14),
(810023106032, 'VIDHUBALA K', '94', 15),
(810023106033, 'ANBUSELVAN A', '70', 16),
(810023106034, 'ARCHANA M', '90', 15),
(810023106035, 'RITHISH B', '95', 16),
(810023106036, 'DHARSHINI P S', '94', 14),
(810023106037, 'ASIYA T', '87', 16),
(810023106038, 'IRFAN T SHADIL', '81', 15),
(810023106039, 'DAYANITHI C', '80', 15),
(810023106040, 'YUVARAJ T', '85', 14),
(810023106041, 'VANCHINATHAN S S', '97', 16),
(810023106042, 'DEVIBALA K', '91', 13),
(810023106043, 'HARINI B', '80', 14),
(810023106044, 'DHUVARIKA S', '82', 14),
(810023106045, 'AKALYA M', '95', 16),
(810023106046, 'PON KARTHIKA V', '88', 15),
(810023106047, 'DIVYASRI S', '61', 10),
(810023106048, 'KESHAV VIJAYAN K R', '93', 14),
(810023106049, 'KEERTHIKA S', '95', 13),
(810023106050, 'SURYA S', '94', 15),
(810023106051, 'NISHANTHI S V', '92', 15),
(810023106052, 'SIVARAMAN K', '85', 14),
(810023106053, 'SARANYA A', '88', 16),
(810023106054, 'KALAIYARASAN V', '70', 14),
(810023106055, 'RAJESHWARI P', '92', 14),
(810023106056, 'KARTHIKEYAN S', '76', 14),
(810023106057, 'MENAKA M', '90', 16),
(810023106058, 'LAKSHMI PRABHA M', '84', 15);

-- --------------------------------------------------------

--
-- Table structure for table `eceage3152`
--

CREATE TABLE `eceage3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eceahs3152`
--

CREATE TABLE `eceahs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `eceahs3152`
--

INSERT INTO `eceahs3152` (`regno`, `name`, `hs3152_mark`, `hs3152_attendance`) VALUES
(810023106001, 'DEVISRI P', '84', 19),
(810023106002, 'MADHAVAN S', '80', 21),
(810023106003, 'SHAFANA YASMIN K', '80', 21),
(810023106004, 'SARANYA G', '83', 21),
(810023106006, 'SARAVANAN A', '60', 15),
(810023106008, 'SANTHOSH KUMAR A', '80', 19),
(810023106009, 'BALAJI V', '85', 21),
(810023106010, 'NIVETHA K', '86', 21),
(810023106011, 'UMAR H', '81', 20),
(810023106012, 'NAVAMALIKA B', '83', 20),
(810023106013, 'AMARNATH P', '89', 21),
(810023106014, 'KAVINESAN M', '75', 18),
(810023106015, 'VIJAYAKUMARI D', '73', 20),
(810023106016, 'VIGNESHWARI A', '81', 19),
(810023106017, 'AMIRTHAMBIKA R', '80', 20),
(810023106018, 'RENUKA K', '80', 18),
(810023106019, 'GOWTHAM R', '84', 17),
(810023106020, 'CHARULATHA B', '81', 20),
(810023106021, 'KRISHNARAJ M', '84', 20),
(810023106022, 'PRIYADHARSHINI B', '70', 19),
(810023106023, 'AKASH A', '65', 20),
(810023106024, 'RAJIV K', '65', 16),
(810023106025, 'SRI LAKSHMI R', '84', 21),
(810023106026, 'LAVANAYA K', '77', 21),
(810023106027, 'SONIYA T', '86', 17),
(810023106028, 'VEDHACHALAM K', '81', 21),
(810023106029, 'KANISHKA S', '80', 20),
(810023106030, 'VENKATESH H', '77', 20),
(810023106031, 'KAVI KUMAR K', '81', 16),
(810023106032, 'VIDHUBALA K', '82', 18),
(810023106033, 'ANBUSELVAN A', '81', 20),
(810023106034, 'ARCHANA M', '84', 17),
(810023106035, 'RITHISH B', '85', 18),
(810023106036, 'DHARSHINI P S', '90', 20),
(810023106037, 'ASIYA T', '83', 21),
(810023106038, 'IRFAN T SHADIL', '80', 17),
(810023106039, 'DAYANITHI C', '75', 15),
(810023106040, 'YUVARAJ T', '86', 20),
(810023106041, 'VANCHINATHAN S S', '90', 21),
(810023106042, 'DEVIBALA K', '88', 19),
(810023106043, 'HARINI B', '86', 19),
(810023106044, 'DHUVARIKA S', '85', 18),
(810023106045, 'AKALYA M', '89', 18),
(810023106046, 'PON KARTHIKA V', '83', 19),
(810023106047, 'DIVYASRI S', '71', 15),
(810023106048, 'KESHAV VIJAYAN K R', '81', 21),
(810023106049, 'KEERTHIKA S', '77', 20),
(810023106050, 'SURYA S', '81', 20),
(810023106051, 'NISHANTHI S V', '84', 21),
(810023106052, 'SIVARAMAN K', '80', 13),
(810023106053, 'SARANYA A', '80', 19),
(810023106054, 'KALAIYARASAN V', '69', 16),
(810023106055, 'RAJESHWARI P', '71', 19),
(810023106056, 'KARTHIKEYAN S', '80', 18),
(810023106057, 'MENAKA M', '88', 21),
(810023106058, 'LAKSHMI PRABHA M', '85', 20);

-- --------------------------------------------------------

--
-- Table structure for table `eceama3151`
--

CREATE TABLE `eceama3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `eceama3151`
--

INSERT INTO `eceama3151` (`regno`, `name`, `ma3151_mark`, `ma3151_attendance`) VALUES
(810023106001, 'DEVISRI P', '92', 25),
(810023106002, 'MADHAVAN S', '84', 26),
(810023106003, 'SHAFANA YASMIN K', '87', 26),
(810023106004, 'SARANYA G', '82', 26),
(810023106006, 'SARAVANAN A', '52', 24),
(810023106008, 'SANTHOSH KUMAR A', '60', 25),
(810023106009, 'BALAJI V', '90', 25),
(810023106010, 'NIVETHA K', '91', 26),
(810023106011, 'UMAR H', '72', 26),
(810023106012, 'NAVAMALIKA B', '83', 26),
(810023106013, 'AMARNATH P', '90', 26),
(810023106014, 'KAVINESAN M', '64', 25),
(810023106015, 'VIJAYAKUMARI D', '79', 25),
(810023106016, 'VIGNESHWARI A', '91', 24),
(810023106017, 'AMIRTHAMBIKA R', '83', 26),
(810023106018, 'RENUKA K', '87', 25),
(810023106019, 'GOWTHAM R', '75', 24),
(810023106020, 'CHARULATHA B', '70', 26),
(810023106021, 'KRISHNARAJ M', '70', 26),
(810023106022, 'PRIYADHARSHINI B', '65', 26),
(810023106023, 'AKASH A', '57', 26),
(810023106024, 'RAJIV K', '48', 23),
(810023106025, 'SRI LAKSHMI R', '76', 26),
(810023106026, 'LAVANAYA K', '86', 26),
(810023106027, 'SONIYA T', '99', 23),
(810023106028, 'VEDHACHALAM K', '65', 26),
(810023106029, 'KANISHKA S', '82', 26),
(810023106030, 'VENKATESH H', '100', 26),
(810023106031, 'KAVI KUMAR K', '85', 24),
(810023106032, 'VIDHUBALA K', '88', 25),
(810023106033, 'ANBUSELVAN A', '78', 25),
(810023106034, 'ARCHANA M', '71', 25),
(810023106035, 'RITHISH B', '87', 26),
(810023106036, 'DHARSHINI P S', '78', 25),
(810023106037, 'ASIYA T', '70', 26),
(810023106038, 'IRFAN T SHADIL', '91', 26),
(810023106039, 'DAYANITHI C', '92', 25),
(810023106040, 'YUVARAJ T', '90', 25),
(810023106041, 'VANCHINATHAN S S', '81', 26),
(810023106042, 'DEVIBALA K', '83', 23),
(810023106043, 'HARINI B', '76', 26),
(810023106044, 'DHUVARIKA S', '87', 25),
(810023106045, 'AKALYA M', '98', 26),
(810023106046, 'PON KARTHIKA V', '79', 25),
(810023106047, 'DIVYASRI S', '40', 22),
(810023106048, 'KESHAV VIJAYAN K R', '96', 25),
(810023106049, 'KEERTHIKA S', '88', 26),
(810023106050, 'SURYA S', '100', 26),
(810023106051, 'NISHANTHI S V', '56', 26),
(810023106052, 'SIVARAMAN K', '50', 25),
(810023106053, 'SARANYA A', '84', 25),
(810023106054, 'KALAIYARASAN V', '69', 24),
(810023106055, 'RAJESHWARI P', '73', 24),
(810023106056, 'KARTHIKEYAN S', '90', 25),
(810023106057, 'MENAKA M', '90', 26),
(810023106058, 'LAKSHMI PRABHA M', '78', 26);

-- --------------------------------------------------------

--
-- Table structure for table `eceaph3151`
--

CREATE TABLE `eceaph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `eceaph3151`
--

INSERT INTO `eceaph3151` (`regno`, `name`, `ph3151_mark`, `ph3151_attendance`) VALUES
(810023106001, 'DEVISRI P', '74 ', 23),
(810023106002, 'MADHAVAN S', '66 ', 23),
(810023106003, 'SHAFANA YASMIN K', '87 ', 23),
(810023106004, 'SARANYA G', '64', 23),
(810023106006, 'SARAVANAN A', '48', 18),
(810023106008, 'SANTHOSH KUMAR A', '48', 23),
(810023106009, 'BALAJI V', '90', 23),
(810023106010, 'NIVETHA K', '84', 23),
(810023106011, 'UMAR H', '53', 23),
(810023106012, 'NAVAMALIKA B', '73', 23),
(810023106013, 'AMARNATH P', '61', 23),
(810023106014, 'KAVINESAN M', '79', 23),
(810023106015, 'VIJAYAKUMARI D', '65', 23),
(810023106016, 'VIGNESHWARI A', '67', 21),
(810023106017, 'AMIRTHAMBIKA R', '71', 23),
(810023106018, 'RENUKA K', '71', 19),
(810023106019, 'GOWTHAM R', '52', 22),
(810023106020, 'CHARULATHA B', '60', 22),
(810023106021, 'KRISHNARAJ M', '60', 22),
(810023106022, 'PRIYADHARSHINI B', '61', 23),
(810023106023, 'AKASH A', '61', 22),
(810023106024, 'RAJIV K', '60', 20),
(810023106025, 'SRI LAKSHMI R', '72', 23),
(810023106026, 'LAVANAYA K', '71', 23),
(810023106027, 'SONIYA T', '79', 21),
(810023106028, 'VEDHACHALAM K', '53', 23),
(810023106029, 'KANISHKA S', '62', 23),
(810023106030, 'VENKATESH H', '72', 23),
(810023106031, 'KAVI KUMAR K', '75', 20),
(810023106032, 'VIDHUBALA K', '80', 22),
(810023106033, 'ANBUSELVAN A', '60', 23),
(810023106034, 'ARCHANA M', '67', 21),
(810023106035, 'RITHISH B', '67', 22),
(810023106036, 'DHARSHINI P S', '92', 23),
(810023106037, 'ASIYA T', '60', 22),
(810023106038, 'IRFAN T SHADIL', '71', 23),
(810023106039, 'DAYANITHI C', '51', 22),
(810023106040, 'YUVARAJ T', '66', 32),
(810023106041, 'VANCHINATHAN S S', '52', 23),
(810023106042, 'DEVIBALA K', '60', 21),
(810023106043, 'HARINI B', '75', 22),
(810023106044, 'DHUVARIKA S', '70', 32),
(810023106045, 'AKALYA M', '84', 23),
(810023106046, 'PON KARTHIKA V', '60', 22),
(810023106047, 'DIVYASRI S', '38', 18),
(810023106048, 'KESHAV VIJAYAN K R', '74', 21),
(810023106049, 'KEERTHIKA S', '75', 23),
(810023106050, 'SURYA S', '89', 23),
(810023106051, 'NISHANTHI S V', '82', 23),
(810023106052, 'SIVARAMAN K', '63', 22),
(810023106053, 'SARANYA A', '72', 23),
(810023106054, 'KALAIYARASAN V', '60', 20),
(810023106055, 'RAJESHWARI P', '66', 21),
(810023106056, 'KARTHIKEYAN S', '60', 22),
(810023106057, 'MENAKA M', '73', 23),
(810023106058, 'LAKSHMI PRABHA M', '88', 23);

-- --------------------------------------------------------

--
-- Table structure for table `ecebcy3151`
--

CREATE TABLE `ecebcy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ecebge3151`
--

CREATE TABLE `ecebge3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ecebge3152`
--

CREATE TABLE `ecebge3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ecebhs3152`
--

CREATE TABLE `ecebhs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ecebma3151`
--

CREATE TABLE `ecebma3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ecebph3151`
--

CREATE TABLE `ecebph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eeeacy3151`
--

CREATE TABLE `eeeacy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eeeage3151`
--

CREATE TABLE `eeeage3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eeeage3152`
--

CREATE TABLE `eeeage3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eeeahs3152`
--

CREATE TABLE `eeeahs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eeeama3151`
--

CREATE TABLE `eeeama3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eeeaph3151`
--

CREATE TABLE `eeeaph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eeebcy3151`
--

CREATE TABLE `eeebcy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eeebge3151`
--

CREATE TABLE `eeebge3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eeebge3152`
--

CREATE TABLE `eeebge3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eeebma3151`
--

CREATE TABLE `eeebma3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eeebph3151`
--

CREATE TABLE `eeebph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `name` varchar(50) NOT NULL,
  `clshandle` varchar(20) NOT NULL,
  `semester` varchar(20) NOT NULL,
  `subcode` varchar(10) NOT NULL,
  `email` text NOT NULL,
  `staffdept` varchar(30) NOT NULL,
  `ep` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`name`, `clshandle`, `semester`, `subcode`, `email`, `staffdept`, `ep`) VALUES
('Mr.C.Suresh Kumar', 'CSE-B', '1', 'GE3151', 'sastiinfotech@gmail.com', 'CSE/IT', 'no'),
('Mrs.G.Revathi', 'IT-A', '1', 'GE3151', 'revaguna7@gmail.com', 'CSE/IT', 'no'),
('Mrs.G.Revathi', 'IT-B', '1', 'GE3151', 'revaguna7@gmail.com', 'CSE/IT', 'no'),
('MRS.R.Sasikala', 'EEE-A', '1', 'GE3151', 'sastiinfotech@gmail.com', 'CSE/IT', 'no'),
('MRS.R.Sasikala', 'EEE-B', '1', 'GE3151', 'sastiinfotech@gmail.com', 'CSE/IT', 'no'),
('MRS.R.Sasikala', 'ECE-B', '1', 'GE3151', 'sastiinfotech@gmail.com', 'CSE/IT', 'no'),
('MR.M.Krishnakumar', 'ECE-A', '1', 'GE3151', 'krishnakumarme86@gmail.com', 'CSE/IT', 'no'),
('MR.M.Krishnakumar', 'BIOTECH', '1', 'GE3151', 'krishnakumarme86@gmail.com', 'CSE/IT', 'no'),
('MR.M.Krishnakumar', 'CSE-A', '1', 'GE3151', 'krishnakumarme86@gmail.com', 'CSE/IT', 'no'),
('Mrs.L.Vanitha', 'PETRO', '1', 'GE3151', 'vanithalaksh22@gmail.com', 'CSE/IT', 'no'),
('Mrs.L.Vanitha', 'PHARMA', '1', 'GE3151', 'vanithalaksh22@gmail.com', 'CSE/IT', 'no'),
('Mrs.N.Shanmuga Priya', 'CIVIL-A', '1', 'GE3151', 'priyashacse@gmail.com,', 'CSE/IT', 'no'),
('Mrs.N.Shanmuga Priya', 'CIVILMECHANICAL-TM', '1', 'GE3151', 'priyashacse@gmail.com,', 'CSE/IT', 'no'),
('Mrs.N.Shanmuga Priya', 'AUTOMOBILE', '1', 'GE3151', 'priyashacse@gmail.com,', 'CSE/IT', 'no'),
('DR.C.Sharmila Devi', 'EEE-B', '1', 'MA3151', 'sharmilavadivelgh@gmail.com', 'Maths', 'no'),
('DR.C.Sharmila Devi', 'PETRO', '1', 'MA3151', 'sharmilavadivelgh@gmail.com', 'Maths', 'no'),
('DR.B.Palpandi', 'ECE-B', '1', 'MA3151', 'palpandiphd15@gmail.com', 'Maths', 'no'),
('MRS.S.Menaka', 'MECHANICAL-A', '1', 'MA3151', 'menaka.aut@gmail.com', 'Maths', 'no'),
('MRS.S.Menaka', 'MECHANICAL-B', '1', 'MA3151', 'menaka.aut@gmail.com', 'Maths', 'no'),
('DR.M.Aruvi', 'CSE-A', '1', 'MA3151', 'aruvi.aut@gmail.com ', 'Maths', 'no'),
('DR.M.Aruvi', 'AUTOMOBILE', '1', 'MA3151', 'aruvi.aut@gmail.com ', 'Maths', 'no'),
('DR.B.Sumithra', 'CIVIL-B', '1', 'MA3151', 'surajsumir@gmail.com ', 'Maths', 'no'),
('DR.B.Sumithra', 'CSE-B', '1', 'MA3151', 'surajsumir@gmail.com ', 'Maths', 'no'),
('DR.B.Sumithra', 'AUTOMOBILE', '1', 'MA3151', 'surajsumir@gmail.com ', 'Maths', 'no'),
('DR.S.Therasa', 'PHARMA', '1', 'MA3151', 'thema.jeje@gmail.com ', 'Maths', 'no'),
('Mrs.S.Mahalakshmi', 'CIVILMECHANICAL-TM', '1', 'MA3151', 'mahasenthil2@gmail.com', 'Maths', 'no'),
('Dr.S.Ramasubramanian', 'EEE-A', '1', 'MA3151', 'srsramdinesh@gmail.com', 'Maths', 'no'),
('Dr. R.Sebasthipriya', 'ECE-A', '1', 'MA3151', 'sebasthipriya@gmail.com', 'Maths', 'no'),
('Dr.K.Kamaraj', 'BIOTECH', '1', 'MA3151', 'krajkj@yahoo.com', 'Maths', 'no'),
('Dr.K.Kamaraj', 'IT-B', '1', 'MA3151', 'krajkj@yahoo.com', 'Maths', 'no'),
('Dr.A.Puvaneswari', 'CIVIL-A', '1', 'MA3151', 'apuvaneswari@gmail.com ', 'Maths', 'no'),
('Dr.A.Puvaneswari', 'IT-A', '1', 'MA3151', 'apuvaneswari@gmail.com ', 'Maths', 'no'),
('Dr.K.Nehru', 'MECHANICAL-B', '1', 'CY3151', 'knehru@aubit.edu.in', 'Chemistry', 'no'),
('Dr.N.Devika', 'AUTOMOBILE', '1', 'CY3151', 'devika.mekala@rediffmail.com', 'Chemistry', 'no'),
('Dr.N.Devika', 'CSE-B', '1', 'CY3151', 'devika.mekala@rediffmail.com', 'Chemistry', 'no'),
('Dr.V.K.Sethurpandian', 'IT-B', '1', 'CY3151', 'vksenthur@gmail.com', 'Chemistry', 'no'),
('Dr.V.K.Sethurpandian', 'PETRO', '1', 'CY3151', 'vksenthur@gmail.com', 'Chemistry', 'no'),
('Dr.E.Anuja', 'IT-A', '1', 'CY3151', 'anuja@aubit.edu.in', 'Chemistry', 'no'),
('Dr.E.Anuja', 'PHARMA', '1', 'CY3151', 'anuja@aubit.edu.in', 'Chemistry', 'no'),
('Dr.G.D.Gayathri', 'EEE-A', '1', 'CY3151', 'gayathri.tau@gmail.com', 'Chemistry', 'no'),
('Dr.G.D.Gayathri', 'EEE-B', '1', 'CY3151', 'gayathri.tau@gmail.com', 'Chemistry', 'no'),
('Dr.V.Thangaraj', 'MECHANICAL-A', '1', 'CY3151', 'thangamraj@gmail.com', 'Chemistry', 'no'),
('Dr.V.Thangaraj', 'CIVIL-B', '1', 'CY3151', 'thangamraj@gmail.com', 'Chemistry', 'no'),
('Dr.S.Moscow', 'ECE-A', '1', 'CY3151', 'moscowchem@gmail.com', 'Chemistry', 'no'),
('Dr.S.Moscow', 'AUTOMOBILE', '1', 'CY3151', 'moscowchem@gmail.com', 'Chemistry', 'no'),
('Dr.K.Kanimozhi', 'CSE-A', '1', 'CY3151', 'kanirams47@gmail.com', 'Chemistry', 'no'),
('Dr.K.Kanimozhi', 'ECE-B', '1', 'CY3151', 'kanirams47@gmail.com', 'Chemistry', 'no'),
('Dr.V.Tamilmani', 'BIOTECH', '1', 'CY3151', 'vj_tamil@yahoo.co.in', 'Chemistry', 'no'),
('Dr.V.Tamilmani', 'PETRO', '1', 'CY3151', 'vj_tamil@yahoo.co.in', 'Chemistry', 'no'),
('Dr.J.Jayachandran', 'CIVIL-A', '1', 'HS3152', 'jjannauniv@gmail.com', 'English', 'no'),
('Dr.J.Jayachandran', 'CIVIL-B', '1', 'HS3152', 'jjannauniv@gmail.com', 'English', 'no'),
('Dr.D.Elizabeth', 'IT-A', '1', 'HS3152', 'elizebethdhanasamy@gmail.com', 'English', 'no'),
('Dr.D.Elizabeth', 'IT-B', '1', 'HS3152', 'elizebethdhanasamy@gmail.com', 'English', 'no'),
(' Dr.K.Renuka', 'MECHANICAL-A', '1', 'HS3152', 'renukak2609@gmail.com', 'English', 'no'),
(' Dr.K.Renuka', 'MECHANICAL-B', '1', 'HS3152', 'renukak2609@gmail.com', 'English', 'no'),
('Mr.R.Shanmugavel', 'ECE-A', '1', 'HS3152', 'shanmugavel.85@gmail.com', 'English', 'no'),
('Mr.R.Shanmugavel', 'ECE-B', '1', 'HS3152', 'shanmugavel.85@gmail.com', 'English', 'no'),
('Mr.R.Shanmugavel', 'CIVILMECHANICAL-TM', '1', 'HS3152', 'shanmugavel.85@gmail.com', 'English', 'no'),
(' Dr.N.Chitra', 'BIOTECH', '1', 'HS3152', 'chithubala.eng@gmail.com', 'English', 'no'),
(' Dr.N.Chitra', 'PHARMA', '1', 'HS3152', 'chithubala.eng@gmail.com', 'English', 'no'),
(' Dr.R.Nandhini', 'CSE-A', '1', 'HS3152', 'nandhinimani76@yahoo.co.in', 'English', 'no'),
(' Dr.R.Nandhini', 'CSE-B', '1', 'HS3152', 'nandhinimani76@yahoo.co.in', 'English', 'no'),
('Dr.S.Gunasekaran', 'AUTOMOBILE', '1', 'HS3152', 'gunaboopesh@gmail.com', 'English', 'no'),
('Dr.S.Gunasekaran', 'PETRO', '1', 'HS3152', 'gunaboopesh@gmail.com', 'English', 'no'),
('Dr. P. Mani', 'CSE-A', '1', 'PH3151', 'drmaniphy@gmail.com', 'Physics', 'no'),
('Dr. P. Mani', 'CSE-B', '1', 'PH3151', 'drmaniphy@gmail.com', 'Physics', 'no'),
('Dr. A. Viswanathan', 'IT-A', '1', 'PH3151', 'alaganviswa@gmail.com', 'Physics', 'no'),
('Dr. A. Viswanathan', 'IT-B', '1', 'PH3151', 'alaganviswa@gmail.com', 'Physics', 'no'),
('Dr. V. Sivakumar', 'ECE-A', '1', 'PH3151', 'vshiv@yahoo.com', 'Physics', 'no'),
('Dr. V. Sivakumar', 'ECE-B', '1', 'PH3151', 'vshiv@yahoo.com', 'Physics', 'no'),
('Dr. A. Janaki Ramya', 'PETRO', '1', 'PH3151', 'renipapu@gmail.com', 'Physics', 'no'),
('Dr. A. Janaki Ramya', 'PHARMA', '1', 'PH3151', 'renipapu@gmail.com', 'Physics', 'no'),
('Dr. M. Saravanan', 'MECHANICAL-B', '1', 'PH3151', 'msandy.physics@gmail.com', 'Physics', 'no'),
('Mr. N. Ramakrishnan', 'CIVILMECHANICAL-TM', '1', 'PH3151', 'Ramkishri1974@gmail.com', 'Physics', 'no'),
('Dr. G. Senguttuvan', 'AUTOMOBILE', '1', 'PH3151', 'sengutuvan@yahoo.com', 'Physics', 'no'),
('Dr.R.Udhayakumar', 'CIVIL-A', '1', 'CY3151', 'dr.r.udhayakumar@gmail.com', 'Chemistry', 'no'),
('Dr.R.Udhayakumar', 'EEE-B', '1', 'CY3151', 'dr.r.udhayakumar@gmail.com', 'Chemistry', 'no'),
('Mr. N. Ramakrishnan', 'MECHANICAL-A', '1', 'PH3151', 'Ramkishri1974@gmail.com', 'Physics', 'no'),
('Dr.Brahadeeswaran', 'BIOTECH', '1', 'PH3151', 'sbrag67@yahoo.com', 'Physics', 'no'),
('Dr.I.Vetha Potheher', 'CIVIL-A', '1', 'PH3151', 'potheher@aubit.edu.in', 'Physics', 'no'),
('Dr.I.Vetha Potheher', 'CIVIL-B', '1', 'PH3151', 'potheher@aubit.edu.in', 'Physics', 'no'),
('Dr.K.Murugesan', 'MECHANICAL-A', '1', 'GE3152', 'murugu.kanakasabai@gmail.com', 'Tamil', 'no'),
('Dr.K.Murugesan', 'BIOTECH', '1', 'GE3152', 'murugu.kanakasabai@gmail.com', 'Tamil', 'no'),
('Dr.K.Murugesan', 'EEE-A', '1', 'GE3152', 'murugu.kanakasabai@gmail.com', 'Tamil', 'no'),
('Dr.K.Murugesan', 'IT-A', '1', 'GE3152', 'murugu.kanakasabai@gmail.com', 'Tamil', 'no'),
('Dr.K.Murugesan', 'PHARMA', '1', 'GE3152', 'murugu.kanakasabai@gmail.com', 'Tamil', 'no'),
('Dr.K.Murugesan', 'CIVIL-B', '1', 'GE3152', 'murugu.kanakasabai@gmail.com', 'Tamil', 'no'),
('Dr.K.Murugesan', 'ECE-B', '1', 'GE3152', 'murugu.kanakasabai@gmail.com', 'Tamil', 'no'),
('Dr.K.Murugesan', 'CSE-B', '1', 'GE3152', 'murugu.kanakasabai@gmail.com', 'Tamil', 'no'),
('Dr.M.Chandrasekaran', 'CIVIL-A', '1', 'GE3152', 'chandruchellam19@gmail.com', 'Tamil', 'no'),
('Dr.M.Chandrasekaran', 'CIVILMECHANICAL-TM', '1', 'GE3152', 'chandruchellam19@gmail.com', 'Tamil', 'no'),
('Dr.M.Chandrasekaran', 'PETRO', '1', 'GE3152', 'chandruchellam19@gmail.com', 'Tamil', 'no'),
('Dr.M.Chandrasekaran', 'ECE-A', '1', 'GE3152', 'chandruchellam19@gmail.com', 'Tamil', 'no'),
('Dr.M.Chandrasekaran', 'CSE-A', '1', 'GE3152', 'chandruchellam19@gmail.com', 'Tamil', 'no'),
('Dr.M.Chandrasekaran', 'AUTOMOBILE', '1', 'GE3152', 'chandruchellam19@gmail.com', 'Tamil', 'no'),
('Dr.M.Chandrasekaran', 'MECHANICAL-B', '1', 'GE3152', 'chandruchellam19@gmail.com', 'Tamil', 'no'),
('Dr.M.Chandrasekaran', 'EEE-B', '1', 'GE3152', 'chandruchellam19@gmail.com', 'Tamil', 'no'),
('Dr.M.Chandrasekaran', 'IT-B', '1', 'GE3152', 'chandruchellam19@gmail.com', 'Tamil', 'no'),
('Dr. V. R. Sarma Dhulipala', 'EEE-A', '1', 'PH3151', 'dvrsarma@aubit.edu.in', 'Physics', 'no'),
('Dr. V. R. Sarma Dhulipala', 'EEE-B', '1', 'PH3151', 'dvrsarma@aubit.edu.in', 'Physics', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `itacy3151`
--

CREATE TABLE `itacy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `itacy3151`
--

INSERT INTO `itacy3151` (`regno`, `name`, `cy3151_mark`, `cy3151_attendance`) VALUES
(810023205001, 'SURYA S', '45', 15),
(810023205002, 'NIRANJAN R', '88', 20),
(810023205003, 'GIRIJA K', '91', 20),
(810023205004, 'DHIVYA M', '80', 18),
(810023205005, 'SENTHAMIZHAN A', '73', 18),
(810023205006, 'KEERTHIVASAN P S', '85', 16),
(810023205007, 'PRAKASH M', '54', 18),
(810023205008, 'HARIHARAN T', '54', 18),
(810023205009, 'SIVA SANKAR V', '56', 14),
(810023205010, 'PUGAZHESHWARAN V', '51', 14),
(810023205011, 'VIGNESHWARAN S', '89', 18),
(810023205012, 'SATHIYA M', '96', 20),
(810023205013, 'AJAY D', '58', 16),
(810023205014, 'DHANALAKSHMI S', '57', 18),
(810023205015, 'DESIKA S', '78', 18),
(810023205016, 'GOVARDHAN S', '79', 16),
(810023205017, 'ABINAYA U', '94', 18),
(810023205018, 'JONES PRISTY D', '93', 18),
(810023205019, 'DHAARANYA S', '81', 18),
(810023205020, 'HARINI K', '96', 18),
(810023205021, 'ANTIN SHERIN V U', '91', 16),
(810023205022, 'BARATH R', '54', 18),
(810023205023, 'SAFILA FARHATH A S', '92', 18),
(810023205024, 'BHARATHI M', '67', 20),
(810023205025, 'ARCHANA J', '78', 20),
(810023205026, 'KAAVYA VARSHA R', '94', 18),
(810023205027, 'KARNIKA S', '90', 18),
(810023205028, 'JAYA BHARATHI S', '78', 20),
(810023205029, 'GUNAVARTHINI K', '66', 14),
(810023205030, 'DHANASEKAR K', '84', 16),
(810023205031, 'SURJITH S', '73', 20),
(810023205032, 'ANUSUYA V', '83', 20),
(810023205033, 'KEERTHIKA G B', '90', 20),
(810023205034, 'JANANI L', '68', 16),
(810023205035, 'PAVITHRA J', '93', 18),
(810023205036, 'PRAKASH S', '77', 18),
(810023205037, 'SWATHI K', '87', 20),
(810023205038, 'THEJASH S', '75', 18),
(810023205039, 'HARIKRISHNAN T', '88', 18),
(810023205040, 'RAJESHWARI P', '69', 20),
(810023205041, 'SARIHA S', '76', 16),
(810023205042, 'MANOBALA T N', '69', 16),
(810023205043, 'AJAY A', '74', 12),
(810023205044, 'MUHAMMED AARIF J', '73', 16),
(810023205045, 'ARUNKUMAR M', '67', 14),
(810023205046, 'NIRAIMATHI M', '80', 16),
(810023205047, 'HEYMANTH S M', '74', 20),
(810023205048, 'NIVEDHA M', '95', 16),
(810023205049, 'DEEPAN RAJA G', '86', 20),
(810023205050, 'ESSTHAR ANNAL J', '91', 18),
(810023205051, 'MOHAMED ISRIN A', '74', 20),
(810023205052, 'SRI RAGABHARATHI R', '71', 20),
(810023205053, 'ROJITH R A', '75', 16),
(810023205054, 'SINDHUJA S', '95', 20),
(810023205055, 'RAJIVI M', '63', 18),
(810023205056, 'LAKSHANA M', '87', 20),
(810023205057, 'VENMANI V', '85', 20),
(810023205058, 'PRAKASH S', '67', 18);

-- --------------------------------------------------------

--
-- Table structure for table `itage3151`
--

CREATE TABLE `itage3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `itage3151`
--

INSERT INTO `itage3151` (`regno`, `name`, `ge3151_mark`, `ge3151_attendance`) VALUES
(810023205001, 'SURYA S', '47', 16),
(810023205002, 'NIRANJAN R', '80', 19),
(810023205003, 'GIRIJA K', '89', 19),
(810023205004, 'DHIVYA M', '71', 19),
(810023205005, 'SENTHAMIZHAN A', '73', 19),
(810023205006, 'KEERTHIVASAN P S', '84', 18),
(810023205007, 'PRAKASH M', '64', 18),
(810023205008, 'HARIHARAN T', '69', 19),
(810023205009, 'SIVA SANKAR V', '67', 18),
(810023205010, 'PUGAZHESHWARAN V', '73', 19),
(810023205011, 'VIGNESHWARAN S', '86', 19),
(810023205012, 'SATHIYA M', '88', 19),
(810023205013, 'AJAY D', '56', 17),
(810023205014, 'DHANALAKSHMI S', '67', 15),
(810023205015, 'DESIKA S', '84', 19),
(810023205016, 'GOVARDHAN S', '76', 19),
(810023205017, 'ABINAYA U', '90', 19),
(810023205018, 'JONES PRISTY D', '92', 19),
(810023205019, 'DHAARANYA S', '90', 18),
(810023205020, 'HARINI K', '86', 18),
(810023205021, 'ANTIN SHERIN V U', '79', 19),
(810023205022, 'BARATH R', '64', 18),
(810023205023, 'SAFILA FARHATH A S', '80', 18),
(810023205024, 'BHARATHI M', '80', 19),
(810023205025, 'ARCHANA J', '82', 19),
(810023205026, 'KAAVYA VARSHA R', '90', 19),
(810023205027, 'KARNIKA S', '78', 19),
(810023205028, 'JAYA BHARATHI S', '84', 19),
(810023205029, 'GUNAVARTHINI K', '75', 17),
(810023205030, 'DHANASEKAR K', '79', 19),
(810023205031, 'SURJITH S', '72', 19),
(810023205032, 'ANUSUYA V', '89', 18),
(810023205033, 'KEERTHIKA G B', '86', 19),
(810023205034, 'JANANI L', '74', 16),
(810023205035, 'PAVITHRA J', '90', 19),
(810023205036, 'PRAKASH S', '82', 19),
(810023205037, 'SWATHI K', '82', 19),
(810023205038, 'THEJASH S', '81', 19),
(810023205039, 'HARIKRISHNAN T', '80', 19),
(810023205040, 'RAJESHWARI P', '84', 19),
(810023205041, 'SARIHA S', '82', 16),
(810023205042, 'MANOBALA T N', '88', 17),
(810023205043, 'AJAY A', '79', 15),
(810023205044, 'MUHAMMED AARIF J', '68', 19),
(810023205045, 'ARUNKUMAR M', '65', 19),
(810023205046, 'NIRAIMATHI M', '77', 16),
(810023205047, 'HEYMANTH S M', '79', 19),
(810023205048, 'NIVEDHA M', '80', 17),
(810023205049, 'DEEPAN RAJA G', '85', 19),
(810023205050, 'ESSTHAR ANNAL J', '88', 18),
(810023205051, 'MOHAMED ISRIN A', '78', 19),
(810023205052, 'SRI RAGABHARATHI R', '72', 15),
(810023205053, 'ROJITH R A', '84', 18),
(810023205054, 'SINDHUJA S', '85', 19),
(810023205055, 'RAJIVI M', '80', 19),
(810023205056, 'LAKSHANA M', '90', 19),
(810023205057, 'VENMANI V', '77', 18),
(810023205058, 'PRAKASH S', '70', 17);

-- --------------------------------------------------------

--
-- Table structure for table `itage3152`
--

CREATE TABLE `itage3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `itahs3152`
--

CREATE TABLE `itahs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `itahs3152`
--

INSERT INTO `itahs3152` (`regno`, `name`, `hs3152_mark`, `hs3152_attendance`) VALUES
(810023205001, 'SURYA S', '45', 21),
(810023205002, 'NIRANJAN R', '73', 23),
(810023205003, 'GIRIJA K', '72', 22),
(810023205004, 'DHIVYA M', '78', 21),
(810023205005, 'SENTHAMIZHAN A', '65', 21),
(810023205006, 'KEERTHIVASAN P S', '80', 21),
(810023205007, 'PRAKASH M', '62', 20),
(810023205008, 'HARIHARAN T', '66', 22),
(810023205009, 'SIVA SANKAR V', '63', 21),
(810023205010, 'PUGAZHESHWARAN V', '65', 21),
(810023205011, 'VIGNESHWARAN S', '70', 21),
(810023205012, 'SATHIYA M', '82', 23),
(810023205013, 'AJAY D', '65', 20),
(810023205014, 'DHANALAKSHMI S', '61', 16),
(810023205015, 'DESIKA S', '80', 22),
(810023205016, 'GOVARDHAN S', '70', 21),
(810023205017, 'ABINAYA U', '88', 22),
(810023205018, 'JONES PRISTY D', '79', 22),
(810023205019, 'DHAARANYA S', '70', 21),
(810023205020, 'HARINI K', '84', 21),
(810023205021, 'ANTIN SHERIN V U', '76', 22),
(810023205022, 'BARATH R', '71', 22),
(810023205023, 'SAFILA FARHATH A S', '78', 21),
(810023205024, 'BHARATHI M', '70', 23),
(810023205025, 'ARCHANA J', '84', 21),
(810023205026, 'KAAVYA VARSHA R', '87', 23),
(810023205027, 'KARNIKA S', '81', 23),
(810023205028, 'JAYA BHARATHI S', '73', 21),
(810023205029, 'GUNAVARTHINI K', '69', 19),
(810023205030, 'DHANASEKAR K', '70', 21),
(810023205031, 'SURJITH S', '72', 23),
(810023205032, 'ANUSUYA V', '76', 20),
(810023205033, 'KEERTHIKA G B', '66', 22),
(810023205034, 'JANANI L', '58', 18),
(810023205035, 'PAVITHRA J', '74', 22),
(810023205036, 'PRAKASH S', '74', 21),
(810023205037, 'SWATHI K', '77', 23),
(810023205038, 'THEJASH S', '67', 20),
(810023205039, 'HARIKRISHNAN T', '72', 21),
(810023205040, 'RAJESHWARI P', '65', 22),
(810023205041, 'SARIHA S', '72', 18),
(810023205042, 'MANOBALA T N', '76', 17),
(810023205043, 'AJAY A', '89', 15),
(810023205044, 'MUHAMMED AARIF J', '73', 21),
(810023205045, 'ARUNKUMAR M', '68', 19),
(810023205046, 'NIRAIMATHI M', '84', 18),
(810023205047, 'HEYMANTH S M', '76', 21),
(810023205048, 'NIVEDHA M', '72', 21),
(810023205049, 'DEEPAN RAJA G', '70', 22),
(810023205050, 'ESSTHAR ANNAL J', '71', 23),
(810023205051, 'MOHAMED ISRIN A', '70', 23),
(810023205052, 'SRI RAGABHARATHI R', '71', 17),
(810023205053, 'ROJITH R A', '76', 21),
(810023205054, 'SINDHUJA S', '84', 22),
(810023205055, 'RAJIVI M', '68', 21),
(810023205056, 'LAKSHANA M', '82', 22),
(810023205057, 'VENMANI V', '73', 17),
(810023205058, 'PRAKASH S', '70', 19);

-- --------------------------------------------------------

--
-- Table structure for table `itama3151`
--

CREATE TABLE `itama3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `itama3151`
--

INSERT INTO `itama3151` (`regno`, `name`, `ma3151_mark`, `ma3151_attendance`) VALUES
(810023205001, 'SURYA S', '53', 24),
(810023205002, 'NIRANJAN R', '80', 30),
(810023205003, 'GIRIJA K', '77', 31),
(810023205004, 'DHIVYA M', '41', 29),
(810023205005, 'SENTHAMIZHAN A', '64', 27),
(810023205006, 'KEERTHIVASAN P S', '69', 27),
(810023205007, 'PRAKASH M', '45', 27),
(810023205008, 'HARIHARAN T', '50', 28),
(810023205009, 'SIVA SANKAR V', '49', 24),
(810023205010, 'PUGAZHESHWARAN V', '63', 25),
(810023205011, 'VIGNESHWARAN S', '97', 27),
(810023205012, 'SATHIYA M', '99', 32),
(810023205013, 'AJAY D', '31', 27),
(810023205014, 'DHANALAKSHMI S', '34', 26),
(810023205015, 'DESIKA S', '69', 29),
(810023205016, 'GOVARDHAN S', '89', 26),
(810023205017, 'ABINAYA U', '94', 29),
(810023205018, 'JONES PRISTY D', '94', 29),
(810023205019, 'DHAARANYA S', '88', 30),
(810023205020, 'HARINI K', '88', 30),
(810023205021, 'ANTIN SHERIN V U', '61', 29),
(810023205022, 'BARATH R', '57', 28),
(810023205023, 'SAFILA FARHATH A S', '79', 30),
(810023205024, 'BHARATHI M', '64', 30),
(810023205025, 'ARCHANA J', '81', 31),
(810023205026, 'KAAVYA VARSHA R', '72', 31),
(810023205027, 'KARNIKA S', '74', 32),
(810023205028, 'JAYA BHARATHI S', '81', 31),
(810023205029, 'GUNAVARTHINI K', '52', 27),
(810023205030, 'DHANASEKAR K', '90', 26),
(810023205031, 'SURJITH S', '81', 30),
(810023205032, 'ANUSUYA V', '58', 27),
(810023205033, 'KEERTHIKA G B', '78', 31),
(810023205034, 'JANANI L', '71', 27),
(810023205035, 'PAVITHRA J', '76', 30),
(810023205036, 'PRAKASH S', '84', 29),
(810023205037, 'SWATHI K', '54', 32),
(810023205038, 'THEJASH S', '65', 29),
(810023205039, 'HARIKRISHNAN T', '93', 28),
(810023205040, 'RAJESHWARI P', '57', 31),
(810023205041, 'SARIHA S', '84', 26),
(810023205042, 'MANOBALA T N', '76', 25),
(810023205043, 'AJAY A', '55', 23),
(810023205044, 'MUHAMMED AARIF J', '62', 25),
(810023205045, 'ARUNKUMAR M', '31', 24),
(810023205046, 'NIRAIMATHI M', '53', 27),
(810023205047, 'HEYMANTH S M', '67', 28),
(810023205048, 'NIVEDHA M', '54', 28),
(810023205049, 'DEEPAN RAJA G', '78', 29),
(810023205050, 'ESSTHAR ANNAL J', '82', 30),
(810023205051, 'MOHAMED ISRIN A', '69', 30),
(810023205052, 'SRI RAGABHARATHI R', '86', 27),
(810023205053, 'ROJITH R A', '68', 26),
(810023205054, 'SINDHUJA S', '69', 31),
(810023205055, 'RAJIVI M', '39', 26),
(810023205056, 'LAKSHANA M', '80', 31),
(810023205057, 'VENMANI V', '72', 29),
(810023205058, 'PRAKASH S', '49', 24);

-- --------------------------------------------------------

--
-- Table structure for table `itaph3151`
--

CREATE TABLE `itaph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `itbcy3151`
--

CREATE TABLE `itbcy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `itbge3151`
--

CREATE TABLE `itbge3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `itbge3151`
--

INSERT INTO `itbge3151` (`regno`, `name`, `ge3151_mark`, `ge3151_attendance`) VALUES
(810023205059, 'KALAIYARASI M', '87', 14),
(810023205060, 'LOGESHKUMAR M', '82', 12),
(810023205061, 'SUGANTHAN R', '79', 12),
(810023205062, 'VIGNESHWARAN L', '81', 12),
(810023205063, 'SANTHOSH A', '77', 12),
(810023205064, 'MADHUMITHA R', '89', 12),
(810023205065, 'KEERTHANA', '86', 14),
(810023205066, 'KEERTHANA A', '87', 13),
(810023205067, 'GOMATHI R', '87', 13),
(810023205068, 'KEERTHANA R', '72', 10),
(810023205069, 'SARANRAJ R', '78', 11),
(810023205070, 'EZHILARASAN J', '73', 13),
(810023205071, 'DEEPADHARSHINI M', '86', 11),
(810023205072, 'SRINITHI S', '78', 12),
(810023205073, 'BHARATHI P', '74', 12),
(810023205074, 'SRIBALAJI G', '81', 14),
(810023205075, 'RAHUL K', '69', 8),
(810023205076, 'ARJUN C', '82', 11),
(810023205077, 'SIVAPRASANTH', '67', 8),
(810023205078, 'PRICIKA K', '73', 13),
(810023205079, 'SRIMATHI J', '63', 10),
(810023205081, 'ABITHADEVI R', '88', 12),
(810023205082, 'MOHANRAJ V', '71', 12),
(810023205083, 'JANANI S', '67', 13),
(810023205084, 'AKSHAYA S', '59', 9),
(810023205085, 'LAVANYA A', '50', 5),
(810023205086, 'SUVARNALEKHAA N', '75', 13),
(810023205087, 'KESAVAN E', '78', 12),
(810023205088, 'BHAVADHARANI B', '82', 11),
(810023205089, 'LAVANYA D', '71', 14),
(810023205090, 'SANTHIYA E', '84', 14),
(810023205091, 'RANGANATHAN M', '73', 10),
(810023205092, 'JAI AAKASH R', '71', 10),
(810023205093, 'KARTHIKEYAN H', '73', 13),
(810023205094, 'JANAHAN E', '84', 12),
(810023205095, 'MANOJ C', '79', 14),
(810023205096, 'YOGESH U G', '81', 14),
(810023205097, 'JANARANJANI M', '83', 14),
(810023205098, 'ABISHEK K', '76', 14),
(810023205099, 'HARINI S', '85', 12),
(810023205100, 'MARY SHALINI A', '84', 14),
(810023205101, 'SATHYASEELAN', '70', 9),
(810023205102, 'VARSHA T', '77', 14),
(810023205103, 'KISHORE R', '66', 10),
(810023205104, 'AHAMED NOOR Z', '63', 10),
(810023205105, 'SANGEETHA M', '81', 10),
(810023205106, 'ANBUKUMAR M', '81', 13),
(810023205107, 'RAVINASRI R', '79', 13),
(810023205108, 'MARUTHAKUMARAN M', '73', 14),
(810023205110, 'MANIKANDAN', '77', 9),
(810023205111, 'NAVEEN M', '78', 12),
(810023205112, 'SIVABALAN S', '66', 8),
(810023205113, 'KAVINRAJAN K', '49', 10),
(810023205114, 'ELAIYAMUGILAN S', '82', 14),
(810023205115, 'HITHESH K', '64', 11),
(810023205116, 'GOKULNATH V', '59', 9);

-- --------------------------------------------------------

--
-- Table structure for table `itbge3152`
--

CREATE TABLE `itbge3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `itbhs3152`
--

CREATE TABLE `itbhs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `itbhs3152`
--

INSERT INTO `itbhs3152` (`regno`, `name`, `hs3152_mark`, `hs3152_attendance`) VALUES
(810023205059, 'KALAIYARASI M', '69', 21),
(810023205060, 'LOGESHKUMAR M', '72', 16),
(810023205061, 'SUGANTHAN R', '75', 15),
(810023205062, 'VIGNESHWARAN L', '70', 15),
(810023205063, 'SANTHOSH A', '79', 17),
(810023205064, 'MADHUMITHA R', '82', 17),
(810023205065, 'KEERTHANA', '65', 21),
(810023205066, 'KEERTHANA A', '74', 20),
(810023205067, 'GOMATHI R', '72', 19),
(810023205068, 'KEERTHANA R', '68', 15),
(810023205069, 'SARANRAJ R', '63', 15),
(810023205070, 'EZHILARASAN J', '73', 16),
(810023205071, 'DEEPADHARSHINI M', '78', 16),
(810023205072, 'SRINITHI S', '71', 17),
(810023205073, 'BHARATHI P', '70', 18),
(810023205074, 'SRIBALAJI G', '66', 19),
(810023205075, 'RAHUL K', '79', 12),
(810023205076, 'ARJUN C', '71', 15),
(810023205077, 'SIVAPRASANTH', '69', 13),
(810023205078, 'PRICIKA K', '65', 19),
(810023205079, 'SRIMATHI J', '65', 16),
(810023205081, 'ABITHADEVI R', '66', 20),
(810023205082, 'MOHANRAJ V', '65', 18),
(810023205083, 'JANANI S', '70', 17),
(810023205084, 'AKSHAYA S', '73', 13),
(810023205085, 'LAVANYA A', '60', 8),
(810023205086, 'SUVARNALEKHAA N', '86', 18),
(810023205087, 'KESAVAN E', '70', 19),
(810023205088, 'BHAVADHARANI B', '81', 19),
(810023205089, 'LAVANYA D', '64', 21),
(810023205090, 'SANTHIYA E', '69', 19),
(810023205091, 'RANGANATHAN M', '66', 16),
(810023205092, 'JAI AAKASH R', '45', 10),
(810023205093, 'KARTHIKEYAN H', '80', 16),
(810023205094, 'JANAHAN E', '86', 15),
(810023205095, 'MANOJ C', '77', 21),
(810023205096, 'YOGESH U G', '71', 19),
(810023205097, 'JANARANJANI M', '76', 19),
(810023205098, 'ABISHEK K', '69', 18),
(810023205099, 'HARINI S', '72', 18),
(810023205100, 'MARY SHALINI A', '62', 19),
(810023205101, 'SATHYASEELAN', '67', 12),
(810023205102, 'VARSHA T', '79', 18),
(810023205103, 'KISHORE R', '74', 15),
(810023205104, 'AHAMED NOOR Z', '80', 17),
(810023205105, 'SANGEETHA M', '69', 18),
(810023205106, 'ANBUKUMAR M', '75', 16),
(810023205107, 'RAVINASRI R', '70', 17),
(810023205108, 'MARUTHAKUMARAN M', '72', 20),
(810023205110, 'MANIKANDAN', '63', 9),
(810023205111, 'NAVEEN M', '70', 13),
(810023205112, 'SIVABALAN S', '60', 17),
(810023205113, 'KAVINRAJAN K', '51', 14),
(810023205114, 'ELAIYAMUGILAN S', '67', 18),
(810023205115, 'HITHESH K', '71', 18),
(810023205116, 'GOKULNATH V', '54', 15);

-- --------------------------------------------------------

--
-- Table structure for table `itbma3151`
--

CREATE TABLE `itbma3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `itbph3151`
--

CREATE TABLE `itbph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('Firstyearcoordinator', 'November@2022');

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalacy3151`
--

CREATE TABLE `mechanicalacy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalage3151`
--

CREATE TABLE `mechanicalage3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalage3152`
--

CREATE TABLE `mechanicalage3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mechanicalage3152`
--

INSERT INTO `mechanicalage3152` (`regno`, `name`, `ge3152_mark`, `ge3152_attendance`) VALUES
(810023114001, 'ACACIO D', '60', 7),
(810023114002, 'SAMBATHKUMAR M', '45', 8),
(810023114003, 'ABINATH K', '60', 5),
(810023114004, 'SANKARANARAYANAN G', '69', 7),
(810023114005, 'RATHNA R', '86', 6),
(810023114006, 'MUGESH K', '67', 8),
(810023114007, 'RAHUL R', '85', 8),
(810023114008, 'MOHAMED SHAFIK R', '75', 8),
(810023114009, 'JAYARAJ A', '74', 8),
(810023114010, 'SUDHAKARAN S', '82', 7),
(810023114011, 'SAKTHIVEL V', '73', 8),
(810023114012, 'SANJAY K', '76', 7),
(810023114013, 'BHUVANESAN NV', '59', 7),
(810023114014, 'PERIYA ARASU M', '80', 8),
(810023114015, 'GIRIDHARAN G', '58', 7),
(810023114016, 'DHARSHINI M', '92', 6),
(810023114017, 'MAGI AGNUS P', '56', 6),
(810023114018, 'RAJADURAI D', '70', 7),
(810023114019, 'SUSHVANTH S', '83', 7),
(810023114020, 'RANJITH M', '75', 8),
(810023114021, 'KAMALAKKANNAN P', '64', 7),
(810023114022, 'SUBRAMANI K', '66', 8),
(810023114023, 'MOHANSELVAKUMAR P', '80', 7),
(810023114024, 'BALAJI K', '74', 8),
(810023114025, 'MUGESH S', '76', 8),
(810023114026, 'NISHANTH S', '70', 7),
(810023114027, 'NITHIN S', '60', 7),
(810023114028, 'BEER MOHAMED N', '73', 7),
(810023114029, 'BOOBALAN E', '77', 7),
(810023114030, 'VIGNESHWARAN S', '64', 8),
(810023114031, 'BHARANIVASAN T', '80', 8),
(810023114032, 'ROHESHWARAN S', '66', 8),
(810023114033, 'KAVI BHARATHI M', '67', 8),
(810023114034, 'DHINESHKUMAR G', '60', 7),
(810023114035, 'MOHAN G', '56', 6),
(810023114036, 'HARIGOVINDAN S', '56', 7),
(810023114037, 'SURAJ R', '71', 5),
(810023114038, 'AUSTIN S', '65', 7),
(810023114039, 'VINOTH KUMAR M', '61', 8),
(810023114040, 'KARTHIKEYAN B', '61', 8),
(810023114041, 'RAKSHITHA V', '88', 6),
(810023114042, 'SURJITH R S', '76', 8),
(810023114043, 'JEEVAA M', '60', 7),
(810023114044, 'MITHUN S', '80', 7),
(810023114045, 'BHARANIMUTHU V', '66', 8),
(810023114046, 'GURUMOORTHI M', '74', 8),
(810023114047, 'AKASH B', '68', 8),
(810023114048, 'PRAVINKUMAR B', '70', 6),
(810023114049, 'SHANJAI SRI RAM S', '66', 8),
(810023114050, 'RATHINAVEL S', '78', 7),
(810023114051, 'PREMKUMAR S', '67', 8),
(810023114052, 'THASEER ALI J', '61', 7);

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalahs3152`
--

CREATE TABLE `mechanicalahs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mechanicalahs3152`
--

INSERT INTO `mechanicalahs3152` (`regno`, `name`, `hs3152_mark`, `hs3152_attendance`) VALUES
(810023114001, 'ACACIO D', '59', 17),
(810023114002, 'SAMBATHKUMAR M', '51', 20),
(810023114003, 'ABINATH K', '54', 13),
(810023114004, 'SANKARANARAYANAN G', '73', 16),
(810023114005, 'RATHNA R', '63', 18),
(810023114006, 'MUGESH K', '75', 19),
(810023114007, 'RAHUL R', '72', 20),
(810023114008, 'MOHAMED SHAFIK R', '65', 20),
(810023114009, 'JAYARAJ A', '61', 19),
(810023114010, 'SUDHAKARAN S', '57', 16),
(810023114011, 'SAKTHIVEL V', '69', 16),
(810023114012, 'SANJAY K', '69', 16),
(810023114013, 'BHUVANESAN NV', '59', 17),
(810023114014, 'PERIYA ARASU M', '70', 18),
(810023114015, 'GIRIDHARAN G', '62', 17),
(810023114016, 'DHARSHINI M', '76', 16),
(810023114017, 'MAGI AGNUS P', '73', 13),
(810023114018, 'RAJADURAI D', '52', 18),
(810023114019, 'SUSHVANTH S', '55', 17),
(810023114020, 'RANJITH M', '77', 14),
(810023114021, 'KAMALAKKANNAN P', '62', 15),
(810023114022, 'SUBRAMANI K', '60', 17),
(810023114023, 'MOHANSELVAKUMAR P', '59', 16),
(810023114024, 'BALAJI K', '72', 16),
(810023114025, 'MUGESH S', '62', 16),
(810023114026, 'NISHANTH S', '68', 16),
(810023114027, 'NITHIN S', '62', 15),
(810023114028, 'BEER MOHAMED N', '68', 14),
(810023114029, 'BOOBALAN E', '74', 15),
(810023114030, 'VIGNESHWARAN S', '69', 14),
(810023114031, 'BHARANIVASAN T', '87', 17),
(810023114032, 'ROHESHWARAN S', '69', 20),
(810023114033, 'KAVI BHARATHI M', '66', 17),
(810023114034, 'DHINESHKUMAR G', '67', 16),
(810023114035, 'MOHAN G', '56', 11),
(810023114036, 'HARIGOVINDAN S', '61', 10),
(810023114037, 'SURAJ R', '71', 14),
(810023114038, 'AUSTIN S', '62', 14),
(810023114039, 'VINOTH KUMAR M', '67', 18),
(810023114040, 'KARTHIKEYAN B', '72', 14),
(810023114041, 'RAKSHITHA V', '82', 13),
(810023114042, 'SURJITH R S', '72', 19),
(810023114043, 'JEEVAA M', '58', 18),
(810023114044, 'MITHUN S', '57', 18),
(810023114045, 'BHARANIMUTHU V', '58', 14),
(810023114046, 'GURUMOORTHI M', '64', 18),
(810023114047, 'AKASH B', '67', 14),
(810023114048, 'PRAVINKUMAR B', '72', 17),
(810023114049, 'SHANJAI SRI RAM S', '65', 15),
(810023114050, 'RATHINAVEL S', '70', 17),
(810023114051, 'PREMKUMAR S', '71', 18),
(810023114052, 'THASEER ALI J', '61', 16);

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalama3151`
--

CREATE TABLE `mechanicalama3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mechanicalama3151`
--

INSERT INTO `mechanicalama3151` (`regno`, `name`, `ma3151_mark`, `ma3151_attendance`) VALUES
(810023114001, 'ACACIO D', '52', 24),
(810023114002, 'SAMBATHKUMAR M', '50', 28),
(810023114003, 'ABINATH K', '40', 20),
(810023114004, 'SANKARANARAYANAN G', '52', 26),
(810023114005, 'RATHNA R', '66', 25),
(810023114006, 'MUGESH K', '71', 30),
(810023114007, 'RAHUL R', '63', 30),
(810023114008, 'MOHAMED SHAFIK R', '80', 30),
(810023114009, 'JAYARAJ A', '67', 28),
(810023114010, 'SUDHAKARAN S', '51', 24),
(810023114011, 'SAKTHIVEL V', '56', 24),
(810023114012, 'SANJAY K', '76', 26),
(810023114013, 'BHUVANESAN NV', '57', 28),
(810023114014, 'PERIYA ARASU M', '47', 26),
(810023114015, 'GIRIDHARAN G', '53', 22),
(810023114016, 'DHARSHINI M', '85', 28),
(810023114017, 'MAGI AGNUS P', '58', 18),
(810023114018, 'RAJADURAI D', '70', 30),
(810023114019, 'SUSHVANTH S', '86', 28),
(810023114020, 'RANJITH M', '68', 26),
(810023114021, 'KAMALAKKANNAN P', '80', 28),
(810023114022, 'SUBRAMANI K', '56', 28),
(810023114023, 'MOHANSELVAKUMAR P', '60', 28),
(810023114024, 'BALAJI K', '70', 28),
(810023114025, 'MUGESH S', '62', 28),
(810023114026, 'NISHANTH S', '57', 24),
(810023114027, 'NITHIN S', '55', 22),
(810023114028, 'BEER MOHAMED N', '67', 24),
(810023114029, 'BOOBALAN E', '57', 28),
(810023114030, 'VIGNESHWARAN S', '58', 20),
(810023114031, 'BHARANIVASAN T', '59', 26),
(810023114032, 'ROHESHWARAN S', '52', 30),
(810023114033, 'KAVI BHARATHI M', '56', 26),
(810023114034, 'DHINESHKUMAR G', '54', 28),
(810023114035, 'MOHAN G', '54', 22),
(810023114036, 'HARIGOVINDAN S', '55', 18),
(810023114037, 'SURAJ R', '57', 20),
(810023114038, 'AUSTIN S', '58', 20),
(810023114039, 'VINOTH KUMAR M', '68', 28),
(810023114040, 'KARTHIKEYAN B', '73', 26),
(810023114041, 'RAKSHITHA V', '87', 16),
(810023114042, 'SURJITH R S', '83', 28),
(810023114043, 'JEEVAA M', '55', 28),
(810023114044, 'MITHUN S', '40', 28),
(810023114045, 'BHARANIMUTHU V', '63', 26),
(810023114046, 'GURUMOORTHI M', '65', 30),
(810023114047, 'AKASH B', '57', 26),
(810023114048, 'PRAVINKUMAR B', '70', 28),
(810023114049, 'SHANJAI SRI RAM S', '50', 28),
(810023114050, 'RATHINAVEL S', '61', 28),
(810023114051, 'PREMKUMAR S', '45', 26),
(810023114052, 'THASEER ALI J', '43', 17);

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalaph3151`
--

CREATE TABLE `mechanicalaph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalbcy3151`
--

CREATE TABLE `mechanicalbcy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalbge3151`
--

CREATE TABLE `mechanicalbge3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalbge3152`
--

CREATE TABLE `mechanicalbge3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalbhs3152`
--

CREATE TABLE `mechanicalbhs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalbma3151`
--

CREATE TABLE `mechanicalbma3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mechanicalbma3151`
--

INSERT INTO `mechanicalbma3151` (`regno`, `name`, `ma3151_mark`, `ma3151_attendance`) VALUES
(810023114054, 'AKASH M K', '70', 30),
(810023114055, 'BARATH KUMARAN E', '54', 25),
(810023114056, 'THIRUMOORTHI A', '46', 30),
(810023114057, 'DHARANI T', '42', 30),
(810023114058, 'MOHAMED REAYAS A', '44', 26),
(810023114059, 'DEVANESAN B', '57', 30),
(810023114060, 'SRIDHAR T', '43', 26),
(810023114061, 'SATHISH KUMAR G', '99', 28),
(810023114062, 'JEGATHEESWARAN T', '43', 16),
(810023114063, 'HARI PRASATH P', '48', 30),
(810023114064, 'MOUNIKA M', '49', 30),
(810023114065, 'KRISHNAKUMAR S', '40', 25),
(810023114066, 'PON AKASH P', '46', 30),
(810023114067, 'ATHARSH P', '64', 30),
(810023114068, 'MANIKANDAN K', '56', 23),
(810023114069, 'KAVIARASAN T', '67', 28),
(810023114070, 'DHILIP A', '46', 28),
(810023114071, 'MAHADEVAN V', '43', 23),
(810023114072, 'PRABANJAN P S', '46', 30),
(810023114073, 'NAVEEN KUMAR R', '40', 24),
(810023114074, 'SUTHARSAN B', '40', 18),
(810023114075, 'AKASH M', '49', 26),
(810023114076, 'VIKRAM S', '46', 27),
(810023114077, 'VISHNU S', '54', 27),
(810023114078, 'LENISH P', '59', 21),
(810023114079, 'BALAJI V', '49', 23),
(810023114080, 'BALA CHANDAR P', '48', 21),
(810023114081, 'GOKUL A', '47', 21),
(810023114082, 'JANA MURUGAPPA M', '45', 30),
(810023114083, 'ROSHAN FARITH S', '57', 21),
(810023114084, 'SIVABALAN K', '55', 28),
(810023114085, 'VIJAYARAJ K R', '55', 30),
(810023114086, 'SHANMUGANATHAN S', '44', 28),
(810023114087, 'NISHANTH KUMAR K', '42', 28),
(810023114088, 'NARESHKUMAR S', '42', 19),
(810023114089, 'GOBINATH R', '44', 24),
(810023114090, 'AMALESH A', '58', 28),
(810023114091, 'AATHIKESAVAN K', '42', 25),
(810023114092, 'SAMITH KANNA R', '45', 26),
(810023114093, 'BOOBALAN R', '43', 21),
(810023114094, 'NAVEEN B', '45', 23),
(810023114096, 'DEV ANAND K', '40', 26),
(810023114097, 'VIGNESH K', '53', 27),
(810023114098, 'JEEVANANTHAM M', '54', 30),
(810023114099, 'JAMERAJ S', '40', 24),
(810023114100, 'RAKESHKUMAR M', '40', 10),
(810023114102, 'ALAGUPRIYAN A', '40', 14),
(810023114103, 'PASUPATHI T', '50', 20),
(810023114104, 'SANTHOSH M', '40', 23),
(810023114106, 'INBARASAN K', '40', 27);

-- --------------------------------------------------------

--
-- Table structure for table `mechanicalbph3151`
--

CREATE TABLE `mechanicalbph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `petrocy3151`
--

CREATE TABLE `petrocy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `petroge3151`
--

CREATE TABLE `petroge3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `petroge3151`
--

INSERT INTO `petroge3151` (`regno`, `name`, `ge3151_mark`, `ge3151_attendance`) VALUES
(810023239001, 'KARNA P', '53', 19),
(810023239002, 'NITHYA SHREE R', '79', 17),
(810023239003, 'NAVEEN KUMAR M', '79', 16),
(810023239004, 'PRIYADHARSHINI U', '82', 18),
(810023239005, 'ARUL SELVAN A', '81', 18),
(810023239006, 'ANTO MIC JERSON G', '64', 16),
(810023239007, 'SWETHA S', '62', 15),
(810023239008, 'NITHIYANANTHA B', '58', 12),
(810023239009, 'RESHMA J', '75', 17),
(810023239010, 'VISHANTH D', '82', 19),
(810023239011, 'KARTHIKA K', '86', 18),
(810023239012, 'PRIYATHARSHINI G', '76', 18),
(810023239013, 'ARAVINDH A', '59', 17),
(810023239014, 'RAMYA R', '73', 19),
(810023239015, 'ANBUCHELVAN S', '79', 19),
(810023239016, 'VIMALRAJ S', '66', 17),
(810023239017, 'LAKSHMANAN T', '69', 16),
(810023239018, 'RAMKUMAR S', '85', 18),
(810023239019, 'NAVDEEP S', '62', 16),
(810023239020, 'AVINASH PG', '90', 17),
(810023239021, 'HARINI LAKSHMI K', '84', 16),
(810023239022, 'DHARSHAN M S', '81', 17),
(810023239023, 'RIYAS MOHAMED S', '62', 17),
(810023239024, 'SRIRAM K', '67', 17),
(810023239025, 'ROJITHMANI S', '76', 16),
(810023239026, 'KISOTH KUMAR S', '74', 17),
(810023239027, 'VIDYACHARAN S', '75', 16),
(810023239028, 'HARINI V', '77', 17),
(810023239029, 'IDHAYA RANJAN I', '61', 15),
(810023239030, 'ASEENA FATHIMA S', '76', 17),
(810023239031, 'CHANDRU M', '56', 17),
(810023239032, 'KAVIYA M', '65', 17),
(810023239033, 'MATHIARASU M', 'ab', 0),
(810023239034, 'SWETHA R U', '83', 18),
(810023239035, 'ABINAYA SRI M', '72', 17),
(810023239036, 'MOHAMMED MAHMOOD M', '63', 18),
(810023239037, 'SOORYA T', '57', 16),
(810023239038, 'SUDHARSAN B', '60', 17),
(810023239039, 'MADESH P', '60', 17),
(810023239040, 'BHARATH R', '65', 18),
(810023239041, 'DISHYAMENAN R', '50', 13),
(810023239042, 'RAKESH KUMAR M', '53', 18),
(810023239043, 'VIGNESH S', '60', 19),
(810023239044, 'HARIHARAN R', '60', 18),
(810023239045, 'VISWA P', '54', 18),
(810023239047, 'AAKASH M', '50', 15),
(810023239048, 'SWETHA S', '75', 19),
(810023239049, 'VISHWA M', '73', 16),
(810023239050, 'PARASURAMAN B', '67', 18),
(810023239051, 'VIJAYALAKSHMI K', '69', 16),
(810023239052, 'DARSHAN B', '57', 11),
(810023239053, 'KARTHI KEYAN M', '50', 18);

-- --------------------------------------------------------

--
-- Table structure for table `petroge3152`
--

CREATE TABLE `petroge3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `petrohs3152`
--

CREATE TABLE `petrohs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `petrohs3152`
--

INSERT INTO `petrohs3152` (`regno`, `name`, `hs3152_mark`, `hs3152_attendance`) VALUES
(810023239001, 'KARNA P', '12', 23),
(810023239002, 'NITHYA SHREE R', '52', 23),
(810023239003, 'NAVEEN KUMAR M', '60', 22),
(810023239004, 'PRIYADHARSHINI U', '52', 22),
(810023239005, 'ARUL SELVAN A', '68', 21),
(810023239006, 'ANTO MIC JERSON G', '18', 22),
(810023239007, 'SWETHA S', '55', 22),
(810023239008, 'NITHIYANANTHA B', '41', 19),
(810023239009, 'RESHMA J', '88', 23),
(810023239010, 'VISHANTH D', '55', 22),
(810023239011, 'KARTHIKA K', '64', 22),
(810023239012, 'PRIYATHARSHINI G', '50', 23),
(810023239013, 'ARAVINDH A', '40', 20),
(810023239014, 'RAMYA R', '50', 23),
(810023239015, 'ANBUCHELVAN S', '52', 22),
(810023239016, 'VIMALRAJ S', '13', 22),
(810023239017, 'LAKSHMANAN T', '50', 22),
(810023239018, 'RAMKUMAR S', '50', 22),
(810023239019, 'NAVDEEP S', '50', 19),
(810023239020, 'AVINASH PG', '68', 23),
(810023239021, 'HARINI LAKSHMI K', '53', 21),
(810023239022, 'DHARSHAN M S', '65', 21),
(810023239023, 'RIYAS MOHAMED S', '50', 24),
(810023239024, 'SRIRAM K', '50', 22),
(810023239025, 'ROJITHMANI S', '53', 19),
(810023239026, 'KISOTH KUMAR S', '54', 23),
(810023239027, 'VIDYACHARAN S', '80', 23),
(810023239028, 'HARINI V', '59', 22),
(810023239029, 'IDHAYA RANJAN I', '20', 18),
(810023239030, 'ASEENA FATHIMA S', '50', 22),
(810023239031, 'CHANDRU M', '50', 21),
(810023239032, 'KAVIYA M', '50', 22),
(810023239033, 'MATHIARASU M', '0', 0),
(810023239034, 'SWETHA R U', '50', 23),
(810023239035, 'ABINAYA SRI M', '51', 23),
(810023239036, 'MOHAMMED MAHMOOD M', '59', 23),
(810023239037, 'SOORYA T', '50', 23),
(810023239038, 'SUDHARSAN B', '38', 21),
(810023239039, 'MADESH P', '60', 21),
(810023239040, 'BHARATH R', '53', 17),
(810023239041, 'DISHYAMENAN R', '12', 18),
(810023239042, 'RAKESH KUMAR M', '43', 23),
(810023239043, 'VIGNESH S', '43', 22),
(810023239044, 'HARIHARAN R', '42', 23),
(810023239045, 'VISWA P', '42', 22),
(810023239047, 'AAKASH M', '10', 18),
(810023239048, 'SWETHA S', '50', 22),
(810023239049, 'VISHWA M', '81', 21),
(810023239050, 'PARASURAMAN B', '59', 21),
(810023239051, 'VIJAYALAKSHMI K', '50', 20),
(810023239052, 'DARSHAN B', '50', 16),
(810023239053, 'KARTHI KEYAN M', '50', 24);

-- --------------------------------------------------------

--
-- Table structure for table `petroma3151`
--

CREATE TABLE `petroma3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `petroph3151`
--

CREATE TABLE `petroph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy3151`
--

CREATE TABLE `pharmacy3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cy3151_mark` varchar(11) DEFAULT NULL,
  `cy3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharmage3151`
--

CREATE TABLE `pharmage3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3151_mark` varchar(11) DEFAULT NULL,
  `ge3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pharmage3151`
--

INSERT INTO `pharmage3151` (`regno`, `name`, `ge3151_mark`, `ge3151_attendance`) VALUES
(810023237001, 'SHYJU WILSON R', '92', 21),
(810023237002, 'PODHIGAI THENDRAL K', '92', 20),
(810023237003, 'SRINITHI S', '93', 20),
(810023237004, 'DHURAI KALIRAJ M', '74', 21),
(810023237005, 'NIHITHA A', '63', 18),
(810023237006, 'YUVASRII R N', '91', 21),
(810023237007, 'PUSHPA V', '62', 19),
(810023237008, 'ARUN EDWIN Y', '63', 18),
(810023237009, 'DHARSHINI TR', '74', 21),
(810023237011, 'KRISHNASOMI S', '70', 21),
(810023237012, 'SOWMIYA M', '78', 20),
(810023237013, 'BHUVANESHWARI V', '71', 20),
(810023237014, 'VIJAY S', '57', 16),
(810023237015, 'ANANTH B', '53', 19),
(810023237016, 'ASHIK SANDHIYAGU J', '65', 15),
(810023237018, 'SANTHOSH R', '54', 18),
(810023237019, 'KRISHNA DHARA S', '73', 19),
(810023237020, 'RENUGADEVI M', '67', 16),
(810023237021, 'AMIRTHA SRI R', '77', 19),
(810023237022, 'HARINI M', '74', 18),
(810023237023, 'GOWNITHA N', '77', 15),
(810023237024, 'HARI SUDHARSAN S', '64', 22),
(810023237025, 'MUTHUMARI B', '76', 15),
(810023237026, 'AARTHI B', '74', 18),
(810023237028, 'AKILANDESHWARI S', '78', 18),
(810023237029, 'YOGESHWARI M', '79', 16),
(810023237030, 'SIVABHARATHI', '65', 17),
(810023237031, 'MEGANATHAN J', '50', 16),
(810023237032, 'THENMOZHI R', '70', 18),
(810023237033, 'PAVITHRA B', '82', 18),
(810023237034, 'SAMYUKTHA M S', '72', 19),
(810023237035, 'HEMALEKHAA G M', '63', 21),
(810023237036, 'VETHA VARSHINI K G', '64', 16),
(810023237037, 'HARIHARAN K', '73', 20),
(810023237038, 'AATHITHYA M', '75', 19),
(810023237039, 'ASMIYA M', '81', 19),
(810023237040, 'POORNITHA B', '69', 19),
(810023237041, 'SRIRAM C', '59', 19),
(810023237042, 'SHRI HARINI C', '80', 19),
(810023237043, 'KIRUBA S', '75', 18),
(810023237044, 'MADHUMITHA K', '72', 20),
(810023237045, 'KARTHIGA DEVI M', '61', 20),
(810023237046, 'JEETIKA S', '63', 19),
(810023237047, 'DHINESHKUMAR N', '57', 21),
(810023237048, 'JOTHEESHWARAN I', '56', 20),
(810023237049, 'NAOFIL ADAM M', '75', 21),
(810023237050, 'HASHINI C', '76', 21),
(810023237051, 'HARINI SRI B', '70', 19),
(810023237052, 'SWETHA S', '77', 18),
(810023237053, 'PRADEEP KUMAR M', '63', 16),
(810023237054, 'HAARES KANNAN G', '54', 17);

-- --------------------------------------------------------

--
-- Table structure for table `pharmage3152`
--

CREATE TABLE `pharmage3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ge3152_mark` varchar(11) DEFAULT NULL,
  `ge3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharmahs3152`
--

CREATE TABLE `pharmahs3152` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `hs3152_mark` varchar(11) DEFAULT NULL,
  `hs3152_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharmama3151`
--

CREATE TABLE `pharmama3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ma3151_mark` varchar(11) DEFAULT NULL,
  `ma3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharmaph3151`
--

CREATE TABLE `pharmaph3151` (
  `regno` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ph3151_mark` varchar(11) DEFAULT NULL,
  `ph3151_attendance` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `studentdetails`
--

CREATE TABLE `studentdetails` (
  `name` varchar(50) NOT NULL,
  `dob` text NOT NULL,
  `regno` bigint(13) NOT NULL,
  `dept` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studentdetails`
--

INSERT INTO `studentdetails` (`name`, `dob`, `regno`, `dept`) VALUES
('SRINATH A M', '2005-06-17', 810023102001, 'AUTOMOBILE'),
('AYYANAR S', '2006-06-06', 810023102002, 'AUTOMOBILE'),
('AJITHKUMAR P', '2005-04-16', 810023102003, 'AUTOMOBILE'),
('BALAMURUGAN T', '2005-10-02', 810023102004, 'AUTOMOBILE'),
('SAKTHIVEL R', '2006-05-24', 810023102005, 'AUTOMOBILE'),
('BHUVANESHKUMAR K', '2006-05-10', 810023102006, 'AUTOMOBILE'),
('GAYATHRI J', '2005-09-24', 810023102007, 'AUTOMOBILE'),
('THILLAIKANNAN M', '2004-09-19', 810023102008, 'AUTOMOBILE'),
('KRISHNAMOORTHI S', '2006-01-29', 810023102009, 'AUTOMOBILE'),
('VISHVABHARATHI S', '2006-05-23', 810023102010, 'AUTOMOBILE'),
('SIVAKUMAR M', '2006-06-18', 810023102011, 'AUTOMOBILE'),
('JEYA SRI P', '2005-11-30', 810023102012, 'AUTOMOBILE'),
('GIRIVASAN A', '2006-01-31', 810023102013, 'AUTOMOBILE'),
('SATHAIAH G', '2006-07-19', 810023102014, 'AUTOMOBILE'),
('TAMILNILAVAN V', '2005-09-23', 810023102015, 'AUTOMOBILE'),
('SANTHOSH E', '2006-08-07', 810023102016, 'AUTOMOBILE'),
('FAZIL AHMAD M', '2005-09-13', 810023102017, 'AUTOMOBILE'),
('ARUNMOZHIVARMAN A', '2005-12-15', 810023102018, 'AUTOMOBILE'),
('HARIPRASATH E', '2006-03-25', 810023102019, 'AUTOMOBILE'),
('VELAVAN G', '2006-04-04', 810023102020, 'AUTOMOBILE'),
('JOSEPH VIJAY D', '2005-11-09', 810023102021, 'AUTOMOBILE'),
('IRANIYAN K', '2006-12-25', 810023102022, 'AUTOMOBILE'),
('VICKNESWARAN P', '2006-06-01', 810023102023, 'AUTOMOBILE'),
('JABAZ RAJA PANDIAN R', '2006-04-02', 810023102024, 'AUTOMOBILE'),
('SENTHIL R', '2005-12-12', 810023102025, 'AUTOMOBILE'),
('SELVAPRIYAN M', '2006-08-15', 810023102026, 'AUTOMOBILE'),
('PRADEEP V', '2006-04-13', 810023102028, 'AUTOMOBILE'),
('DINESH KUMAR P', '2005-12-27', 810023102029, 'AUTOMOBILE'),
('VISHVA H', '2006-04-13', 810023102030, 'AUTOMOBILE'),
('LOHITHRAAJ S', '2006-03-04', 810023102031, 'AUTOMOBILE'),
('KUMARAN S', '2006-02-09', 810023102032, 'AUTOMOBILE'),
('MEDWIN SAMUEL P', '2006-02-14', 810023102033, 'AUTOMOBILE'),
('GOWTHAM U', '2006-04-05', 810023102034, 'AUTOMOBILE'),
('AMIRTHA MARDHINI R', '2005-10-04', 810023102035, 'AUTOMOBILE'),
('CHAITANYA SUZI S', '2005-05-07', 810023102036, 'AUTOMOBILE'),
('AJAY M', '2005-09-30', 810023102037, 'AUTOMOBILE'),
('JEEVA N', '2006-10-29', 810023103001, 'CIVIL-A'),
('JAYASHREE N', '2005-09-09', 810023103002, 'CIVIL-A'),
('NADHIYA T', '2005-12-28', 810023103003, 'CIVIL-A'),
('YUVASHREE G', '2005-08-15', 810023103004, 'CIVIL-A'),
('KAVIRAJAN K', '2006-02-09', 810023103005, 'CIVIL-A'),
('RAGUL KANTH B', '2006-01-22', 810023103006, 'CIVIL-A'),
('ABARNA A', '2005-09-30', 810023103007, 'CIVIL-A'),
('BALAJI S', '2005-10-02', 810023103008, 'CIVIL-A'),
('SIVABALAN G', '2005-11-25', 810023103010, 'CIVIL-A'),
('KRITHIKRAJAN P', '2006-05-19', 810023103011, 'CIVIL-A'),
('SHAHITHYA R', '2005-09-26', 810023103012, 'CIVIL-A'),
('ARUL K', '2006-11-07', 810023103013, 'CIVIL-A'),
('PARKAVI B', '2006-07-29', 810023103014, 'CIVIL-A'),
('RITHICK P M', '2005-10-31', 810023103015, 'CIVIL-A'),
('SRINESH S', '2006-01-23', 810023103016, 'CIVIL-A'),
('SIVASANKARI V', '2006-03-04', 810023103017, 'CIVIL-A'),
('ASWATHI G', '2006-05-12', 810023103018, 'CIVIL-A'),
('HARINI M', '2006-05-30', 810023103019, 'CIVIL-A'),
('NISHA A', '2005-10-30', 810023103020, 'CIVIL-A'),
('PRADEEP N', '2006-07-29', 810023103021, 'CIVIL-A'),
('RAJKUMAR S I', '2006-03-17', 810023103022, 'CIVIL-A'),
('MONISHA S', '2006-03-14', 810023103023, 'CIVIL-A'),
('RAMKUMAR R', '2005-05-15', 810023103024, 'CIVIL-A'),
('HARISH R', '2006-04-11', 810023103025, 'CIVIL-A'),
('MATHAN KUMAR A', '2006-02-10', 810023103026, 'CIVIL-A'),
('SURYA DHARSHINI M', '2006-07-02', 810023103027, 'CIVIL-A'),
('KABILAN S', '2006-02-09', 810023103028, 'CIVIL-A'),
('KEERTHANA K', '2004-07-06', 810023103029, 'CIVIL-A'),
('KESAVAKUMARI S', '2006-04-06', 810023103030, 'CIVIL-A'),
('LOKESHWARAN V B', '2005-08-25', 810023103031, 'CIVIL-A'),
('ABHISHEK R', '2005-09-14', 810023103032, 'CIVIL-A'),
('DHARANI S', '2005-10-14', 810023103033, 'CIVIL-A'),
('NITHINARVINTH A', '2003-05-06', 810023103034, 'CIVIL-A'),
('BHARANIDHARAN V', '2005-10-19', 810023103035, 'CIVIL-A'),
('NEELAVANNAN R', '2006-03-13', 810023103036, 'CIVIL-A'),
('NISHANTH S', '2005-12-01', 810023103037, 'CIVIL-A'),
('ARUN P', '2005-11-15', 810023103038, 'CIVIL-A'),
('KALIVIGNESH G', '2006-04-06', 810023103039, 'CIVIL-A'),
('MOHAMED HALITH A', '2005-09-25', 810023103040, 'CIVIL-A'),
('ABDUL KALAM A', '2006-01-20', 810023103041, 'CIVIL-A'),
('BHARATHI R K', '2006-02-24', 810023103042, 'CIVIL-A'),
('JAGADESAN T', '2006-02-07', 810023103043, 'CIVIL-A'),
('NITHIYASRI M', '2006-01-24', 810023103044, 'CIVIL-A'),
('ABINAYA R', '2006-03-29', 810023103045, 'CIVIL-A'),
('HAARINI S', '2005-08-04', 810023103046, 'CIVIL-A'),
('SRIRAM NATTAR P', '2006-06-19', 810023103047, 'CIVIL-A'),
('YOGESHWARAN V', '2006-01-27', 810023103048, 'CIVIL-A'),
('VAISHNAVI T', '2005-10-28', 810023103049, 'CIVIL-A'),
('KAMALNATH A', '2005-11-19', 810023103050, 'CIVIL-A'),
('VIMAL KUMAR M', '2004-07-05', 810023103051, 'CIVIL-A'),
('SRUTHI A', '2005-09-28', 810023103053, 'CIVIL-A'),
('PRITHIKA R T', '2006-08-06', 810023103054, 'CIVIL-A'),
('AJAY SUNDAR A', '2006-01-08', 810023103055, 'CIVIL-A'),
('KARTHICK S', '2005-07-28', 810023103056, 'CIVIL-B'),
('GANGA K', '2006-09-26', 810023103057, 'CIVIL-B'),
('SHAMUNDESHWARI T', '2005-11-24', 810023103058, 'CIVIL-B'),
('DHANUSHA S', '2006-08-07', 810023103059, 'CIVIL-B'),
('ARTHI S', '2006-04-01', 810023103060, 'CIVIL-B'),
('DHIVYA DHARSHINI G', '2005-12-02', 810023103061, 'CIVIL-B'),
('HARIHARAN N', '2005-10-07', 810023103062, 'CIVIL-B'),
('ROHINI G K', '2005-06-06', 810023103063, 'CIVIL-B'),
('DHEJESH KUMAR P', '2005-12-27', 810023103064, 'CIVIL-B'),
('SUNITHA K', '2005-11-14', 810023103065, 'CIVIL-B'),
('LINGESH KUMAR', '2005-09-22', 810023103066, 'CIVIL-B'),
('MOHAMED ANIF S', '2005-03-13', 810023103067, 'CIVIL-B'),
('LATCHATHAN T', '2006-02-05', 810023103068, 'CIVIL-B'),
('THILAK S', '2006-02-15', 810023103069, 'CIVIL-B'),
('AARTHI K', '2005-11-12', 810023103070, 'CIVIL-B'),
('SASIKUMAR S', '2006-02-19', 810023103071, 'CIVIL-B'),
('ABDUL AJEES M', '2006-05-23', 810023103072, 'CIVIL-B'),
('BANU SRI VARTHANI V', '2005-09-22', 810023103073, 'CIVIL-B'),
('SANTHOSH M', '2006-08-27', 810023103074, 'CIVIL-B'),
('AATHISESAN S', '2006-03-15', 810023103075, 'CIVIL-B'),
('ANBUMANI M', '2005-07-09', 810023103076, 'CIVIL-B'),
('PRIYADHARSHINI M', '2004-10-12', 810023103077, 'CIVIL-B'),
('KODESHWARI M', '2006-02-27', 810023103078, 'CIVIL-B'),
('APOORVA N', '2006-07-04', 810023103079, 'CIVIL-B'),
('SHANMUGA PRIYA K', '2006-07-05', 810023103080, 'CIVIL-B'),
('JANANISRI G', '2006-05-18', 810023103082, 'CIVIL-B'),
('SAMINATHAN M', '2005-05-25', 810023103083, 'CIVIL-B'),
('PRAVEEN S', '2004-07-29', 810023103084, 'CIVIL-B'),
('JEEVA M', '2005-06-11', 810023103085, 'CIVIL-B'),
('YUVARAJ R', '2006-09-29', 810023103086, 'CIVIL-B'),
('PRASANYA D', '2006-05-10', 810023103087, 'CIVIL-B'),
('YUGANIKHI G', '2006-04-18', 810023103088, 'CIVIL-B'),
('MARIA AKASH A', '2004-10-11', 810023103089, 'CIVIL-B'),
('RESHIKA V', '2006-04-29', 810023103090, 'CIVIL-B'),
('NIRANJAN S', '2005-10-07', 810023103091, 'CIVIL-B'),
('GOKUL S', '2006-07-24', 810023103092, 'CIVIL-B'),
('VINOTHA R', '2005-08-18', 810023103093, 'CIVIL-B'),
('BALAMURUGAN S', '2005-10-02', 810023103094, 'CIVIL-B'),
('HARIHARAN A', '2005-10-24', 810023103095, 'CIVIL-B'),
('VINOCHAN M', '2006-06-24', 810023103096, 'CIVIL-B'),
('AZHARUDEEN R', '2005-05-05', 810023103097, 'CIVIL-B'),
('JEYAKISHORE S S', '2006-07-13', 810023103098, 'CIVIL-B'),
('AYYAPPAN S', '2006-06-12', 810023103099, 'CIVIL-B'),
('BASKAR A', '2006-05-16', 810023103100, 'CIVIL-B'),
('KATHIRAVAN K', '2005-08-20', 810023103101, 'CIVIL-B'),
('KAVIPRIYA R', '2005-03-19', 810023103102, 'CIVIL-B'),
('PRAVINRAJ D', '2006-03-15', 810023103103, 'CIVIL-B'),
('VASANTH A', '2005-12-29', 810023103104, 'CIVIL-B'),
('PRIYA V', '2006-01-21', 810023103105, 'CIVIL-B'),
('DARSNA S', '2006-03-23', 810023104001, 'CSE-A'),
('CHARLIN ASHINI A D', '2006-06-03', 810023104002, 'CSE-A'),
('SRINIDHI K', '2006-05-11', 810023104003, 'CSE-A'),
('ARUL JASMINE D', '2006-01-10', 810023104004, 'CSE-A'),
('SANTHIYA S', '2005-03-01', 810023104005, 'CSE-A'),
('ARUL JEBARAJ M', '2006-03-05', 810023104006, 'CSE-A'),
('YUVARANI S', '2005-02-04', 810023104007, 'CSE-A'),
('VISHNUPRIYA K', '2006-03-02', 810023104008, 'CSE-A'),
('MONISHA JENCY J', '2006-04-10', 810023104009, 'CSE-A'),
('NISHASRI A', '2005-10-31', 810023104010, 'CSE-A'),
('VIVEKANANDAN A', '2005-11-08', 810023104011, 'CSE-A'),
('SAKTHIVEL K', '2006-06-13', 810023104012, 'CSE-A'),
('DIVYA K', '2006-05-13', 810023104013, 'CSE-A'),
('SARAVANAKUMAR P', '2006-02-09', 810023104014, 'CSE-A'),
('DEEPIKA A', '2006-01-23', 810023104015, 'CSE-A'),
('RAJESH S', '2006-06-07', 810023104016, 'CSE-A'),
('SHOBANA V', '2005-12-09', 810023104017, 'CSE-A'),
('SOWMIYA S', '2005-10-14', 810023104018, 'CSE-A'),
('MATHAN KUMAR G', '2005-10-27', 810023104019, 'CSE-A'),
('AKASH A', '2006-06-22', 810023104020, 'CSE-A'),
('VAITHEESHWARAN P', '2005-02-11', 810023104021, 'CSE-A'),
('ASIN T', '2006-05-14', 810023104022, 'CSE-A'),
('ASHOK RAJ A', '2006-08-01', 810023104023, 'CSE-A'),
('BALAMURUGAN K', '2006-02-27', 810023104024, 'CSE-A'),
('DEEPAK RAJ E', '2004-08-29', 810023104025, 'CSE-A'),
('GOMATHI S', '2006-07-12', 810023104026, 'CSE-A'),
('ARUVI V', '2006-06-11', 810023104027, 'CSE-A'),
('VIMAL RAJ J', '2006-02-20', 810023104028, 'CSE-A'),
('NIRMALKUMAR', '2005-02-04', 810023104029, 'CSE-A'),
('VIJAY V', '2005-06-20', 810023104030, 'CSE-A'),
('VAISHNAVI P', '2005-09-23', 810023104031, 'CSE-A'),
('MUTHAZHAGI P', '2006-03-07', 810023104032, 'CSE-A'),
('DHANALAKSHMI J', '2006-01-23', 810023104033, 'CSE-A'),
('GOKUL RAJAN T', '2005-11-10', 810023104034, 'CSE-A'),
('AYISHA H', '2004-07-15', 810023104036, 'CSE-A'),
('AKSHAYA S', '2005-12-29', 810023104037, 'CSE-A'),
('HARINI S', '2005-05-31', 810023104038, 'CSE-A'),
('INBAN V', '2006-04-11', 810023104039, 'CSE-A'),
('SARATHY V', '2005-09-26', 810023104040, 'CSE-A'),
('PUGAZHVADIVU E', '2006-02-17', 810023104041, 'CSE-A'),
('VEERAMANI S', '2005-06-15', 810023104042, 'CSE-A'),
('SNOW SELVA RAFIKA S', '2005-08-11', 810023104043, 'CSE-A'),
('MAHENDIRAN M', '2005-06-13', 810023104044, 'CSE-A'),
('MUTHAMIZHSELVI M', '2005-12-22', 810023104045, 'CSE-A'),
('MOHANADHARSHINI S', '2005-07-11', 810023104046, 'CSE-A'),
('DEEPANRAJA S', '2006-06-18', 810023104047, 'CSE-A'),
('KATHIRAVAN P', '2006-01-10', 810023104048, 'CSE-A'),
('SANGEETHA J', '2005-11-12', 810023104049, 'CSE-A'),
('MUGESHKUMAR M', '2006-05-07', 810023104050, 'CSE-A'),
('INDRA SANTHOSHI B', '2005-10-25', 810023104051, 'CSE-A'),
('RENUGA S', '2006-05-25', 810023104052, 'CSE-A'),
('HONIXA AFFRIN G A', '2006-06-28', 810023104053, 'CSE-A'),
('KELLTENA D', '2005-11-10', 810023104054, 'CSE-A'),
('WILMA ROSARY D', '2005-12-14', 810023104055, 'CSE-A'),
('RADHIKA R', '2006-09-02', 810023104056, 'CSE-A'),
('ROFEENA J', '2005-10-01', 810023104057, 'CSE-A'),
('MUTHURAJA P', '2006-01-10', 810023104058, 'CSE-A'),
('YOKESWARAN P', '2005-06-04', 810023104059, 'CSE-A'),
('RIFAYA PARVEEN S', '2006-04-30', 810023104060, 'CSE-A'),
('ANNE JAISI KIRUBA R', '2005-10-30', 810023104061, 'CSE-B'),
('JAINULABUDEEN K', '2005-10-26', 810023104062, 'CSE-B'),
('GURUBARATH S', '2005-12-08', 810023104063, 'CSE-B'),
('SANGEETHA S', '2005-10-03', 810023104065, 'CSE-B'),
('LASIMA V', '2006-05-26', 810023104066, 'CSE-B'),
('MARIESWARAN K', '2004-02-19', 810023104067, 'CSE-B'),
('SUMITHRA R', '2006-01-21', 810023104068, 'CSE-B'),
('MUHAMMAD ZAAFIR M', '2007-01-07', 810023104069, 'CSE-B'),
('KISHAN DOSS R', '2005-09-04', 810023104070, 'CSE-B'),
('BALAJI M', '2006-03-23', 810023104071, 'CSE-B'),
('THAMIZH EZHILAN T', '2006-06-05', 810023104072, 'CSE-B'),
('MAGESHWARAN O', '2005-12-02', 810023104073, 'CSE-B'),
('GOWTHAM S', '2006-05-30', 810023104074, 'CSE-B'),
('DHARINI D', '2006-02-20', 810023104075, 'CSE-B'),
('SURAJ SIVA R', '2006-01-14', 810023104076, 'CSE-B'),
('LATCHAYA S', '2006-06-21', 810023104077, 'CSE-B'),
('ARUNPRASAD A S', '2006-05-17', 810023104078, 'CSE-B'),
('MADHANKUMAR O V', '2004-10-11', 810023104079, 'CSE-B'),
('POONGODI S', '2005-12-25', 810023104080, 'CSE-B'),
('SOBIYA A', '2005-11-02', 810023104081, 'CSE-B'),
('ARUNA S', '2006-01-11', 810023104082, 'CSE-B'),
('ASHIKA H', '2006-03-02', 810023104083, 'CSE-B'),
('VIJAYALAKSHMI M', '2005-09-23', 810023104085, 'CSE-B'),
('THOLKAPPIYAN G', '2006-03-18', 810023104086, 'CSE-B'),
('AISHWARYA V', '2005-12-23', 810023104087, 'CSE-B'),
('SIDHARTH M', '2006-05-31', 810023104088, 'CSE-B'),
('SHOBIKA B', '2005-11-12', 810023104089, 'CSE-B'),
('PRAVEEN BALAJI S', '2004-05-31', 810023104090, 'CSE-B'),
('ADITHYA T', '2005-09-01', 810023104092, 'CSE-B'),
('SAKTHIVEL S', '2006-05-20', 810023104093, 'CSE-B'),
('MAHA SHREE R', '2005-09-29', 810023104094, 'CSE-B'),
('SAFRIN SHIFA I', '2006-07-12', 810023104095, 'CSE-B'),
('GUNABALAJI G', '2005-11-01', 810023104096, 'CSE-B'),
('DEEPIKA T', '2006-02-11', 810023104097, 'CSE-B'),
('NISHANTHINI S', '2005-10-01', 810023104098, 'CSE-B'),
('KAVIYA K', '2005-06-08', 810023104099, 'CSE-B'),
('SELSIYA K', '2006-03-30', 810023104100, 'CSE-B'),
('ARIVU SELVAN R', '2005-11-02', 810023104101, 'CSE-B'),
('VIGNESHWARAN C', '2006-08-02', 810023104102, 'CSE-B'),
('SELVA J', '2005-02-06', 810023104103, 'CSE-B'),
('DIVYA R', '2005-04-12', 810023104104, 'CSE-B'),
('VISHVA P', '2006-05-08', 810023104105, 'CSE-B'),
('HARISH M', '2006-02-11', 810023104106, 'CSE-B'),
('KIRUBAKARAN B', '2006-06-27', 810023104107, 'CSE-B'),
('VISHWANATH R', '2005-07-31', 810023104108, 'CSE-B'),
('MANOJITHAN R', '2006-07-28', 810023104109, 'CSE-B'),
('BHUVANESH', '2005-12-22', 810023104110, 'CSE-B'),
('KABILDHARSHAN S', '2005-09-19', 810023104111, 'CSE-B'),
('PRATHAP A', '2005-07-19', 810023104112, 'CSE-B'),
('BHAVANA V', '2005-04-20', 810023104113, 'CSE-B'),
('KALAI VANI S', '2005-08-01', 810023104114, 'CSE-B'),
('GOKUL T P', '2004-06-08', 810023104115, 'CSE-B'),
('REVATHI K', '2005-09-08', 810023104116, 'CSE-B'),
('ASWINI R', '2006-05-26', 810023104117, 'CSE-B'),
('THIRISHALA M', '2006-11-12', 810023104118, 'CSE-B'),
('RITHICK MENON M', '2006-04-10', 810023104119, 'CSE-B'),
('ARUNACHALAM A', '2005-12-01', 810023105001, 'EEE-A'),
('SAHAYA SHAINI A', '2006-07-16', 810023105002, 'EEE-A'),
('NIVETHA S', '2005-08-07', 810023105003, 'EEE-A'),
('SUGANYA G', '2005-09-09', 810023105004, 'EEE-A'),
('ARAVINTH S', '2005-12-06', 810023105005, 'EEE-A'),
('KANIKA M', '2006-06-16', 810023105006, 'EEE-A'),
('LAVANYA V', '2006-05-25', 810023105007, 'EEE-A'),
('ARAVIND A', '2006-02-21', 810023105008, 'EEE-A'),
('GUNALINI A', '2005-07-06', 810023105009, 'EEE-A'),
('PRAVEENKUMAR J', '2005-09-06', 810023105010, 'EEE-A'),
('SHALMA BEGUM A S', '2006-05-07', 810023105011, 'EEE-A'),
('FATHIMA HAFNAA M', '2006-04-02', 810023105012, 'EEE-A'),
('NANDHAKUMAR K', '2006-05-14', 810023105013, 'EEE-A'),
('RASU A', '2006-08-31', 810023105014, 'EEE-A'),
('RUTHRAPATHY S', '2005-08-12', 810023105015, 'EEE-A'),
('SRIRAMSANTHOSH S', '2007-04-15', 810023105016, 'EEE-A'),
('KIRUBALAN N', '2006-08-08', 810023105017, 'EEE-A'),
('SANTHOSH S', '2006-06-22', 810023105018, 'EEE-A'),
('MONISHA L', '2005-09-29', 810023105019, 'EEE-A'),
('SRI NIVETHA K', '2006-07-16', 810023105020, 'EEE-A'),
('VARSHINI S', '2006-05-07', 810023105021, 'EEE-A'),
('ARUNA M', '2004-01-01', 810023105022, 'EEE-A'),
('SAMUNDISHWARI I', '2005-11-13', 810023105023, 'EEE-A'),
('BABISHNA E', '2006-07-31', 810023105024, 'EEE-A'),
('KARTHIKEYAN M', '2005-12-16', 810023105025, 'EEE-A'),
('MALAIYANDI S', '2005-10-31', 810023105026, 'EEE-A'),
('MUTHUMANI KANDAN R P', '2006-09-24', 810023105027, 'EEE-A'),
('PUGAZHMANI', '2006-03-27', 810023105028, 'EEE-A'),
('ARAVINDHAN K', '2005-11-03', 810023105029, 'EEE-A'),
('MUTHU SANKAR S', '2005-06-16', 810023105030, 'EEE-A'),
('NAVEENDHIRAN G', '2006-07-15', 810023105031, 'EEE-A'),
('JEEVANRAJ E', '2006-06-14', 810023105032, 'EEE-A'),
('NISHA M', '2006-03-20', 810023105033, 'EEE-A'),
('MANJULA S', '2006-02-14', 810023105034, 'EEE-A'),
('NAVINASH V', '2005-11-04', 810023105035, 'EEE-A'),
('NIZAR AHAMED A J', '2005-09-02', 810023105036, 'EEE-A'),
('AARTHI SREE S', '2006-03-12', 810023105037, 'EEE-A'),
('NATHIYA N', '2006-03-15', 810023105038, 'EEE-A'),
('SURABHI A', '2002-12-02', 810023105039, 'EEE-A'),
('ENIYANILA M', '2006-01-02', 810023105041, 'EEE-A'),
('VINVITHAA SRI C K', '2005-06-06', 810023105042, 'EEE-A'),
('KARTHIK T K', '2005-07-11', 810023105043, 'EEE-A'),
('DAENIKA M', '2005-08-05', 810023105044, 'EEE-A'),
('MALINI R', '2005-11-25', 810023105045, 'EEE-A'),
('YUVAN SHANKAR R', '2006-10-26', 810023105047, 'EEE-A'),
('HARINI G', '2006-07-24', 810023105048, 'EEE-A'),
('AATHIHA M', '2005-06-27', 810023105049, 'EEE-A'),
('ABDUL WAHIDH B', '2006-02-25', 810023105050, 'EEE-A'),
('SAM SUDHARSAN', '2006-06-17', 810023105051, 'EEE-A'),
('NATHIYA R', '2005-03-30', 810023105052, 'EEE-A'),
('GUNASEKARAN S', '2006-03-26', 810023105053, 'EEE-A'),
('RAMYA S', '2006-02-07', 810023105054, 'EEE-A'),
('KISHOREKUMAR V', '2005-01-22', 810023105055, 'EEE-A'),
('JENESH SAMVEL H', '2005-02-23', 810023105057, 'EEE-A'),
('MADHU LEKA A', '2005-02-24', 810023105058, 'EEE-A'),
('VENGATESH V', '2005-02-26', 810023105059, 'EEE-B'),
('SHAMLI M', '2006-03-02', 810023105060, 'EEE-B'),
('BOWNIKA M', '2006-04-29', 810023105061, 'EEE-B'),
('SURYA', '2006-03-31', 810023105062, 'EEE-B'),
('SWATHI S', '2006-07-06', 810023105063, 'EEE-B'),
('VENNILA M', '2006-10-13', 810023105064, 'EEE-B'),
('SUDHARSANAN S', '2006-01-17', 810023105065, 'EEE-B'),
('RAGUL R', '2006-08-18', 810023105066, 'EEE-B'),
('SHANMUGANATHAN D', '2005-08-03', 810023105067, 'EEE-B'),
('ABARNA B', '2005-10-12', 810023105068, 'EEE-B'),
('NAVEEN M', '2005-11-04', 810023105069, 'EEE-B'),
('RAMYA LAKSHMI P', '2005-11-28', 810023105070, 'EEE-B'),
('MALATHI M', '2006-05-23', 810023105071, 'EEE-B'),
('DEVAPRASATH S', '2006-06-29', 810023105072, 'EEE-B'),
('MANORANJAN B', '2005-12-21', 810023105073, 'EEE-B'),
('DHARSHINI K', '2005-11-30', 810023105074, 'EEE-B'),
('SOBI KATHIR C', '2005-08-25', 810023105075, 'EEE-B'),
('SARABAVAN S', '2005-06-02', 810023105076, 'EEE-B'),
('DHARSHINI R', '2006-05-21', 810023105077, 'EEE-B'),
('SUDHARSHAN V', '2006-05-22', 810023105078, 'EEE-B'),
('VEDHA S', '2006-05-09', 810023105079, 'EEE-B'),
('EMERSON ETHIRAJ A', '2006-02-06', 810023105080, 'EEE-B'),
('NEETHIARASI M', '2006-05-14', 810023105081, 'EEE-B'),
('NAGUL R', '2005-10-22', 810023105082, 'EEE-B'),
('AKASH A', '2006-07-31', 810023105083, 'EEE-B'),
('KEERTHANA M', '2006-01-03', 810023105084, 'EEE-B'),
('KALAIYARASAN K', '2004-07-13', 810023105085, 'EEE-B'),
('YAZHINI A', '2005-10-11', 810023105086, 'EEE-B'),
('KANNIHA R', '2004-07-19', 810023105087, 'EEE-B'),
('PRIYADHARSHINI S', '2006-02-06', 810023105088, 'EEE-B'),
('SACHIN P', '2005-11-03', 810023105089, 'EEE-B'),
('AMIRTHARATHINAM P', '2006-07-10', 810023105090, 'EEE-B'),
('MEGHA S', '2005-12-22', 810023105091, 'EEE-B'),
('DINESH S', '2005-06-19', 810023105092, 'EEE-B'),
('YUGENDIRAN I', '2005-12-29', 810023105093, 'EEE-B'),
('SRI SINDHU L', '2006-01-28', 810023105094, 'EEE-B'),
('SRISANMATHI S', '2005-07-13', 810023105095, 'EEE-B'),
('JAYASHREE B', '2006-11-25', 810023105096, 'EEE-B'),
('YASIN KHAN N', '2006-06-03', 810023105097, 'EEE-B'),
('MONISHA S', '2006-07-02', 810023105099, 'EEE-B'),
('MAHALAKSHMI J', '2005-11-11', 810023105100, 'EEE-B'),
('SUBEGA M', '2006-02-06', 810023105101, 'EEE-B'),
('PRASANNA M', '2005-09-12', 810023105102, 'EEE-B'),
('VIMAL RAJ N', '2006-03-19', 810023105103, 'EEE-B'),
('GURU RAM S', '2006-03-15', 810023105105, 'EEE-B'),
('VIGNESH S', '2005-09-21', 810023105106, 'EEE-B'),
('ANITHA A', '2006-07-28', 810023105107, 'EEE-B'),
('SANYO S', '2005-06-27', 810023105108, 'EEE-B'),
('KALAIMANI K', '2006-01-29', 810023105109, 'EEE-B'),
('KAVIARASU K', '2006-05-02', 810023105110, 'EEE-B'),
('LAAVANYA M', '2006-04-01', 810023105111, 'EEE-B'),
('HARSHINEE A', '2006-03-25', 810023105112, 'EEE-B'),
('ANUSHA M', '2006-06-17', 810023105114, 'EEE-B'),
('VALLIPRIYA N', '2006-02-24', 810023105115, 'EEE-B'),
('VICHITRA V', '2006-03-18', 810023105116, 'EEE-B'),
('ANANTHALAKSHMI P', '2006-02-20', 810023105117, 'EEE-B'),
('DEVISRI P', '2006-06-10', 810023106001, 'ECE-A'),
('MADHAVAN S', '2005-07-23', 810023106002, 'ECE-A'),
('SHAFANA YASMIN K', '2005-09-06', 810023106003, 'ECE-A'),
('SARANYA G', '2005-11-14', 810023106004, 'ECE-A'),
('SARAVANAN A', '2006-08-12', 810023106006, 'ECE-A'),
('SANTHOSH KUMAR A', '2005-06-07', 810023106008, 'ECE-A'),
('BALAJI V', '2005-10-31', 810023106009, 'ECE-A'),
('NIVETHA K', '2005-11-03', 810023106010, 'ECE-A'),
('UMAR H', '2005-05-08', 810023106011, 'ECE-A'),
('NAVAMALIKA B', '2006-04-16', 810023106012, 'ECE-A'),
('AMARNATH P', '2005-06-09', 810023106013, 'ECE-A'),
('KAVINESAN M', '2006-04-23', 810023106014, 'ECE-A'),
('VIJAYAKUMARI D', '2005-11-17', 810023106015, 'ECE-A'),
('VIGNESHWARI A', '2005-10-27', 810023106016, 'ECE-A'),
('AMIRTHAMBIKA R', '2006-06-20', 810023106017, 'ECE-A'),
('RENUKA K', '2006-09-23', 810023106018, 'ECE-A'),
('GOWTHAM R', '2005-11-09', 810023106019, 'ECE-A'),
('CHARULATHA B', '2006-04-10', 810023106020, 'ECE-A'),
('KRISHNARAJ M', '2005-10-22', 810023106021, 'ECE-A'),
('PRIYADHARSHINI B', '2006-05-05', 810023106022, 'ECE-A'),
('AKASH A', '2006-08-22', 810023106023, 'ECE-A'),
('RAJIV K', '2006-09-09', 810023106024, 'ECE-A'),
('SRI LAKSHMI R', '2005-09-04', 810023106025, 'ECE-A'),
('LAVANAYA K', '2006-03-31', 810023106026, 'ECE-A'),
('SONIYA T', '2006-09-28', 810023106027, 'ECE-A'),
('VEDHACHALAM K', '2006-07-27', 810023106028, 'ECE-A'),
('KANISHKA S', '2006-09-14', 810023106029, 'ECE-A'),
('VENKATESH H', '2005-07-14', 810023106030, 'ECE-A'),
('KAVI KUMAR K', '2006-06-01', 810023106031, 'ECE-A'),
('VIDHUBALA K', '2006-08-26', 810023106032, 'ECE-A'),
('ANBUSELVAN A', '2006-10-19', 810023106033, 'ECE-A'),
('ARCHANA M', '2004-01-01', 810023106034, 'ECE-A'),
('RITHISH B', '2006-03-19', 810023106035, 'ECE-A'),
('DHARSHINI P S', '2005-09-18', 810023106036, 'ECE-A'),
('ASIYA T', '2005-08-15', 810023106037, 'ECE-A'),
('IRFAN T SHADIL', '2005-09-08', 810023106038, 'ECE-A'),
('DAYANITHI C', '2006-03-12', 810023106039, 'ECE-A'),
('YUVARAJ T', '2006-02-22', 810023106040, 'ECE-A'),
('VANCHINATHAN S S', '2005-12-10', 810023106041, 'ECE-A'),
('DEVIBALA K', '2005-09-19', 810023106042, 'ECE-A'),
('HARINI B', '2005-08-31', 810023106043, 'ECE-A'),
('DHUVARIKA S', '2005-12-10', 810023106044, 'ECE-A'),
('AKALYA M', '2006-06-23', 810023106045, 'ECE-A'),
('PON KARTHIKA V', '2007-05-19', 810023106046, 'ECE-A'),
('DIVYASRI S', '2006-02-13', 810023106047, 'ECE-A'),
('KESHAV VIJAYAN K R', '2005-08-31', 810023106048, 'ECE-A'),
('KEERTHIKA S', '2006-01-09', 810023106049, 'ECE-A'),
('SURYA S', '2005-11-01', 810023106050, 'ECE-A'),
('NISHANTHI S V', '2005-09-14', 810023106051, 'ECE-A'),
('SIVARAMAN K', '2006-05-13', 810023106052, 'ECE-A'),
('SARANYA A', '2005-10-23', 810023106053, 'ECE-A'),
('KALAIYARASAN V', '2005-08-19', 810023106054, 'ECE-A'),
('RAJESHWARI P', '2005-05-04', 810023106055, 'ECE-A'),
('KARTHIKEYAN S', '2005-10-01', 810023106056, 'ECE-A'),
('MENAKA M', '2004-10-10', 810023106057, 'ECE-A'),
('LAKSHMI PRABHA M', '2005-11-14', 810023106058, 'ECE-A'),
('RITHIGA DEVI R', '2006-04-20', 810023106059, 'ECE-B'),
('NAVEENA M', '2005-11-05', 810023106060, 'ECE-B'),
('SRINITHI PRIYA T', '2005-12-10', 810023106061, 'ECE-B'),
('DINESHKUMAR K V', '2006-01-24', 810023106062, 'ECE-B'),
('PRAVEEN KUMAR R', '2005-10-29', 810023106063, 'ECE-B'),
('KIRUTHIKASRIMATHI M', '2005-11-08', 810023106064, 'ECE-B'),
('ABITHA K', '2005-10-18', 810023106065, 'ECE-B'),
('HARIKRISHNAN T', '2005-08-30', 810023106066, 'ECE-B'),
('PRAVEEN R', '2005-03-22', 810023106067, 'ECE-B'),
('PRIYADHARSHINI G S', '2006-01-21', 810023106068, 'ECE-B'),
('NISHA K', '2005-09-27', 810023106069, 'ECE-B'),
('LOGANATHAN P', '2006-01-08', 810023106070, 'ECE-B'),
('HARANIYA K', '2005-12-18', 810023106072, 'ECE-B'),
('JAYASRI V', '2005-09-13', 810023106073, 'ECE-B'),
('DIVYALAKSHMANI G', '2005-01-28', 810023106074, 'ECE-B'),
('RAJESH KANNA M', '2005-10-04', 810023106075, 'ECE-B'),
('KIRUTHIKA P', '2005-10-13', 810023106076, 'ECE-B'),
('ARCHANA C', '2006-02-06', 810023106077, 'ECE-B'),
('NAVINRAJ B', '2006-04-12', 810023106078, 'ECE-B'),
('VIGNESH SHREE P', '2005-01-16', 810023106079, 'ECE-B'),
('SUBHASH M', '2006-06-20', 810023106080, 'ECE-B'),
('VINISHA T', '2005-10-21', 810023106081, 'ECE-B'),
('AGHILESH M', '2005-12-30', 810023106082, 'ECE-B'),
('MANIKANDAN S', '2005-11-27', 810023106083, 'ECE-B'),
('VIJAYA DHARSHINI S', '2005-10-23', 810023106084, 'ECE-B'),
('SUNDHARA LAKSHMI T', '2006-01-06', 810023106085, 'ECE-B'),
('THANGARAJ S', '2006-03-18', 810023106086, 'ECE-B'),
('ABISHEK M', '2005-11-04', 810023106087, 'ECE-B'),
('MADHUMITHA S', '2005-09-29', 810023106088, 'ECE-B'),
('VASANTHA NESAN S', '2005-08-17', 810023106089, 'ECE-B'),
('SHIFANA S', '2006-06-12', 810023106090, 'ECE-B'),
('DEEPIKA S', '2006-07-06', 810023106091, 'ECE-B'),
('AKSHAYA PRIYA S', '2006-03-21', 810023106092, 'ECE-B'),
('THARIS S', '2005-09-04', 810023106093, 'ECE-B'),
('MATHANGI M', '2006-05-18', 810023106094, 'ECE-B'),
('NIVETHA B', '2005-12-01', 810023106095, 'ECE-B'),
('VIGNESH S', '2005-12-05', 810023106096, 'ECE-B'),
('SHREEYA S', '2005-12-09', 810023106097, 'ECE-B'),
('RAMANISH V', '2006-04-24', 810023106098, 'ECE-B'),
('MADHANKUMAR Y', '2005-09-30', 810023106099, 'ECE-B'),
('SHRIBALA T', '2005-02-03', 810023106100, 'ECE-B'),
('SHEIK ABDULLA I', '2006-01-14', 810023106101, 'ECE-B'),
('NIRANJANA P', '2006-02-22', 810023106102, 'ECE-B'),
('RAJPRIYA S', '2007-02-03', 810023106103, 'ECE-B'),
('PONNIN SELVAN M', '2005-06-02', 810023106105, 'ECE-B'),
('NITHISH A', '2006-03-31', 810023106106, 'ECE-B'),
('GOWTHAM V', '2005-08-31', 810023106107, 'ECE-B'),
('SUMAN ADHITHIYA M', '2005-09-17', 810023106108, 'ECE-B'),
('PURUSHOTHAMAN K', '2004-09-16', 810023106109, 'ECE-B'),
('GIRIDHARAN S', '2006-08-19', 810023106110, 'ECE-B'),
('SARATH V', '2005-08-01', 810023106111, 'ECE-B'),
('SRIRAM P', '2005-06-17', 810023106112, 'ECE-B'),
('YOVARASAN S', '2005-10-08', 810023106113, 'ECE-B'),
('SUWATHIGA S', '2005-11-01', 810023106114, 'ECE-B'),
('KANISHKA L', '2006-01-13', 810023106115, 'ECE-B'),
('ACACIO D', '2006-02-27', 810023114001, 'MECHANICAL-A'),
('SAMBATHKUMAR M', '2004-09-02', 810023114002, 'MECHANICAL-A'),
('ABINATH K', '2006-03-31', 810023114003, 'MECHANICAL-A'),
('SANKARANARAYANAN G', '2006-02-04', 810023114004, 'MECHANICAL-A'),
('RATHNA R', '2005-10-05', 810023114005, 'MECHANICAL-A'),
('MUGESH K', '2006-07-12', 810023114006, 'MECHANICAL-A'),
('RAHUL R', '2006-08-16', 810023114007, 'MECHANICAL-A'),
('MOHAMED SHAFIK R', '2005-11-28', 810023114008, 'MECHANICAL-A'),
('JAYARAJ A', '2005-11-20', 810023114009, 'MECHANICAL-A'),
('SUDHAKARAN S', '2005-11-14', 810023114010, 'MECHANICAL-A'),
('SAKTHIVEL V', '2005-05-09', 810023114011, 'MECHANICAL-A'),
('SANJAY K', '2006-08-28', 810023114012, 'MECHANICAL-A'),
('BHUVANESAN NV', '2005-12-25', 810023114013, 'MECHANICAL-A'),
('PERIYA ARASU M', '2005-10-02', 810023114014, 'MECHANICAL-A'),
('GIRIDHARAN G', '2005-10-13', 810023114015, 'MECHANICAL-A'),
('DHARSHINI M', '2006-06-19', 810023114016, 'MECHANICAL-A'),
('MAGI AGNUS P', '2005-08-25', 810023114017, 'MECHANICAL-A'),
('RAJADURAI D', '2006-09-10', 810023114018, 'MECHANICAL-A'),
('SUSHVANTH S', '2006-04-27', 810023114019, 'MECHANICAL-A'),
('RANJITH M', '2006-04-22', 810023114020, 'MECHANICAL-A'),
('KAMALAKKANNAN P', '2006-02-09', 810023114021, 'MECHANICAL-A'),
('SUBRAMANI K', '2005-04-11', 810023114022, 'MECHANICAL-A'),
('MOHANSELVAKUMAR P', '2006-01-18', 810023114023, 'MECHANICAL-A'),
('BALAJI K', '2005-09-21', 810023114024, 'MECHANICAL-A'),
('MUGESH S', '2006-01-17', 810023114025, 'MECHANICAL-A'),
('NISHANTH S', '2006-04-17', 810023114026, 'MECHANICAL-A'),
('NITHIN S', '2006-04-17', 810023114027, 'MECHANICAL-A'),
('BEER MOHAMED N', '2006-04-05', 810023114028, 'MECHANICAL-A'),
('BOOBALAN E', '2006-06-13', 810023114029, 'MECHANICAL-A'),
('VIGNESHWARAN S', '2005-10-07', 810023114030, 'MECHANICAL-A'),
('BHARANIVASAN T', '2005-10-09', 810023114031, 'MECHANICAL-A'),
('ROHESHWARAN S', '2006-08-02', 810023114032, 'MECHANICAL-A'),
('KAVI BHARATHI M', '2006-03-31', 810023114033, 'MECHANICAL-A'),
('DHINESHKUMAR G', '2005-10-26', 810023114034, 'MECHANICAL-A'),
('MOHAN G', '2006-05-07', 810023114035, 'MECHANICAL-A'),
('HARIGOVINDAN S', '2006-10-09', 810023114036, 'MECHANICAL-A'),
('SURAJ R', '2005-03-11', 810023114037, 'MECHANICAL-A'),
('AUSTIN S', '2005-09-08', 810023114038, 'MECHANICAL-A'),
('VINOTH KUMAR M', '2005-04-13', 810023114039, 'MECHANICAL-A'),
('KARTHIKEYAN B', '2006-01-11', 810023114040, 'MECHANICAL-A'),
('RAKSHITHA V', '2005-07-14', 810023114041, 'MECHANICAL-A'),
('SURJITH R S', '2006-02-04', 810023114042, 'MECHANICAL-A'),
('JEEVAA M', '2005-03-17', 810023114043, 'MECHANICAL-A'),
('MITHUN S', '2006-09-20', 810023114044, 'MECHANICAL-A'),
('BHARANIMUTHU V', '2005-10-02', 810023114045, 'MECHANICAL-A'),
('GURUMOORTHI M', '2006-06-09', 810023114046, 'MECHANICAL-A'),
('AKASH B', '2006-02-12', 810023114047, 'MECHANICAL-A'),
('PRAVINKUMAR B', '2006-06-06', 810023114048, 'MECHANICAL-A'),
('SHANJAI SRI RAM S', '2005-10-03', 810023114049, 'MECHANICAL-A'),
('RATHINAVEL S', '2005-11-02', 810023114050, 'MECHANICAL-A'),
('PREMKUMAR S', '2006-02-24', 810023114051, 'MECHANICAL-A'),
('THASEER ALI J', '2005-11-27', 810023114052, 'MECHANICAL-A'),
('AKASH M K', '2005-09-23', 810023114054, 'MECHANICAL-B'),
('BARATH KUMARAN E', '2005-11-07', 810023114055, 'MECHANICAL-B'),
('THIRUMOORTHI A', '2006-01-23', 810023114056, 'MECHANICAL-B'),
('DHARANI T', '2005-11-01', 810023114057, 'MECHANICAL-B'),
('MOHAMED REAYAS A', '2006-04-13', 810023114058, 'MECHANICAL-B'),
('DEVANESAN B', '2005-06-02', 810023114059, 'MECHANICAL-B'),
('SRIDHAR T', '2005-12-09', 810023114060, 'MECHANICAL-B'),
('SATHISH KUMAR G', '2005-10-23', 810023114061, 'MECHANICAL-B'),
('JEGATHEESWARAN T', '2006-07-15', 810023114062, 'MECHANICAL-B'),
('HARI PRASATH P', '2006-01-13', 810023114063, 'MECHANICAL-B'),
('MOUNIKA M', '2005-08-07', 810023114064, 'MECHANICAL-B'),
('KRISHNAKUMAR S', '2005-09-15', 810023114065, 'MECHANICAL-B'),
('PON AKASH P', '2005-12-07', 810023114066, 'MECHANICAL-B'),
('ATHARSH P', '2005-10-07', 810023114067, 'MECHANICAL-B'),
('MANIKANDAN K', '2006-12-11', 810023114068, 'MECHANICAL-B'),
('KAVIARASAN T', '2005-07-09', 810023114069, 'MECHANICAL-B'),
('DHILIP A', '2005-03-02', 810023114070, 'MECHANICAL-B'),
('MAHADEVAN V', '2006-03-13', 810023114071, 'MECHANICAL-B'),
('PRABANJAN P S', '2006-09-04', 810023114072, 'MECHANICAL-B'),
('NAVEEN KUMAR R', '2006-04-29', 810023114073, 'MECHANICAL-B'),
('SUTHARSAN B', '2005-11-14', 810023114074, 'MECHANICAL-B'),
('AKASH M', '2006-11-21', 810023114075, 'MECHANICAL-B'),
('VIKRAM S', '2004-11-22', 810023114076, 'MECHANICAL-B'),
('VISHNU S', '2006-07-05', 810023114077, 'MECHANICAL-B'),
('LENISH P', '2006-06-27', 810023114078, 'MECHANICAL-B'),
('BALAJI V', '2005-09-24', 810023114079, 'MECHANICAL-B'),
('BALA CHANDAR P', '2005-12-29', 810023114080, 'MECHANICAL-B'),
('GOKUL A', '2005-09-17', 810023114081, 'MECHANICAL-B'),
('JANA MURUGAPPA M', '2006-05-31', 810023114082, 'MECHANICAL-B'),
('ROSHAN FARITH S', '2006-03-18', 810023114083, 'MECHANICAL-B'),
('SIVABALAN K', '2005-07-15', 810023114084, 'MECHANICAL-B'),
('VIJAYARAJ K R', '2005-12-22', 810023114085, 'MECHANICAL-B'),
('SHANMUGANATHAN S', '2006-04-05', 810023114086, 'MECHANICAL-B'),
('NISHANTH KUMAR K', '2006-10-12', 810023114087, 'MECHANICAL-B'),
('NARESHKUMAR S', '2005-10-22', 810023114088, 'MECHANICAL-B'),
('GOBINATH R', '2006-06-17', 810023114089, 'MECHANICAL-B'),
('AMALESH A', '2006-02-15', 810023114090, 'MECHANICAL-B'),
('AATHIKESAVAN K', '2005-11-10', 810023114091, 'MECHANICAL-B'),
('SAMITH KANNA R', '2005-11-30', 810023114092, 'MECHANICAL-B'),
('BOOBALAN R', '2004-10-13', 810023114093, 'MECHANICAL-B'),
('NAVEEN B', '2005-12-01', 810023114094, 'MECHANICAL-B'),
('DEV ANAND K', '2006-06-19', 810023114096, 'MECHANICAL-B'),
('VIGNESH K', '2006-05-28', 810023114097, 'MECHANICAL-B'),
('JEEVANANTHAM M', '2005-07-21', 810023114098, 'MECHANICAL-B'),
('JAMERAJ S', '2005-10-14', 810023114099, 'MECHANICAL-B'),
('RAKESHKUMAR M', '2006-02-18', 810023114100, 'MECHANICAL-B'),
('ALAGUPRIYAN A', '2006-03-14', 810023114102, 'MECHANICAL-B'),
('PASUPATHI T', '2006-01-20', 810023114103, 'MECHANICAL-B'),
('SANTHOSH M', '2006-06-19', 810023114104, 'MECHANICAL-B'),
('INBARASAN K', '2005-12-26', 810023114106, 'MECHANICAL-B'),
('TAMILSELVAN M', '2004-05-19', 810023126001, 'CIVILMECHANICAL-TM'),
('MUTHULAKSHMI G', '2006-03-22', 810023126002, 'CIVILMECHANICAL-TM'),
('NANDHINI K', '2006-06-09', 810023126003, 'CIVILMECHANICAL-TM'),
('SRIPRIYA B', '2005-11-12', 810023126004, 'CIVILMECHANICAL-TM'),
('KIRUTHIGA S', '2006-04-20', 810023126005, 'CIVILMECHANICAL-TM'),
('DINESH P', '2005-11-02', 810023126006, 'CIVILMECHANICAL-TM'),
('KAVI ARASU C', '2005-12-13', 810023126007, 'CIVILMECHANICAL-TM'),
('SARANYA S', '2006-04-26', 810023126008, 'CIVILMECHANICAL-TM'),
('JANANI K', '2006-01-01', 810023126009, 'CIVILMECHANICAL-TM'),
('RUBASRI M', '2005-12-26', 810023126010, 'CIVILMECHANICAL-TM'),
('MADHUMITHA S', '2007-01-06', 810023126011, 'CIVILMECHANICAL-TM'),
('GANGANADHI P', '2006-09-25', 810023126012, 'CIVILMECHANICAL-TM'),
('SUVETHA V', '2006-02-24', 810023126013, 'CIVILMECHANICAL-TM'),
('ABIRAMI A', '2005-11-20', 810023126014, 'CIVILMECHANICAL-TM'),
('GOWTHAM V', '2006-04-07', 810023126015, 'CIVILMECHANICAL-TM'),
('KRISHNAVENI R', '2006-01-30', 810023126017, 'CIVILMECHANICAL-TM'),
('KARTHIKEYAN S', '2004-11-30', 810023126018, 'CIVILMECHANICAL-TM'),
('BUVANESH C', '2006-08-27', 810023126019, 'CIVILMECHANICAL-TM'),
('PATHMAVATHI L', '2006-06-10', 810023126020, 'CIVILMECHANICAL-TM'),
('MOHANA DEVI S', '2006-02-14', 810023126021, 'CIVILMECHANICAL-TM'),
('DHANUSHRAJAN K', '2006-07-15', 810023126022, 'CIVILMECHANICAL-TM'),
('PRADEEP V', '2006-08-22', 810023126023, 'CIVILMECHANICAL-TM'),
('AARTHY K', '2006-02-19', 810023126024, 'CIVILMECHANICAL-TM'),
('SELVAPRIYA P', '2005-11-23', 810023126025, 'CIVILMECHANICAL-TM'),
('PRABHA P', '2006-03-22', 810023126026, 'CIVILMECHANICAL-TM'),
('THIRUPATHI N', '2006-07-26', 810023126027, 'CIVILMECHANICAL-TM'),
('PRAVEENKUMAR S', '2005-09-09', 810023126028, 'CIVILMECHANICAL-TM'),
('AAKASH P', '2006-06-07', 810023126029, 'CIVILMECHANICAL-TM'),
('ABIRAMI B', '2005-10-08', 810023126030, 'CIVILMECHANICAL-TM'),
('HEMALATHA P', '2006-07-17', 810023126031, 'CIVILMECHANICAL-TM'),
('GUNA R', '2006-06-24', 810023126032, 'CIVILMECHANICAL-TM'),
('SHARUKHAN M', '2005-12-23', 810023126033, 'CIVILMECHANICAL-TM'),
('MATHIBALAN P', '2006-05-29', 810023126034, 'CIVILMECHANICAL-TM'),
('AJAY N', '2005-11-28', 810023126036, 'CIVILMECHANICAL-TM'),
('NAVEEN KUMAR S', '2005-09-06', 810023126037, 'CIVILMECHANICAL-TM'),
('PACHAIYAPPAN P', '2006-02-06', 810023126038, 'CIVILMECHANICAL-TM'),
('DHARNISH K', '2005-12-04', 810023126039, 'CIVILMECHANICAL-TM'),
('KANSHIYA S', '2006-04-22', 810023126040, 'CIVILMECHANICAL-TM'),
('KAVITHASAN M', '2005-11-29', 810023126041, 'CIVILMECHANICAL-TM'),
('SHARMILI M', '2006-02-02', 810023126042, 'CIVILMECHANICAL-TM'),
('VANISRI R', '2005-12-14', 810023126043, 'CIVILMECHANICAL-TM'),
('YOGESH J', '2005-09-11', 810023126044, 'CIVILMECHANICAL-TM'),
('PRAVEEN KUMAR M', '2005-03-26', 810023126045, 'CIVILMECHANICAL-TM'),
('KIRAN SANKAR R', '2005-07-06', 810023126046, 'CIVILMECHANICAL-TM'),
('ABINAYA A', '2006-05-24', 810023126047, 'CIVILMECHANICAL-TM'),
('HARISH R V', '2006-08-20', 810023126048, 'CIVILMECHANICAL-TM'),
('ADHITHYA A', '2006-03-22', 810023126049, 'CIVILMECHANICAL-TM'),
('AMUDHAN S', '2005-05-17', 810023127001, 'CIVILMECHANICAL-TM'),
('SEVVELJAYAM S', '2005-10-05', 810023127002, 'CIVILMECHANICAL-TM'),
('ANDAVAR K', '2006-04-08', 810023127003, 'CIVILMECHANICAL-TM'),
('ASHWIN G', '2006-04-08', 810023127004, 'CIVILMECHANICAL-TM'),
('NAWINKUMAAR V', '2005-11-04', 810023127005, 'CIVILMECHANICAL-TM'),
('XAVIER AKASH A', '2005-12-03', 810023127006, 'CIVILMECHANICAL-TM'),
('KAVEENA M', '2005-10-13', 810023127007, 'CIVILMECHANICAL-TM'),
('NAVEEN S', '2006-05-14', 810023127008, 'CIVILMECHANICAL-TM'),
('BALAKRISHNAN R', '2005-11-06', 810023127009, 'CIVILMECHANICAL-TM'),
('MOHAN PANDI D', '2006-03-14', 810023127010, 'CIVILMECHANICAL-TM'),
('DHANARANGAN R', '2005-12-17', 810023127011, 'CIVILMECHANICAL-TM'),
('SAKTHIVEL P', '2006-07-22', 810023127012, 'CIVILMECHANICAL-TM'),
('PUNITH S', '2006-05-16', 810023127013, 'CIVILMECHANICAL-TM'),
('SRIDHAR T', '2005-12-21', 810023127014, 'CIVILMECHANICAL-TM'),
('VENKATARAJ V', '2004-11-21', 810023127015, 'CIVILMECHANICAL-TM'),
('SHAMEER AKTHAR S', '2005-03-25', 810023127016, 'CIVILMECHANICAL-TM'),
('GOWSHIKKUMAR S', '2006-05-05', 810023127017, 'CIVILMECHANICAL-TM'),
('SURYA S', '2006-02-17', 810023205001, 'IT-A'),
('NIRANJAN R', '2006-06-19', 810023205002, 'IT-A'),
('GIRIJA K', '2007-01-29', 810023205003, 'IT-A'),
('DHIVYA M', '2005-10-15', 810023205004, 'IT-A'),
('SENTHAMIZHAN A', '2006-04-20', 810023205005, 'IT-A'),
('KEERTHIVASAN P S', '2006-06-16', 810023205006, 'IT-A'),
('PRAKASH M', '2005-05-05', 810023205007, 'IT-A'),
('HARIHARAN T', '2006-07-25', 810023205008, 'IT-A'),
('SIVA SANKAR V', '2005-12-18', 810023205009, 'IT-A'),
('PUGAZHESHWARAN V', '2006-06-23', 810023205010, 'IT-A'),
('VIGNESHWARAN S', '2005-11-05', 810023205011, 'IT-A'),
('SATHIYA M', '2006-01-04', 810023205012, 'IT-A'),
('AJAY D', '2005-09-25', 810023205013, 'IT-A'),
('DHANALAKSHMI S', '2006-08-15', 810023205014, 'IT-A'),
('DESIKA S', '2005-12-10', 810023205015, 'IT-A'),
('GOVARDHAN S', '2005-10-24', 810023205016, 'IT-A'),
('ABINAYA U', '2006-04-13', 810023205017, 'IT-A'),
('JONES PRISTY D', '2006-05-31', 810023205018, 'IT-A'),
('DHAARANYA S', '2006-06-29', 810023205019, 'IT-A'),
('HARINI K', '2006-01-20', 810023205020, 'IT-A'),
('ANTIN SHERIN V U', '2006-05-18', 810023205021, 'IT-A'),
('BARATH R', '2006-08-26', 810023205022, 'IT-A'),
('SAFILA FARHATH A S', '2005-11-09', 810023205023, 'IT-A'),
('BHARATHI M', '2005-08-09', 810023205024, 'IT-A'),
('ARCHANA J', '2006-06-09', 810023205025, 'IT-A'),
('KAAVYA VARSHA R', '2005-08-01', 810023205026, 'IT-A'),
('KARNIKA S', '2005-03-21', 810023205027, 'IT-A'),
('JAYA BHARATHI S', '2005-10-31', 810023205028, 'IT-A'),
('GUNAVARTHINI K', '2006-03-17', 810023205029, 'IT-A'),
('DHANASEKAR K', '2006-05-17', 810023205030, 'IT-A'),
('SURJITH S', '2005-10-26', 810023205031, 'IT-A'),
('ANUSUYA V', '2005-06-15', 810023205032, 'IT-A'),
('KEERTHIKA G B', '2005-12-07', 810023205033, 'IT-A'),
('JANANI L', '2005-11-20', 810023205034, 'IT-A'),
('PAVITHRA J', '2006-01-20', 810023205035, 'IT-A'),
('PRAKASH S', '2006-10-19', 810023205036, 'IT-A'),
('SWATHI K', '2005-12-08', 810023205037, 'IT-A'),
('THEJASH S', '2005-08-12', 810023205038, 'IT-A'),
('HARIKRISHNAN T', '2006-04-06', 810023205039, 'IT-A'),
('RAJESHWARI P', '2006-09-17', 810023205040, 'IT-A'),
('SARIHA S', '2005-10-03', 810023205041, 'IT-A'),
('MANOBALA T N', '2005-09-04', 810023205042, 'IT-A'),
('AJAY A', '2004-02-08', 810023205043, 'IT-A'),
('MUHAMMED AARIF J', '2006-05-26', 810023205044, 'IT-A'),
('ARUNKUMAR M', '2005-11-28', 810023205045, 'IT-A'),
('NIRAIMATHI M', '2004-09-14', 810023205046, 'IT-A'),
('HEYMANTH S M', '2005-10-25', 810023205047, 'IT-A'),
('NIVEDHA M', '2006-01-02', 810023205048, 'IT-A'),
('DEEPAN RAJA G', '2005-09-18', 810023205049, 'IT-A'),
('ESSTHAR ANNAL J', '2004-08-10', 810023205050, 'IT-A'),
('MOHAMED ISRIN A', '2004-10-25', 810023205051, 'IT-A'),
('SRI RAGABHARATHI R', '2006-02-14', 810023205052, 'IT-A'),
('ROJITH R A', '2005-06-24', 810023205053, 'IT-A'),
('SINDHUJA S', '2006-07-17', 810023205054, 'IT-A'),
('RAJIVI M', '2005-11-20', 810023205055, 'IT-A'),
('LAKSHANA M', '2006-01-09', 810023205056, 'IT-A'),
('VENMANI V', '2006-05-15', 810023205057, 'IT-A'),
('PRAKASH S', '2005-10-03', 810023205058, 'IT-A'),
('KALAIYARASI M', '2005-12-07', 810023205059, 'IT-B'),
('LOGESHKUMAR M', '2006-04-01', 810023205060, 'IT-B'),
('SUGANTHAN R', '2006-05-24', 810023205061, 'IT-B'),
('VIGNESHWARAN L', '2006-05-15', 810023205062, 'IT-B'),
('SANTHOSH A', '2005-10-04', 810023205063, 'IT-B'),
('MADHUMITHA R', '2003-12-21', 810023205064, 'IT-B'),
('KEERTHANA', '2005-09-15', 810023205065, 'IT-B'),
('KEERTHANA A', '2006-03-25', 810023205066, 'IT-B'),
('GOMATHI R', '2005-03-09', 810023205067, 'IT-B'),
('KEERTHANA R', '2006-03-11', 810023205068, 'IT-B'),
('SARANRAJ R', '2006-05-18', 810023205069, 'IT-B'),
('EZHILARASAN J', '2006-05-26', 810023205070, 'IT-B'),
('DEEPADHARSHINI M', '2006-06-09', 810023205071, 'IT-B'),
('SRINITHI S', '2005-11-03', 810023205072, 'IT-B'),
('BHARATHI P', '2005-09-12', 810023205073, 'IT-B'),
('SRIBALAJI G', '2005-11-12', 810023205074, 'IT-B'),
('RAHUL K', '2005-08-13', 810023205075, 'IT-B'),
('ARJUN C', '2006-06-08', 810023205076, 'IT-B'),
('SIVAPRASANTH', '2006-01-04', 810023205077, 'IT-B'),
('PRICIKA K', '2006-04-12', 810023205078, 'IT-B'),
('SRIMATHI J', '2005-09-18', 810023205079, 'IT-B'),
('ABITHADEVI R', '2006-07-08', 810023205081, 'IT-B'),
('MOHANRAJ V', '2006-05-08', 810023205082, 'IT-B'),
('JANANI S', '2006-03-23', 810023205083, 'IT-B'),
('AKSHAYA S', '2005-06-04', 810023205084, 'IT-B'),
('LAVANYA A', '2003-05-18', 810023205085, 'IT-B'),
('SUVARNALEKHAA N', '2005-08-24', 810023205086, 'IT-B'),
('KESAVAN E', '2005-08-03', 810023205087, 'IT-B'),
('BHAVADHARANI B', '2006-06-25', 810023205088, 'IT-B'),
('LAVANYA D', '2006-02-05', 810023205089, 'IT-B'),
('SANTHIYA E', '2006-08-14', 810023205090, 'IT-B'),
('RANGANATHAN M', '2004-05-08', 810023205091, 'IT-B'),
('JAI AAKASH R', '2005-09-06', 810023205092, 'IT-B'),
('KARTHIKEYAN H', '2006-01-10', 810023205093, 'IT-B'),
('JANAHAN E', '2005-05-27', 810023205094, 'IT-B'),
('MANOJ C', '2005-07-10', 810023205095, 'IT-B'),
('YOGESH U G', '2005-10-08', 810023205096, 'IT-B'),
('JANARANJANI M', '2005-11-07', 810023205097, 'IT-B'),
('ABISHEK K', '2005-11-13', 810023205098, 'IT-B'),
('HARINI S', '2006-03-09', 810023205099, 'IT-B'),
('MARY SHALINI A', '2006-01-19', 810023205100, 'IT-B'),
('SATHYASEELAN', '2005-03-14', 810023205101, 'IT-B'),
('VARSHA T', '2005-04-01', 810023205102, 'IT-B'),
('KISHORE R', '2005-05-14', 810023205103, 'IT-B'),
('AHAMED NOOR Z', '2004-05-15', 810023205104, 'IT-B'),
('SANGEETHA M', '2006-04-20', 810023205105, 'IT-B'),
('ANBUKUMAR M', '2006-03-07', 810023205106, 'IT-B'),
('RAVINASRI R', '2006-07-01', 810023205107, 'IT-B'),
('MARUTHAKUMARAN M', '2006-01-04', 810023205108, 'IT-B'),
('MANIKANDAN', '2006-03-28', 810023205110, 'IT-B'),
('NAVEEN M', '2006-08-03', 810023205111, 'IT-B'),
('SIVABALAN S', '2005-05-27', 810023205112, 'IT-B'),
('KAVINRAJAN K', '2006-01-17', 810023205113, 'IT-B'),
('ELAIYAMUGILAN S', '2005-07-30', 810023205114, 'IT-B'),
('HITHESH K', '2005-09-01', 810023205115, 'IT-B'),
('GOKULNATH V', '2006-01-14', 810023205116, 'IT-B'),
('PREM PRADHYUSH B A', '2005-10-29', 810023214001, 'BIOTECH'),
('ABISHEK S', '2006-06-08', 810023214002, 'BIOTECH'),
('NATRAJ R', '2003-09-12', 810023214003, 'BIOTECH'),
('PRIYADHARSHINI P', '2006-03-22', 810023214004, 'BIOTECH'),
('SURYASELVAN E', '2005-06-13', 810023214005, 'BIOTECH'),
('RAYAN AFRIN S', '2006-01-13', 810023214006, 'BIOTECH'),
('PRIYADHARSHINI B', '2005-12-23', 810023214007, 'BIOTECH'),
('VENKATESHWARI S', '2006-02-13', 810023214008, 'BIOTECH'),
('KAMALIKA M', '2005-11-19', 810023214009, 'BIOTECH'),
('AAQIF ALI N R', '2005-10-24', 810023214010, 'BIOTECH'),
('PREETHI JESSICA K', '2005-09-12', 810023214011, 'BIOTECH'),
('DHANUJA SRI N', '2006-06-13', 810023214013, 'BIOTECH'),
('SRIDHAR M', '2006-12-24', 810023214014, 'BIOTECH'),
('GOPIKRISHNAN A', '2005-10-15', 810023214015, 'BIOTECH'),
('MOURIYA J', '2005-08-07', 810023214016, 'BIOTECH'),
('GUNA S', '2006-03-18', 810023214017, 'BIOTECH'),
('ARUNADEVI R', '2006-07-05', 810023214018, 'BIOTECH'),
('LOGESHWARI P', '2005-11-16', 810023214019, 'BIOTECH'),
('NAVEEN KARTHIKEYAN R', '2005-09-10', 810023214020, 'BIOTECH'),
('MATHIVATHANI U', '2006-09-12', 810023214021, 'BIOTECH'),
('MADHUSRI V', '2006-06-30', 810023214022, 'BIOTECH'),
('SANKARIYYA S', '2006-05-20', 810023214023, 'BIOTECH'),
('KIRUBASANKARI J', '2005-12-05', 810023214024, 'BIOTECH'),
('PRIYADHARSHINI A', '2005-11-25', 810023214025, 'BIOTECH'),
('SUBIKSHA J', '2005-09-20', 810023214026, 'BIOTECH'),
('FLORENCE HINRIKA B', '2005-07-13', 810023214027, 'BIOTECH'),
('DHANUSH J U', '2006-03-01', 810023214028, 'BIOTECH'),
('SOWMIYA S', '2005-04-10', 810023214029, 'BIOTECH'),
('ABIRAMI S', '2006-06-10', 810023214030, 'BIOTECH'),
('SANCHITHA R S', '2006-06-06', 810023214031, 'BIOTECH'),
('HEMA SHALINI S', '2006-05-04', 810023214032, 'BIOTECH'),
('PRIYADHARSHINI V', '2004-08-02', 810023214033, 'BIOTECH'),
('DHARANI M', '2006-06-18', 810023214034, 'BIOTECH'),
('MAHESHWARAN S', '2005-07-10', 810023214035, 'BIOTECH'),
('DIVAHAR S', '2006-03-28', 810023214036, 'BIOTECH'),
('DHANYA M', '2006-02-01', 810023214037, 'BIOTECH'),
('JASMINE SHARMILA S', '2005-12-26', 810023214038, 'BIOTECH'),
('NANDHINI S', '2005-12-31', 810023214039, 'BIOTECH'),
('BAVATHARANI S', '2005-01-02', 810023214040, 'BIOTECH'),
('SHREYA B', '2006-01-31', 810023214041, 'BIOTECH'),
('SHILVIYA R', '2003-10-15', 810023214042, 'BIOTECH'),
('LOGESHWARAN K', '2006-01-09', 810023214043, 'BIOTECH'),
('DARWIN NAAKENDIRAN D', '2006-05-07', 810023214044, 'BIOTECH'),
('SARANYAESHWARI S', '2006-08-26', 810023214045, 'BIOTECH'),
('ABARNA P S', '2004-09-21', 810023214046, 'BIOTECH'),
('KEERTHIKA R', '2006-09-06', 810023214047, 'BIOTECH'),
('DEEPIKA T', '2006-07-06', 810023214048, 'BIOTECH'),
('GLADSON RAJ I', '2006-05-15', 810023214049, 'BIOTECH'),
('MAHABUNISHA M', '2005-01-11', 810023214050, 'BIOTECH'),
('JANANI S', '2006-04-21', 810023214051, 'BIOTECH'),
('SELVAKUMAR S', '2006-06-19', 810023214053, 'BIOTECH'),
('SURUTHI M', '2006-05-21', 810023214054, 'BIOTECH'),
('SHYJU WILSON R', '2005-07-22', 810023237001, 'PHARMA'),
('PODHIGAI THENDRAL K', '2005-12-04', 810023237002, 'PHARMA'),
('SRINITHI S', '2006-02-15', 810023237003, 'PHARMA'),
('DHURAI KALIRAJ M', '2006-04-08', 810023237004, 'PHARMA'),
('NIHITHA A', '2005-11-04', 810023237005, 'PHARMA'),
('YUVASRII R N', '2005-10-09', 810023237006, 'PHARMA'),
('PUSHPA V', '2005-07-22', 810023237007, 'PHARMA'),
('ARUN EDWIN Y', '2005-08-20', 810023237008, 'PHARMA'),
('DHARSHINI TR', '2006-03-28', 810023237009, 'PHARMA'),
('KRISHNASOMI S', '2006-08-09', 810023237011, 'PHARMA'),
('SOWMIYA M', '2006-03-31', 810023237012, 'PHARMA'),
('BHUVANESHWARI V', '2005-11-01', 810023237013, 'PHARMA'),
('VIJAY S', '2005-12-16', 810023237014, 'PHARMA'),
('ANANTH B', '2005-07-07', 810023237015, 'PHARMA'),
('ASHIK SANDHIYAGU J', '2006-07-20', 810023237016, 'PHARMA'),
('SANTHOSH R', '2006-06-04', 810023237018, 'PHARMA'),
('KRISHNA DHARA S', '2005-08-30', 810023237019, 'PHARMA'),
('RENUGADEVI M', '2005-09-28', 810023237020, 'PHARMA'),
('AMIRTHA SRI R', '2005-07-02', 810023237021, 'PHARMA'),
('HARINI M', '2006-09-06', 810023237022, 'PHARMA'),
('GOWNITHA N', '2006-06-01', 810023237023, 'PHARMA'),
('HARI SUDHARSAN S', '2005-11-22', 810023237024, 'PHARMA'),
('MUTHUMARI B', '2005-11-04', 810023237025, 'PHARMA'),
('AARTHI B', '2005-10-04', 810023237026, 'PHARMA'),
('AKILANDESHWARI S', '2006-04-01', 810023237028, 'PHARMA'),
('YOGESHWARI M', '2006-01-27', 810023237029, 'PHARMA'),
('SIVABHARATHI', '2006-01-13', 810023237030, 'PHARMA'),
('MEGANATHAN J', '2005-11-23', 810023237031, 'PHARMA'),
('THENMOZHI R', '2006-05-04', 810023237032, 'PHARMA'),
('PAVITHRA B', '2005-11-19', 810023237033, 'PHARMA'),
('SAMYUKTHA M S', '2005-09-25', 810023237034, 'PHARMA'),
('HEMALEKHAA G M', '2005-09-28', 810023237035, 'PHARMA'),
('VETHA VARSHINI K G', '2006-09-14', 810023237036, 'PHARMA'),
('HARIHARAN K', '2005-05-13', 810023237037, 'PHARMA'),
('AATHITHYA M', '2005-09-16', 810023237038, 'PHARMA'),
('ASMIYA M', '2005-11-07', 810023237039, 'PHARMA'),
('POORNITHA B', '2006-07-30', 810023237040, 'PHARMA'),
('SRIRAM C', '2006-03-02', 810023237041, 'PHARMA'),
('SHRI HARINI C', '2005-01-28', 810023237042, 'PHARMA'),
('KIRUBA S', '2006-07-22', 810023237043, 'PHARMA'),
('MADHUMITHA K', '2005-11-23', 810023237044, 'PHARMA'),
('KARTHIGA DEVI M', '2006-05-28', 810023237045, 'PHARMA'),
('JEETIKA S', '2006-05-19', 810023237046, 'PHARMA'),
('DHINESHKUMAR N', '2006-05-02', 810023237047, 'PHARMA'),
('JOTHEESHWARAN I', '2005-10-13', 810023237048, 'PHARMA'),
('NAOFIL ADAM M', '2005-11-24', 810023237049, 'PHARMA'),
('HASHINI C', '2005-09-26', 810023237050, 'PHARMA'),
('HARINI SRI B', '2006-07-06', 810023237051, 'PHARMA'),
('SWETHA S', '2005-10-28', 810023237052, 'PHARMA'),
('PRADEEP KUMAR M', '2006-05-14', 810023237053, 'PHARMA'),
('HAARES KANNAN G', '2006-05-03', 810023237054, 'PHARMA'),
('KARNA P', '2006-06-27', 810023239001, 'PETRO'),
('NITHYA SHREE R', '2006-02-28', 810023239002, 'PETRO'),
('NAVEEN KUMAR M', '2005-09-19', 810023239003, 'PETRO'),
('PRIYADHARSHINI U', '2004-11-19', 810023239004, 'PETRO'),
('ARUL SELVAN A', '2006-10-29', 810023239005, 'PETRO'),
('ANTO MIC JERSON G', '2006-03-09', 810023239006, 'PETRO'),
('SWETHA S', '2006-02-17', 810023239007, 'PETRO'),
('NITHIYANANTHA B', '2005-08-14', 810023239008, 'PETRO'),
('RESHMA J', '2006-05-18', 810023239009, 'PETRO'),
('VISHANTH D', '2006-01-11', 810023239010, 'PETRO'),
('KARTHIKA K', '2005-07-13', 810023239011, 'PETRO'),
('PRIYATHARSHINI G', '2006-03-22', 810023239012, 'PETRO'),
('ARAVINDH A', '2005-06-05', 810023239013, 'PETRO'),
('RAMYA R', '2006-07-21', 810023239014, 'PETRO'),
('ANBUCHELVAN S', '2005-07-13', 810023239015, 'PETRO'),
('VIMALRAJ S', '2006-07-05', 810023239016, 'PETRO'),
('LAKSHMANAN T', '2005-08-25', 810023239017, 'PETRO'),
('RAMKUMAR S', '2005-12-15', 810023239018, 'PETRO'),
('NAVDEEP S', '2006-06-11', 810023239019, 'PETRO'),
('AVINASH PG', '2005-11-13', 810023239020, 'PETRO'),
('HARINI LAKSHMI K', '2006-01-13', 810023239021, 'PETRO'),
('DHARSHAN M S', '2005-03-22', 810023239022, 'PETRO'),
('RIYAS MOHAMED S', '2006-06-14', 810023239023, 'PETRO'),
('SRIRAM K', '2006-04-06', 810023239024, 'PETRO'),
('ROJITHMANI S', '2006-02-19', 810023239025, 'PETRO'),
('KISOTH KUMAR S', '2006-01-02', 810023239026, 'PETRO'),
('VIDYACHARAN S', '2006-10-11', 810023239027, 'PETRO'),
('HARINI V', '2005-11-20', 810023239028, 'PETRO'),
('IDHAYA RANJAN I', '2005-09-08', 810023239029, 'PETRO'),
('ASEENA FATHIMA S', '2005-09-30', 810023239030, 'PETRO'),
('CHANDRU M', '2006-04-26', 810023239031, 'PETRO'),
('KAVIYA M', '2005-12-07', 810023239032, 'PETRO'),
('MATHIARASU M', '2002-03-25', 810023239033, 'PETRO'),
('SWETHA R U', '2005-11-14', 810023239034, 'PETRO'),
('ABINAYA SRI M', '2005-03-14', 810023239035, 'PETRO'),
('MOHAMMED MAHMOOD M', '2005-06-28', 810023239036, 'PETRO'),
('SOORYA T', '2005-06-10', 810023239037, 'PETRO'),
('SUDHARSAN B', '2006-04-27', 810023239038, 'PETRO'),
('MADESH P', '2004-08-18', 810023239039, 'PETRO'),
('BHARATH R', '2006-06-19', 810023239040, 'PETRO'),
('DISHYAMENAN R', '2006-03-02', 810023239041, 'PETRO'),
('RAKESH KUMAR M', '2006-10-03', 810023239042, 'PETRO'),
('VIGNESH S', '2005-11-30', 810023239043, 'PETRO'),
('HARIHARAN R', '2006-05-31', 810023239044, 'PETRO'),
('VISWA P', '2005-06-19', 810023239045, 'PETRO'),
('AAKASH M', '2005-10-17', 810023239047, 'PETRO'),
('SWETHA S', '2006-03-01', 810023239048, 'PETRO'),
('VISHWA M', '2005-08-21', 810023239049, 'PETRO'),
('PARASURAMAN B', '2005-11-15', 810023239050, 'PETRO'),
('VIJAYALAKSHMI K', '2005-11-20', 810023239051, 'PETRO'),
('DARSHAN B', '2004-09-27', 810023239052, 'PETRO'),
('KARTHI KEYAN M', '2005-12-07', 810023239053, 'PETRO');

-- --------------------------------------------------------

--
-- Table structure for table `totalautomobile`
--

CREATE TABLE `totalautomobile` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `totalbiotech`
--

CREATE TABLE `totalbiotech` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalbiotech`
--

INSERT INTO `totalbiotech` (`subcode`, `totalmark`, `totalattendance`) VALUES
('GE3151', 100, 18),
('HS3152', 100, 23);

-- --------------------------------------------------------

--
-- Table structure for table `totalcivila`
--

CREATE TABLE `totalcivila` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalcivila`
--

INSERT INTO `totalcivila` (`subcode`, `totalmark`, `totalattendance`) VALUES
('PH3151', 100, 29);

-- --------------------------------------------------------

--
-- Table structure for table `totalcivilb`
--

CREATE TABLE `totalcivilb` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalcivilb`
--

INSERT INTO `totalcivilb` (`subcode`, `totalmark`, `totalattendance`) VALUES
('MA3151', 100, 30),
('PH3151', 100, 26);

-- --------------------------------------------------------

--
-- Table structure for table `totalcivilmechanicaltm`
--

CREATE TABLE `totalcivilmechanicaltm` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalcivilmechanicaltm`
--

INSERT INTO `totalcivilmechanicaltm` (`subcode`, `totalmark`, `totalattendance`) VALUES
('MA3151', 100, 34);

-- --------------------------------------------------------

--
-- Table structure for table `totalcsea`
--

CREATE TABLE `totalcsea` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalcsea`
--

INSERT INTO `totalcsea` (`subcode`, `totalmark`, `totalattendance`) VALUES
('GE3151', 100, 19),
('CY3151', 100, 24),
('MA3151', 100, 37);

-- --------------------------------------------------------

--
-- Table structure for table `totalcseb`
--

CREATE TABLE `totalcseb` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `totalecea`
--

CREATE TABLE `totalecea` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalecea`
--

INSERT INTO `totalecea` (`subcode`, `totalmark`, `totalattendance`) VALUES
('GE3151', 100, 16),
('MA3151', 100, 26),
('CY3151', 100, 28),
('HS3152', 100, 19),
('PH3151', 100, 23);

-- --------------------------------------------------------

--
-- Table structure for table `totaleceb`
--

CREATE TABLE `totaleceb` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `totaleeea`
--

CREATE TABLE `totaleeea` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `totaleeeb`
--

CREATE TABLE `totaleeeb` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `totalita`
--

CREATE TABLE `totalita` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalita`
--

INSERT INTO `totalita` (`subcode`, `totalmark`, `totalattendance`) VALUES
('GE3151', 100, 19),
('CY3151', 100, 20),
('HS3152', 100, 23),
('MA3151', 100, 32);

-- --------------------------------------------------------

--
-- Table structure for table `totalitb`
--

CREATE TABLE `totalitb` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalitb`
--

INSERT INTO `totalitb` (`subcode`, `totalmark`, `totalattendance`) VALUES
('GE3151', 100, 14),
('HS3152', 100, 21);

-- --------------------------------------------------------

--
-- Table structure for table `totalmechanicala`
--

CREATE TABLE `totalmechanicala` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalmechanicala`
--

INSERT INTO `totalmechanicala` (`subcode`, `totalmark`, `totalattendance`) VALUES
('HS3152', 100, 20),
('MA3151', 100, 30),
('GE3152', 100, 8);

-- --------------------------------------------------------

--
-- Table structure for table `totalmechanicalb`
--

CREATE TABLE `totalmechanicalb` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalmechanicalb`
--

INSERT INTO `totalmechanicalb` (`subcode`, `totalmark`, `totalattendance`) VALUES
('MA3151', 100, 30);

-- --------------------------------------------------------

--
-- Table structure for table `totalpetro`
--

CREATE TABLE `totalpetro` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalpetro`
--

INSERT INTO `totalpetro` (`subcode`, `totalmark`, `totalattendance`) VALUES
('GE3151', 100, 19),
('HS3152', 100, 24);

-- --------------------------------------------------------

--
-- Table structure for table `totalpharma`
--

CREATE TABLE `totalpharma` (
  `subcode` varchar(10) DEFAULT NULL,
  `totalmark` int(5) DEFAULT NULL,
  `totalattendance` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `totalpharma`
--

INSERT INTO `totalpharma` (`subcode`, `totalmark`, `totalattendance`) VALUES
('GE3151', 100, 22);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
