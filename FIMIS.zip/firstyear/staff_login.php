
<?php

  function check()
  {
      include("config.php");
      $r=$_POST['usname'];
      $s=$_POST['passwor'];
	    if ($conn->connect_error) 
      {
		    die("Connection failed: " . $conn->connect_error);
	    }

	    $sql = "SELECT * FROM faculty WHERE email = '$r'";
	    $result = $conn->query($sql);
      $row = $result->fetch_assoc();
      if($row['email']==$r and $row['staffdept']==$s)
      {
        mainfunc();
        
      }
      else
      {
        echo "<script>alert('Invalid Username or Password');</script>";
        echo "<script>window.location.href='staff_login.html';</script>";
      }
  }
check();
function mainfunc(){
  $r=$_POST['usname'];
  $s=$_POST['passwor'];
  include("config.php");

$sql1 =mysqli_query($conn,"SELECT * FROM faculty WHERE email = '$r'");
?>
<style>
    body
        {   position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg,#00d47f, #ee0979, #00c2d2, #ee0979 );

            background-size: 400% 400%;
            animation: gradient 15s ease infinite;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
          }
        h2{
            font-family:sans-serif;
            font-weight:bold;
          }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.3);
            width: 300px;
            margin: 0 auto;
            animation: fade-in 1s ease-in;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        select, input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }

        @keyframes fade-in {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
    </style>

<center><h2>Faculty Information</h2><center>
<form action="entry/aaa/index.php" method="post">
<div class="ad">
  <div class="container">
  <h2>Name</h2>
<select>
  <?php
  while($r= mysqli_fetch_array($sql1))
  {
    ?>
    <option><?php echo $r['name'];?></option>
    <?php
    break;
    }
?>
</select>
<h2>Department</h2>

<select>
 <?php
 $r=$_POST['usname'];
 $s=$_POST['passwor'];
 include("config.php");
 $sql2 =mysqli_query($conn,"SELECT * FROM faculty WHERE email = '$r'");
while($r2= mysqli_fetch_array($sql2))
{
 ?>
 <option><?php echo $r2['staffdept'];?></option>
 <?php
 break;
}
?>
</select>

<h2>Semester</h2>
<select>
<?php
 $r=$_POST['usname'];
 $s=$_POST['passwor'];
 include("config.php");

 $sql3 =mysqli_query($conn,"SELECT * FROM faculty WHERE email = '$r'");
while($r3= mysqli_fetch_array($sql3))
{
 ?>
 <option><?php echo $r3['semester'];?></option>
 <?php
 break;
}
?>
</select>
<h2>Class</h2>

<select name="clshandle">
<?php
 $r=$_POST['usname'];
 $s=$_POST['passwor'];
 include("config.php");

 $sql4 =mysqli_query($conn,"SELECT * FROM faculty WHERE email = '$r'");
while($r4= mysqli_fetch_array($sql4))
{
 ?>
 <option><?php echo $r4['clshandle'];?></option>
 <?php
}
?>
</select>

<h2>SUB code</h2>
<select name="subject">
  <?php
    $r=$_POST['usname'];
    $s=$_POST['passwor'];
    include("config.php");

    $sql5 =mysqli_query($conn,"SELECT * FROM faculty WHERE email = '$r'");
  while($r1= mysqli_fetch_array($sql5))
  {
    ?>
    <option><?php echo $r1['subcode'];?></option>
    <?php
  }
  ?>
</select><br><br>
<center><input type="submit" value="Upload Marks"></center>

</div>
</div>
</form>
<?php
}
?>