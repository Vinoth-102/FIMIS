<?php
// Database configuration
include("config.php");
try {
    // Create a database connection
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit();
}

$tableName2 = 'eceb_final_report';

// Replace with your table name

// SQL query to fetch data from the table
$sql2 = "SELECT * FROM $tableName2";
$stmt2 = $conn->query($sql2);
$data2 = $stmt2->fetchAll(PDO::FETCH_ASSOC);

$sql3 = "SELECT * FROM totaleceb";
$stmt3 = $conn->query($sql3);
$data3 = $stmt3->fetchAll(PDO::FETCH_ASSOC);



// CSV file name
$csvFileName2 = 'ECE_B_FINAL.csv';

// Open a new CSV file for writing
$file2 = fopen($csvFileName2, 'w');

// Write a header row to the CSV
try{
error_reporting(0);
$abc=array(["UNIVERSITY COLLEGE OF ENGINEERING, BIT CAMPUS, ANNA UNIVERSITY,TIRUCHIRAPPALLI - 620024",]);
foreach($abc as $a){
fputcsv($file2, $a);
}


/** *****************************/

$abc=array([" FIRST YEAR B.E./B.TECH. SECOND SEMESTER 2022 -2023 "]);
foreach($abc as $a){
fputcsv($file2, $a);
}

$abc=array([" Revised R- 2021 (CBCS)  "]);
foreach($abc as $a){
fputcsv($file2, $a);
}

$abc=array([" Class Advisor : "," "," FIRST  INTERNAL ASSESSMENT TEST MARKS (FIRST SEMESTER)"," ","First report Period:"]);
foreach($abc as $a){
fputcsv($file2, $a);
}

/** **************************/
$abc=array(["DEPT : ECE-B"]);
foreach($abc as $a){
fputcsv($file2, $a);
}
$header2 = array_keys($data2[0]);

include("config1.php");

$l=count($header2);
$j=2;
for($i=0;$i<$l-3;$i++){
    if($j%2==0){
        $sub = strtoupper(substr($header2[$j],0,6));
        $q = "SELECT * FROM totaleceb WHERE subcode = '$sub';";
        $res = $conn1->query($q);
        while($row = $res->fetch_assoc()){
            $header2[$j] = $header2[$j]."(".$row["totalattendance"].")";
        }
        $j++;
    }
    else{
        $sub = strtoupper(substr($header2[$j],0,6));
        $q = "SELECT * FROM totaleceb WHERE subcode = '$sub';";
        $res = $conn1->query($q);
        while($row = $res->fetch_assoc()){
            $header2[$j] = $header2[$j]."(".$row["totalmark"].")";
        }
        $j++;
    }
}

for($i=0;$i<$l;$i++){
    $header2[$i] = strtoupper($header2[$i]);
}

/********************* */



$imp = array();
for($i=0;$i<$l-2;$i++){
    $imp[$i] = substr($header2[$i],0,6);
}
$imp[0] = " ";
$imp[1] = " ";
fputcsv($file2, $imp);

for($i=2;$i<$l;$i++){
    if($i == $l-2){
        break;
    }
    $header2[$i] = substr($header2[$i],7,3).substr($header2[$i],-5);
    
}

/****************************** */





fputcsv($file2, $header2);
}catch(TypeError $e){
    echo "Error : Either All Subject Marks Not Uploaded OR Incorrect Values Uploaded.";
    include("config.php");
    $q1 = "DROP TABLE eceb_final_report";
    $res = mysqli_query($conn,$q1);
    exit;
}

// Write the data to the CSV
foreach ($data2 as $row2) {
    fputcsv($file2, $row2);
}

/*try{
    $header3 = array_keys($data3[0]);
    fputcsv($file2, $header3);
    }catch(TypeError $e){
        echo "Error : Either All Subject Marks Not Uploaded OR Incorrect Values Uploaded.";
        exit;
    }

foreach ($data3 as $row3) {
    fputcsv($file2, $row3);
}*/

fclose($file2);

// Create a download link for the CSV file
$downloadLink2 = '<a href="' . $csvFileName2 . '" download>Download ECE_B Report</a>';

echo "ECE_B Final Report Successfully Generated: $csvFileName2<br>";
echo "Click here to download: $downloadLink2 <br><br>";
?>
<?php


?>
<?php
// Define the CSV file name
$csvFileName1 = 'ECE_B_FINAL.csv';

// Check if the file exists
if (file_exists($csvFileName1)) {
    // Read the CSV data into an array
    $csvData = array_map('str_getcsv', file($csvFileName1));

    $i=0;
    echo '<table>';
    foreach ($csvData as $row) {
        echo '<tr>';
        foreach ($row as $cell) {
            if($i==0 || $i==1 || $i==2 || $i==3 || $i==4 || $i==5 || $i==6 || $i==7 || $i==8){
                echo "";
                $i++;
            }
            else{
            echo '<td>' . htmlspecialchars($cell) . '</td>';
            $i++;
            }
        }
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo "The CSV file does not exist.";
}
echo "    <style>
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

th, td {
    border: 1px solid #e0e0e0;
    padding: 12px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
    font-weight: bold;
}

tr:nth-child(even) {
    background-color: #f7f7f7;
}

tr:hover {
    background-color: #e0e0e0;
}
</style>"
?>