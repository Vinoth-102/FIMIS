<?php
include("config.php");
try{
$q1 = "DROP TABLE ita_final_report";
$q2 = "DROP TABLE itb_final_report";
$r1 = mysqli_query($conn,$q1);
$r2 = mysqli_query($conn,$q2);

if($r1 & $r2){
    echo "RESET SUCCESSFULL.";
}
else{
    echo "ERROR.";
}
}
catch(Exception $e){
    echo "REPORT NOT GENERATED YET.";
}

?>