<?php
error_reporting(0);

include("config.php");
try{
$xx = "DROP TABLE eeea_final_report";
$x = $conn->query($xx);
}catch(Exception $e){
    echo "";
}
try {
    // Connect to the database
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // SQL query to fetch table names
    $sql = "SHOW TABLES";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Fetch table names
    $tableNames = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Filter tables starting with 'eeea' and 'itb'
    $filteredTables = array_filter($tableNames, function($tableName) {
        return (strpos($tableName, 'eeea') === 0);
    });

     /**************************************** */



     $connn = new mysqli($servername, $username, $password, $dbname);

     foreach($filteredTables as $a){ 
         echo $a;
         echo "<br>";
         $sub = substr($a,-6)."_mark";
         $sub1 = substr($a,-6)."_attendance";
 
         $que = "ALTER TABLE $a MODIFY $sub varchar(11) AFTER $sub1";
         mysqli_query($connn,$que);
 
     }
 
     
 
 
 
 
     /******************************************** */
    // Perform a natural join on the filtered tables
    $query = "SELECT * FROM " . implode(" NATURAL JOIN ", $filteredTables);

    // Execute the join query
    $stmt = $conn->prepare($query);
    $stmt->execute();

    // Fetch the results
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Create a new table to store the result
    $newTableName = "eeea_final_report";
    $createQuery = "CREATE TABLE $newTableName AS $query";

    // Execute the create table query
    $stmt = $conn->prepare($createQuery);
    $stmt->execute();
} catch (PDOException $e) {
    echo "";
}



function total()
{
include("config.php");
$newTableName = "eeea_final_report";

// Create a connection to the MySQL database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch column names ending with "Mark"
$query = "SELECT COLUMN_NAME
          FROM INFORMATION_SCHEMA.COLUMNS
          WHERE TABLE_NAME = '$newTableName'
          AND COLUMN_NAME LIKE '%Mark'";

$result = $conn->query($query);

$arr = array();
$i=0;
if ($result->num_rows > 0) {
    // Output each column name
    while ($row = $result->fetch_assoc()) {
        $arr[$i] = $row["COLUMN_NAME"];
        $i++;
    }
} else {
    echo "No columns found.";
}
$q1 = "SELECT * FROM $newTableName";
$res1 = $conn->query($q1);

try{
$q2 = "ALTER TABLE $newTableName ADD grand_total INT;";
$res2 = $conn->query($q2);



while($row = $res1->fetch_assoc()){
    $mark = 0;
    $j = 0;
    while($j <= 8){
        if($arr[$j]){
            $mark = (int)$row[$arr[$j]] + $mark;
            $j++;
        }
        else{
            break;
        }
    }
 $z = $row['regno'];
$q3 = "UPDATE $newTableName SET grand_total = $mark WHERE regno = '$z'";
$res3 = $conn->query($q3);
}
}
catch(Exception $e)
{
    echo "";
}
/************************************************************************************** */

// SQL query to fetch column names ending with "Mark"
$query = "SELECT COLUMN_NAME
          FROM INFORMATION_SCHEMA.COLUMNS
          WHERE TABLE_NAME = '$newTableName'
          AND COLUMN_NAME LIKE '%Attendance'";

$result = $conn->query($query);

$arr = array();
$i=0;
if ($result->num_rows > 0) {
    // Output each column name
    while ($row = $result->fetch_assoc()) {
        $arr[$i] = $row["COLUMN_NAME"];
        $i++;
    }
} else {
    echo "No columns found.";
}
$q1 = "SELECT * FROM $newTableName";
$res1 = $conn->query($q1);

try{
$q2 = "ALTER TABLE $newTableName ADD total_attendance INT";
$res2 = $conn->query($q2);



while($row = $res1->fetch_assoc()){
    $mark = 0;
    $j = 0;
    while($j <= 8){
        if($arr[$j]){
            $mark = (int)$row[$arr[$j]] + $mark;
            $j++;
        }
        else{
            break;
        }
    }
 $z = $row['regno'];
$q3 = "UPDATE $newTableName SET total_attendance = $mark WHERE regno = '$z'";
$res3 = $conn->query($q3);
}
}
catch(Exception $e)
{
    echo "";
}



$connn = new mysqli($servername, $username, $password, $dbname);

    $quee = "ALTER TABLE $newTableName MODIFY grand_total INT(11) AFTER total_attendance";
    mysqli_query($connn,$quee);

/************************************************************************************** */


$conn->close();


}




total();

echo "<a href='eeeatabletocsv.php'>Click here to Download EEE-A Final Report.</a><br><br>";


?>
