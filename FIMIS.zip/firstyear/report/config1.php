<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student";

$conn1 = new mysqli($servername, $username, $password, $dbname);
?>