<html>

<head>
    <title>Update Details</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            width: 25%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        h3 {
            margin: 8px 0;
        }

        input {
            width: 100%;
            padding: 5px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        input[list] {
            width: 100%;
            padding: 7px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        datalist option {
            background-color: #fff;
            color: #333;
        }
    </style>
</head>

<body>
    <h1>Update Student Details.....</h1><br>
    <form action="" method="post">

        <h3>Name</h3>
        <input type="text" name="names">
        <br>
        <h3>Reg NO</h3>
        <input type="number" name="regno">
        <br>

        <h3>Dept</h3>
        <input list="cls" name="cls" required>
        <datalist id="cls">
            <option value="AUTOMOBILE-A">AUTOMOBILE-A</option>
            <option value="AUTOMOBILE-B">AUTOMOBILE-B</option>
            <option value="BIOTECH">BIOTECH</option>
            <option value="CIVIL-A">CIVIL-A</option>
            <option value="CIVIL-B">CIVIL-B</option>
            <option value="CIVIL-TM">CIVIL-TM</option>
            <option value="CSE-A">CSE-A</option>
            <option value="CSE-B">CSE-B</option>
            <option value="ECE-A">ECE-A</option>
            <option value="ECE-B">ECE-B</option>
            <option value="EEE-A">EEE-A</option>
            <option value="EEE-B">EEE-B</option>
            <option value="IT-A">IT-A</option>
            <option value="IT-B">IT-B</option>
            <option value="MECHANICAL-A">MECHANICAL-A</option>
            <option value="MECHANICAL-B">MECHANICAL-B</option>
            <option value="MECHANICAL-TM">MECHANICAL-TM</option>
            <option value="PHARMA">PHARMA</option>
            <option value="PETRO">PETRO</option>
        </datalist>
        <br>
        <h3>DOB</h3>
        <input type="date" name="dob" required>
        <br><br>
        <input type="submit" name="submit">
    </form>
</body>

</html>

<?php

if (isset($_POST['submit'])){

include("config.php");

$names = $_POST["names"];
$dob = $_POST["dob"];
$regno = $_POST["regno"];
$dept = $_POST["cls"];
$col1="name";


$q1 = "DELETE FROM studentdetails WHERE regno='$regno'";
$res1 = $conn->query($q1);

$q2 = "INSERT INTO studentdetails VALUES('$names','$dob','$regno','$dept')";
$res2 = $conn->query($q2);


if($res1 & $res2){
    echo "<center><p style='color:green;font-weight:bold;'>Student Details are updated Successfully.</p></center>";
}
else{
    echo "<center><p style='color:red;font-weight:bold;'>Error : Either Student not Available or Incorrect Data Entered.</p></center>";
}
$conn->close();

}
echo "<br><center><a href='home.html'>Go To HomePage</a></center>";
?>