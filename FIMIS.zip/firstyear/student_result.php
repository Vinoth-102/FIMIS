<?php
function check()
{
    include("config.php");
    $r = $_POST['usname'];
    $d = $_POST['passwor'];
    $s = (string) $d;
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM studentdetails WHERE regno = $r";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    if ($row['regno'] == $r && $row['dob'] == $s) {
        mainfunc();
    } else {
        echo $s;
        echo "<script>alert('Invalid Username or Password');</script>";
        //echo "<script>window.location.href='student_login.html';</script>";
    }
    $conn->close();
}
check();

function mainfunc()
{
    $r = $_POST['usname'];
    $s = $_POST['passwor'];
    include("config.php");
    $q1 = "SELECT dept from studentdetails WHERE regno = '$r'";
    $result1 = mysqli_query($conn, $q1);
    $rrr = mysqli_fetch_array($result1);
    $cls = $rrr["dept"]; 

    $cls1 = strtolower($cls);
    $cls2 = str_replace("-","",$cls1);
    $tablename = $cls2.'_final_report';
    $tablename1='total'.$cls2;


/*    $sql = "SHOW COLUMNS FROM $tableName";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $columnNames = array();
        while ($row = $result->fetch_assoc()) {
            $columnNames[] = $row['Field'];
        }
    
        // $columnNames array now contains the column names
        print_r($columnNames);
    } else {
        echo "No columns found in the table.";
    }
    */


    $sql1 = mysqli_query($conn, "SELECT * FROM studentdetails WHERE regno = $r");
    $sql2 = mysqli_query($conn, "SELECT * FROM $tablename WHERE regno = $r");
    $row2 = mysqli_fetch_array($sql2); 
    $sql3 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='CY3151'");
    $row3 = mysqli_fetch_array($sql3);
    $sql4 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='PH3151'");
    $row4 = mysqli_fetch_array($sql4);
    $sql5 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='HS3152'");
    $row5 = mysqli_fetch_array($sql5);
    $sql6 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='MA3151'");
    $row6 = mysqli_fetch_array($sql6);
    $sql7 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='GE3151'");
    $row7 = mysqli_fetch_array($sql7);
    $sql8 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='GE3152'");
    $row8 = mysqli_fetch_array($sql8);
    $sql9 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='BS3171'");
    $row9 = mysqli_fetch_array($sql9);
    $sql10 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='GE3171'");
    $row10= mysqli_fetch_array($sql10);
    $sql11= mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='GE3172'");
    $row11= mysqli_fetch_array($sql11);
    
    
    

?>

<style>
/* Style for the table */
body{
    background-image: linear-gradient(#ff2d75,rgba(10, 10, 11, 0.4)), url(images/b2.jpg);
   
    background-position: center;
    background-size: cover;

}
.data-table {
    
    width: 70%;
    border-collapse: collapse;
    margin-top: 55px;
    border-radius:8px;
    
}

.data-table th,
.data-table td {
   
    border: 1px solid #ddd;
    padding: 8px;
 
    
}

.data-table th {
    background-color: #f2f2f2;
  
}
.data-table tr:nth-child(even) {
    background-color: #f2f2f2;
}

.data-table tr:nth-child(odd) {
    background-color: #ffffff;
}
tr.center-row td {
      text-align: center;
    }

/* Additional styling for the table */
.ad h2 {
    font-size: 20px;
    margin-top: 20px;
}
.head{
        display: flex;
    }
    .head h2,h3{
        width: 100%;
     
    }





</style>

    <form action="entry/aaa/index.php" method="post">
        <div class="ad">
            <div class="container">
            
                <table class="data-table" align="center" cellspacing="0" >
                    
                    <tr>
                    <th colspan="4" style="height:50px;background:#ffffff;"><div class="head">
                        <image src="logo.png" height="100px" width="150px"></image>
                        <center><h2 style="font-size = 20px">University College of Engineering, BIT Campus, Anna University, Tiruchirappalli.</h2>
                        <h3>FIMIS - FIRST YEAR INTERNAL MARK INFORMATION SYSTEM</h3>
                    <h4>INTERNAL ASSESSMENT - 2</h4></center>
                    </div>
                    </th>
                    </tr>       
                    <?php
                    while ($row = mysqli_fetch_array($sql1)) {
                    ?>
                    <tr>
                        <td colspan="4"><span style="font-weight:bold;font-size:22px;">Name : &nbsp</span><?php echo $row['name']; ?></td>
                    </tr>
                    <tr>
                        <td   colspan="2" ><p style="font-weight:bold;font-size:20px;">Department & Section </p><?php echo $row['dept']; ?></td>
                        <td   colspan="2"><p style="font-weight:bold;font-size:20px;">Register Number </p> <?php echo $row['regno']; ?></td>
                    </tr>
                    
                    <?php
                    }
                    ?>
                    <tr>
                        <th>Subject code</th>
                        <th>Marks</th>
                        <th>Total No.of Hours</th>
                        <th>No.of Hours Attended</th>

                    </tr>
                   

                        <tr class="center-row">
                            <th>CY3151</th>
                            <td><?php echo $row2['cy3151_mark']; ?></td>
                            <td><?php echo $row3['totalattendance']; ?></td>
                            <td><?php echo $row2['cy3151_attendance']; ?></td>
                        </tr >
                        
                        <tr class="center-row">
                            <th>PH3151</th>
                            <td><?php echo $row2['ph3151_mark']; ?></td>
                            <td><?php  echo $row4['totalattendance']; ?></td>

                            <td><?php echo $row2['ph3151_attendance']; ?></td>
                            
                        </tr>

                        <tr class="center-row">
                        
                        <th>HS3152</th>
                        <td><?php echo $row2['hs3152_mark']; ?></td>
                        <td><?php  echo $row5['totalattendance']; ?></td>

                        <td><?php echo $row2['hs3152_attendance']; ?></td>
                        
                        </tr>

                        <tr class="center-row">
                        <th>MA3151</th>
                        <td><?php echo $row2['ma3151_mark']; ?></td>
                        <td><?php  echo $row6['totalattendance']; ?></td>

                        <td><?php echo $row2['ma3151_attendance']; ?></td>
                        </tr>

                        <tr class="center-row">
                        <th>GE3151</th>
                        <td><?php echo $row2['ge3151_mark']; ?></td>
                        <td><?php  echo $row7['totalattendance']; ?></td>

                        <td><?php echo $row2['ge3151_attendance']; ?></td>
                        
                        </tr>

                        <tr class="center-row">
                        <th>GE3152</th>
                        <td><?php echo $row2['ge3152_mark']; ?></td>
                        <td><?php  echo $row8['totalattendance']; ?></td>

                        <td><?php echo $row2['ge3152_attendance']; ?></td>
                        
                        </tr>

                        <tr class="center-row">
                        <th>BS3171</th>
                        <td><?php echo $row2['bs3171_mark']; ?></td>
                        <td><?php  echo $row9['totalattendance']; ?></td>

                        <td><?php echo $row2['bs3171_attendance']; ?></td>
                        
                        </tr>

                        <tr class="center-row">
                        <th>GE3171</th>
                        <td><?php echo $row2['ge3171_mark']; ?></td>
                        <td><?php  echo $row10['totalattendance']; ?></td>

                        <td><?php echo $row2['ge3171_attendance']; ?></td>
                        
                        </tr>


                        <tr class="center-row">
                        <th>GE3172</th>
                        <td><?php echo $row2['ge3172_mark']; ?></td>
                        <td><?php  echo $row11['totalattendance']; ?></td>

                        <td><?php echo $row2['ge3172_attendance']; ?></td>
                        
                        </tr>

                        

                        <tr class="center-row">
                            <th>Total</th>
                            <td style="font-weight:bold;"><?php echo (int)$row2['cy3151_mark']+(int)$row2['ph3151_mark']+(int)$row2['hs3152_mark']+(int)$row2['ma3151_mark']+(int)$row2['ge3151_mark']+(int)$row2['ge3152_mark']+(int)$row2['bs3171_mark']+(int)$row2['ge3171_mark']+(int)$row2['ge3172_mark'];?></td>
                            <td style="font-weight:bold;"><?php echo $row3['totalattendance']+$row4['totalattendance']+$row5['totalattendance']+$row6['totalattendance']+$row7['totalattendance']+$row8['totalattendance']+$row9['totalattendance']+$row10['totalattendance']+$row11['totalattendance'];?></td>
                            
                            <td style="font-weight:bold;"><?php echo $row2['cy3151_attendance']+$row2['ph3151_attendance']+$row2['hs3152_attendance']+$row2['ma3151_attendance']+$row2['ge3151_attendance']+$row2['ge3152_attendance']+$row2['bs3171_attendance']+$row2['ge3171_attendance']+$row2['ge3172_attendance'];?></td>                   
                        </tr>
                    
                    
                </table>
            </div>
        </div>
    </form>
<?php
$conn->close();

}
?>

