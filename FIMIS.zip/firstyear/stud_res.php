<?php
function check()
{
    include("config.php");
    $r = $_POST['usname'];
    $d = $_POST['passwor'];
    $s = (string) $d;
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM studentdetails WHERE regno = $r";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    if ($row['regno'] == $r && $row['dob'] == $s) {
        mainfunc();
    } else {
        echo $s;
        echo "<script>alert('Invalid Username or Password');</script>";
        //echo "<script>window.location.href='student_login.html';</script>";
    }
    $conn->close();
}
function mainfunc()
{
    
    $a = array();
    $sub_arr = array();
    $r = $_POST['usname'];
    $s = $_POST['passwor'];
    include("config.php");
    $q1 = "SELECT dept from studentdetails WHERE regno = '$r'";
    $result1 = mysqli_query($conn, $q1);
    $rrr = mysqli_fetch_array($result1);
    $cls = $rrr["dept"]; 

    $cls1 = strtolower($cls);
    $cls2 = str_replace("-","",$cls1);
    $tablename = $cls2.'_final_report';
    $tablename1='total'.$cls2;
    $cols = "SELECT COLUMN_NAME from information_schema.columns where table_name = '$tablename'";
    $res1 = mysqli_query($conn, $cols);
    //$i=0;
    while($row1 = mysqli_fetch_array($res1)){
        //$a[$i] = $row1["COLUMN_NAME"];
        array_push($a, $row1["COLUMN_NAME"]);
        array_push($sub_arr, substr(strtoupper($row1["COLUMN_NAME"]),0,6));
        
        //$i = $i+1;
    }
    ?>
    <style>
        body{
    background-image: linear-gradient(#ff2d75,rgba(10, 10, 11, 0.4)), url(images/b2.jpg);
   
    background-position: center;
    background-size: cover;

}
.data-table {
    
    width: 70%;
    border-collapse: collapse;
    margin-top: 55px;
    border-radius:8px;
    
}

.data-table th,
.data-table td {
   
    border: 1px solid #ddd;
    padding: 8px;
 
    
}

.data-table th {
    background-color: #f2f2f2;
  
}
.data-table tr:nth-child(even) {
    background-color: #f2f2f2;
}

.data-table tr:nth-child(odd) {
    background-color: #ffffff;
}
tr.center-row td {
      text-align: center;
    }

/* Additional styling for the table */
.ad h2 {
    font-size: 20px;
    margin-top: 20px;
}
.head{
        display: flex;
    }
    .head h2,h3{
        width: 100%;
     
    }
    .head h2{
        font-size:20px;
    }



        </style>
    <table class="data-table" align="center" cellspacing="0">
    <tr>
                    <th colspan="4" style="height:50px;background:#ffffff;"><div class="head">
                        <image src="logo.png" height="100px" width="150px"></image>
                        <center><h2>University College of Engineering, BIT Campus, Anna University, Tiruchirappalli.</h2>
                        <h3>FIMIS - FIRST YEAR INTERNAL MARK INFORMATION SYSTEM</h3>
                    <h4>INTERNAL ASSESSMENT REPORT</h4></center>
                    </div>
                    </th>
                    </tr>

                    <?php
                    $sql_name = mysqli_query($conn, "SELECT * FROM studentdetails WHERE regno = $r");

                    while ($row = mysqli_fetch_array($sql_name)) {
                    ?>
                    <tr>
                        <td colspan="4"><span style="font-weight:bold;font-size:22px;">Name : &nbsp</span><?php echo $row['name']; ?></td>
                    </tr>
                    <tr>
                        <td   colspan="2" ><p style="font-weight:bold;font-size:20px;">Department & Section </p><?php echo $row['dept']; ?></td>
                        <td   colspan="2"><p style="font-weight:bold;font-size:20px;">Register Number </p> <?php echo $row['regno']; ?></td>
                    </tr>
                    
                    <?php
                    }
                    ?>
        <tr>
            <th >Subject code</th>
            <th>No. of Hours Attended</th>
            <th>Total No.of Hours</th>
            <th>Marks</th>
        </tr>
    <?php
    $length = count($a);
    $tot =0;
    $tothours = 0;
    $totatt = 0;
    for($j=2;$j<$length-2;$j++){
        $query = "SELECT * from $tablename WHERE regno = '$r'";
        $ma = mysqli_query($conn, $query);
        $sub = substr(strtoupper($a[$j]),0,6);
        echo "<tr class='center-row'><th>".$sub."</th>";
        //echo $sub;
       

        while($row2 = mysqli_fetch_array($ma))
        {
            
           // echo $a[$j]." = ".$row2[$a[$j]];
            $tot = $tot + (int)$row2[$a[$j]];
            echo "<td>".$row2[$a[$j]]."</td>";
            if($j%2==0)
            {
            $sql3 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='$sub'");
            $row3 = mysqli_fetch_array($sql3);
            //echo $sub."tot att = ".$row3['totalattendance'];
            echo "<td>".$row3['totalattendance']."</td>";
            $tothours = $tothours + (int)$row3['totalattendance'];
            }
           // echo $a[++$j]." = ".$row2[$a[$j]];
            echo "<td>".$row2[$a[++$j]]."</td></tr>";
            $totatt = $totatt + (int)$row2[$a[$j]];

            
            

        }
        

    }
    echo "<tr class='center-row'>
    <th>Total</th>
    <th>".$tot."</th>
    <th>".$tothours."</th>
    <th>".$totatt."</th></tr>";

    //print_r($sub_arr);


}
check();
?>