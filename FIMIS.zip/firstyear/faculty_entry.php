
<?php
error_reporting(E_ERROR | E_PARSE); // Hide warnings, but display errors and parse errors
 // Disable error display

    include("config.php");
    $name=$_POST["nam"];
    $staffdept=$_POST["dep"];
    $clshandle=$_POST["clshandle"];
    $semester=$_POST["sem"];
    $subject=$_POST["sub"];
    $email=$_POST["mail"];
    
    $tablename=$clshandle.$subject;
    $t = strtolower($tablename);
    $s = str_replace("-", "", $t);
    $subl = strtolower($subject);
    $m = "_mark";
    $a = "_attendance";
   
    $col1 = $subl.$m;
    $col2 = $subl.$a;
    

        $q1 = "CREATE TABLE IF NOT EXISTS $s(regno BIGINT,name VARCHAR(255),$col1 VARCHAR(11),$col2 INT)";
        $res1 = mysqli_query($conn,$q1);
        //$q2 = "SELECT name,clshandle,subcode FROM faculty WHERE clshandle='$clshandle' AND subcode='$subject'";
        //$res2 = mysqli_query($conn,$q2);
        //$row = $res2->fetch_assoc();
        
        if($res1)
        {
        $query="INSERT INTO faculty VALUES('$name','$clshandle','$semester','$subject','$email','$staffdept','no')";
        $res=mysqli_query($conn,$query);
        if($res)
        {
            echo "<center><span class='tick-symbol' style='color:green;font-size:62px'>&#10004;</span><br>
            <h2 style='color:green;font-family:Arial;font-weight:bold;'>Details Saved Successfully.</h2></center>";
        }
        else
        {
            echo "<center><span class='cross-symbol' style='color:red;font-size:62px'>&#10007;</span><br>
            <h2 style='color:red;font-family:Arial;font-weight:bold;'>Failed To Save Details...........</h2></center>";
        }
        }
        
        $conn->close();

?>