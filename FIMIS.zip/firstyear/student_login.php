
<?php

  function check()
  {
    include("config.php");
      $r=$_POST['usname'];
      $s=$_POST['passwor'];
	    if ($conn->connect_error) 
      {
		    die("Connection failed: " . $conn->connect_error);
	    }

	    $sql = "SELECT * FROM studentdetails WHERE regno= '$r'";
	    $result = $conn->query($sql);
      $row = $result->fetch_assoc();
      if($row['regno']==$r and $row['dob']==$s)
      {
        echo "<script>window.location.href='student_result.php';</script>";
      }
      else
      {
        echo "<script>alert('Invalid Username or Password');</script>";
        echo "<script>window.location.href='student_login.html';</script>";
      }
  }
check();
$conn->close();
?>
