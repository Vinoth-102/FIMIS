<?php
include("config.php");
$cup = $_POST["cup"];
$nu = $_POST["nu"];
$np = $_POST["np"];
$cp = $_POST["cp"];

$q = "SELECT * FROM login";
$res = mysqli_query($conn,$q);
$row = $res->fetch_assoc();

$tb = "login";

if($cup == $row["password"]){

    $q1 = "DELETE FROM $tb WHERE password = '$cup'";
    $res1 = mysqli_query($conn,$q1);
    if($res1 == TRUE & $np==$cp){
        $q2 = "INSERT INTO $tb VALUES('$nu','$cp')";
        $res2 = mysqli_query($conn,$q2);
        echo "<center>Password Changed Successfully</center>";
    }
    else{
        echo "<center>Password Does Not Matched</center>";

    }
}
else{
        echo "</center>Password Does Not Match</center>";
}
$conn->close();

?>