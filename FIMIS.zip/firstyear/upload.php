<?php
// Check if a file has been uploaded
try{
if (isset($_FILES['excel_file'])) {
    // Define database connection details
    include("config.php");
    

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the uploaded CSV file
    $excel_file = $_FILES['excel_file']['tmp_name'];

    // Read the CSV file
    if (($handle = fopen($excel_file, "r")) !== false) {
        // Iterate through the CSV data and insert into the database
        while (($data = fgetcsv($handle, 1000, ",")) !== false) {
            // Modify this code to match the structure of your CSV file and database table
            $column1 = $data[0];
            $column2 = $data[1];
            $column3 = $data[2];
            $column4 = $data[3];

            $sql = "INSERT INTO studentdetails (name,dob,regno,dept) VALUES ('$column1','$column2',$column3,'$column4')";
            
            $conn->query($sql);
            $sq = "DELETE FROM studentdetails where dept='dept'";
            $conn->query($sq);

        }

        fclose($handle);
    }

    // Close the database connection
    $conn->close();
    echo "<center><span class='tick-symbol' style='color:green;font-size:62px'>&#10004;</span><br>
            <h2 style='color:green;font-family:Arial;font-weight:bold;'>Student Details Uploaded Successfully.</h2></center>";
} else {
    echo "<center><span class='cross-symbol' style='color:red;font-size:62px'>&#10007;</span><br>
    <h2 style='color:red;font-family:Arial;font-weight:bold;'>Details not uploaded !!!</h2></center>";
}
}
catch(Exception $e){
    echo "<center><span class='cross-symbol' style='color:red;font-size:62px'>&#10007;</span><br>
    <h2 style='color:red;font-family:Arial;font-weight:bold;'>Incorrect Data In The File !!!</h2></center>";
}
?>
