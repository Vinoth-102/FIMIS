<?php
error_reporting(0);
include("config.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to get all table names
$sql = "SHOW TABLES";
$result = $conn->query($sql);

$tables = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_row()) {
        $tables[] = $row[0];
    }
} else {
    echo "No tables found in the database.";
}

// Close the database connection


// Print the array of table names




$len = count($tables);
for($i=0;$i<$len;$i++){
    if($tables[$i]=="faculty" || $tables[$i]=="studentdetails" || $tables[$i]=="login")
    {
        echo "<br>";
    }
    elseif (substr($tables[$i], -13) === '_final_report'){
        $sql1 = "DROP TABLE $tables[$i]";
        $res1 = mysqli_query($conn,$sql1);
    }
    else{
        $sql = "TRUNCATE TABLE $tables[$i]";
        $res = mysqli_query($conn,$sql);
    }
}
if($res1 & $res){
    echo "<center><h2>Reset Success</h2></center>";
}
else
{
    echo "<center><h2>Website is Already Reset.</h2></center>";

}

$conn->close();

?>

