<html>
    <head>
        <title>Submitted List</title>
        <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        h2 {
            color: #333;
        }
        table {
            width: 80%;
            margin: 0 auto;
            border:2px solid #333;
        }
        th, td {
            padding: 12px 20px;
            text-align: center;
        }
        th {
            background-color: #333;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:nth-child(odd) {
            background-color: #ffffff;
        }
        td:last-child {
            font-weight: bold;
        }
        .head{
        display: flex;
    }
    .head h2,h3{
        width: 100%;
        margin-left: 10%;
    }
    </style>



</head>
    <body>
    <div class="head">
            <image src="logo.png" height="100px" width="150px"></image>
            <center><h2>University College of Engineering, BIT Campus, Anna University, Tiruchirappalli.</h2>
            <h3>FIMIS - FIRST YEAR INTERNAL MARK INFORMATION SYSTEM</h3></center>
            </div>
        <center><h2>Marks Submission List</h2><center>
        <table>
            <tr>
                <th>Name</th>
                <th>Class Handling</th>
                <th>Subject Code</th>
                <th>Submitted Or Not Submitted</th>
                <th>Permission To Edit</th>
                <th>Mail - ID</th>


            </tr>


<?php
include("config.php");
            $query = "SELECT name,clshandle,subcode,ep,email FROM faculty";
            $result = $conn->query($query);
            

            while($row = $result->fetch_assoc())
            {
            $table = $row["clshandle"].$row["subcode"];
            $table = strtolower($table);
            $table = str_replace("-","",$table);
            echo "<tr><td>".$row['name']."</td>";
            echo "<td>".$row['clshandle']."</td>";
            echo "<td>".$row['subcode']."</td>";

            $q1 = "SELECT * FROM $table";
            $res = $conn->query($q1);
            $r1 = $res->fetch_assoc();

            if($r1){
                echo "<td>Submitted</td>";
            }
            else{
                echo "<td>Not Submitted</td>";
            }
            echo "<td>".$row['ep']."</td>";
            echo "<td>".$row['email']."</td>";

            
            
            echo "</tr>";



            }

$conn->close();
            
            
?>
</table>
</body>
</html>