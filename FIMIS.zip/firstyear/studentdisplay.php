<html>
    <head>
        <title>Submitted List</title>
        <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        h2 {
            color: #333;
        }
        table {
            width: 80%;
            margin: 0 auto;
            border:2px solid #333;
        }
        th, td {
            padding: 12px 20px;
            text-align: center;
        }
        th {
            background-color: #333;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:nth-child(odd) {
            background-color: #ffffff;
        }
        td:last-child {
            font-weight: bold;
        }
        .head{
                display: flex;
            }
            .head h2,h3{
                width: 100%;
                margin-left:5%;
            }
    </style>



</head>
    <body>
    <div class="head">
            <image src="logo.png" height="100px" width="150px"></image>
            <center><h2>University College of Engineering, BIT Campus, Anna University, Tiruchirappalli.</h2>
            <h3>FIMIS - FIRST YEAR INTERNAL MARK INFORMATION SYSTEM</h3></center>
        </div>
        <center><h2>Student List</h2><center>
        <table>
            <tr>
                <th>Name</th>
                <th>Regno</th>
                <th>DOB</th>
                <th>Dept</th>
            </tr>


<?php
include("config.php");
            $query = "SELECT * FROM studentdetails";
            $result = $conn->query($query);
            

            while($row = $result->fetch_assoc())
            {
            
            echo "<tr><td>".$row['name']."</td>";
            echo "<td>".$row['regno']."</td>";
            echo "<td>".$row['dob']."</td>";
            echo "<td>".$row['dept']."</td></tr>";



            }

            
            
?>
</table>
</body>
</html>