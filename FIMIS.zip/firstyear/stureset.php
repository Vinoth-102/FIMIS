<?php

include("config.php");
$sql2 = "TRUNCATE TABLE studentdetails";
$res2 = mysqli_query($conn,$sql2);
if($res2){
    echo "Reset Success";
}
else{
    echo "Reset Failed";
}
$conn->close();

?>