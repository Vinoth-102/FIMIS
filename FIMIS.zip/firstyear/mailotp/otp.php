<?php
function generate_otp($n)
{
   $gen = "1357902468";
   $res = "";
   for ($i = 1; $i <= $n; $i++)
{
   $res .= substr($gen, (rand()%(strlen($gen))), 1);
}
   return $res;
}
$num = 6;
print_r("The one time password generated is :");
print_r(generate_otp($num));
?>