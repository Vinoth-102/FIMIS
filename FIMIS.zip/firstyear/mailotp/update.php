<?php
include('smtp/PHPMailerAutoload.php');
$receiver = $_POST["regno"];
echo smtp_mailer($receiver,'Firstyear Internal Mark Information System','Access Granted to Edit the First Year Internal Marks.');
function smtp_mailer($to,$subject, $msg){
	$mail = new PHPMailer(); 
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'tls'; 
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 587; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	//$mail->SMTPDebug = 2; 
	$mail->Username = "aubitfirstyearcoordinator@gmail.com";
	$mail->Password = "csra qlbi kgmc csrw";
	$mail->SetFrom("aubitfirstyearcoordinator@gmail.com");
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){
        echo "Please Check Your Internet Connection !!!<br>";
        exit;
	}
}
?>



<html>
</html>
<?php
error_reporting(0);

include("config.php");

$class = $_POST["clshandle"];
$subcode = $_POST["sub"];
$regno = $_POST["regno"];
$n = $_POST["n"];

$m = "_mark";
$a = "_attendance";
$tbname = $class.$subcode;
$t = strtolower($tbname);
$s = str_replace("-", "", $t);
$col1 = $subcode.$m;
$col2 = $subcode.$a;



$q1 = "UPDATE faculty SET ep='yes' WHERE email='$regno' AND subcode='$subcode' AND clshandle='$class'";
$res1 = $conn->query($q1);

$q2 = "SELECT ep FROM faculty WHERE email='$regno' AND subcode='$subcode' AND clshandle='$class'";
$res2 = $conn->query($q2);

$row2 = $res2->fetch_assoc();

if($row2["ep"] == "yes"){
    echo "<center><span class='tick-symbol' style='color:green;font-size:62px'>&#10004;</span><br>
    <h2 style='color:green;font-family:Arial;font-weight:bold;'>Faculty Can Update the marks.</h2>";
}
else{
    echo "<center><span class='cross-symbol' style='color:red;font-size:62px'>&#10007;</span><br>
    <h2 style='color:red;font-family:Arial;font-weight:bold;'>Error : Either Faculty not Available or Incorrect Data Entered.</h2>";
}








?>