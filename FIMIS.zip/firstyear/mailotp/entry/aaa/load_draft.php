<?php
session_start();

// Assuming you have a session variable storing the draft data
if (isset($_SESSION['draft_data'])) {
    echo json_encode($_SESSION['draft_data']);
} else {
    echo '{}';
}
?>
