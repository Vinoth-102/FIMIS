<?php
session_start();

// Assuming you have a session variable to store the draft data
$_SESSION['draft_data'] = json_decode(file_get_contents('php://input'), true);
?>
