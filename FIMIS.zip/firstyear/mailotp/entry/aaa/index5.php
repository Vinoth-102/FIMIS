<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Mark and Attendance Entry</title>
    <style>
    body {
        font-family: Arial, Helvetica, sans-serif;
        background-color: #f0f0f0;
        margin: 0;
        padding: 0;
        color: #333;
    }

    h2 {
        text-align: center;
        color: #333;
    }

    .container {
        width: 80%;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border: 2px solid #000;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        border: 2px solid #000;
    }

    th, td {
        border: 2px solid #000;
        padding: 5px;
        text-align: center;
    }

    th {
        background-color: #333;
        color: #fff;
    }

    input[type="number"] {
        width: 100px;
    }

    .inp {
        width: 50px;
    }

    button {
        background-color: #007BFF;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background 0.3s;
        font-size: 18px;
    }

    button:hover {
        background-color: #0056b3;
    }

    .error {
        color: red;
        font-size: 14px;
        font-weight: bold;
    }
    .head{
        display: flex;
    }
    .head h2,h3{
        width: 100%;
    }

</style>

</head>
<body>


<div class="container">
<div class="head">
            <image src="logo.png" height="100px" width="150px"></image>
            <center><h2>University College of Engineering, BIT Campus, Anna University, Tiruchirappalli.</h2>
            <h3>FIMIS - FIRST YEAR INTERNAL MARK INFORMATION SYSTEM</h3></center>
            </div>
    <h2>Student Mark and Attendance Entry</h2>
    <form onsubmit="return confirmSubmission()" id="markForm" method="post" action="process1.php">
        <?php
            // Include your database connection code here
            include("config.php");
            $staff = $_POST["stfname"];

            $clshandle=$_POST["clshandle"];
            $subject=$_POST["subject"];
            $tablename=$clshandle.$subject;
            $t = strtolower($tablename);
            $s = str_replace("-", "", $t);

            $tt = "total".$clshandle;
            $ttt = strtolower($tt);
            $totaltable = str_replace("-", "", $ttt);

            $col1 = strtolower($subject)."_mark";
            $col2 = strtolower($subject)."_attendance";

            $query = "SELECT * FROM $s";
            $result1 = $conn->query($query);
            
            //if($row1){
                //echo "Marks already submitted if you want to update contact Admin.<br><br>";
                //details_display();
            $z1 = "SELECT ep FROM faculty WHERE subcode='$subject' AND clshandle='$clshandle'";
            $zz1 = $conn->query($z1);
            while($zzz1 = $zz1->fetch_assoc()){
            if($zzz1["ep"] == "yes"){
                mainfunc();
            }
            else{
                echo "You need Admin Permission To edit";
                $conn->close();
                exit;
            }
        }

            //}
            //else{
               // mainfunc();
            //}

            function mainfunc(){

            global $conn,$clshandle,$subject,$col1,$col2,$row1,$result1,$totaltable,$staff;


            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch students' information from the database
            $sql = "SELECT name, regno FROM studentdetails WHERE dept = '$clshandle'";
            $result = $conn->query($sql);

            $s1 = "SELECT totalmark,totalattendance FROM $totaltable WHERE subcode='$subject'";
            $result2 = $conn->query($s1);
            $row2 = $result2->fetch_assoc();

            echo "<br>Staff Name : ".$staff;
            echo "<br>";
            echo "<br>";

            echo "<table>";

            echo "<tr>";
            echo "<td>Class : <select name='cl'><option>".$clshandle."</option></select></td>";
            echo "<td>Subject : <select name='sb'><option>".$subject."</option></select></td>";
            echo "<td>Total Marks:<input class='inp' type='number' name='ma'  value=".$row2["totalmark"]." required></td>";
            echo "<td>Total Attendance:<input class='inp' type='number' name='at'   value=".$row2["totalattendance"]." required></td>";
            echo "</tr>";


            echo "<th>Name</th>";
            echo "<th>Reg no</th>";
            echo "<th>Marks</th>";
            echo "<th>Attendance</th>";


           // if ($result->num_rows > 0) {
                //while ($row = $result->fetch_assoc()) {
                    
                    while($row1 = $result1->fetch_assoc())
                    {
                    echo '<div class="student-entry">';
                    echo "<tr>";
                    echo '<td>' . $row1["name"] . '</td>'; 
                    echo '<td>' .$row1["regno"] . '</td>';
                    

                    echo '<td><input type="text" id="marks_' . $row1["regno"] . '" name="marks[' . $row1["regno"] . ']" min="0" max="100" value='.$row1["$col1"].' required></td>';
                    // Add input for attendance
                    echo '<td><input type="number" id="attendance_' . $row1["regno"] . '" name="attendance[' . $row1["regno"] . ']" min="0" max="100" value='.$row1["$col2"].' required></td>';
                    echo "</tr>";
                    echo '</div>'; 
                    }  
               //}
           // } else {
           //     echo "<p style = 'color:red';>No students found in the database.</p>";
           // }
            echo "</table>";


            


        $conn->close();
        
        ?>

        <br>
        <p style = "color:red;font-size:14px;font-weight:bold;">Note : Please Double check the MARKS AND ATTENDANCE of all the Students, Because After Submission YOU CANNOT EDIT OR MODIFY OR UPDATE the Marks or Attendance. So, Double check all the Values.</p>
        <br>
        <button type="submit">Submit</button>
    </form>
        <?php
            }
            function details_display(){
                global $col1;
                global $col2;
                global $col3;
                global $col4;
                global $s;
                global $conn;
                global $clshandle;
                global $subject;
                global $servername;
                global $dbname;
                global $username;
                global $password,$totaltable,$staff;


                echo "<table><tr>
                <th>Name</th>
                <th>Regno</th>
                <th>Mark</th>
                <th>Attendance</th></tr>";
                $dis = "SELECT * FROM $s";
                $result = $conn->query($dis);
                echo "Faculty Name : ".$staff;
                echo "<br>";

                echo "Class : ".$clshandle;
                echo "<br>";
                echo "Subject : ".$subject;
                echo "<br><br>";

                

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row["name"]."</td>";
                    echo "<td>".$row["regno"]."</td>";
                    echo "<td>".$row[$col1]."</td>";
                    echo "<td>".$row[$col2]."</td>";
                    echo "</tr>";
                }
                echo "</table>";
            
            $dis1 = "SELECT totalmark,totalattendance FROM $totaltable WHERE subcode='$subject'";
            $result1 = $conn->query($dis1);
            while ($row1 = $result1->fetch_assoc()){
            echo "<br>";

            echo "Total Mark : ".$row1["totalmark"];
            echo "<br>";

            echo "Total Attendance : ".$row1["totalattendance"];
            break;
            }

            try {
                // Create a database connection
                $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch (PDOException $e) {
                echo "Connection failed: " . $e->getMessage();
                exit();
            }
            
            
            $tableName = $s; // Replace with your table name
            
            // SQL query to fetch data from the table
            $sql = "SELECT * FROM $tableName";
            $stmt = $conn->query($sql);
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // CSV file name
            $csvFileName = $s.".csv";
            
            // Open a new CSV file for writing
            $file = fopen($csvFileName, 'w');



            $abc = array(["UNIVERSITY COLLEGE OF ENGINEERING, BIT CAMPUS, ANNA UNIVERSITY,TIRUCHIRAPPALLI - 620024"]);
            foreach ($abc as $a) {
                fputcsv($file, $a);
            }

            $abc = array(["FACULTY : ".$staff]);
            foreach ($abc as $a) {
                fputcsv($file, $a);
            }

            $abc = array(["CLASS : ".$clshandle,"SUBJECT : ".$subject]);
            foreach ($abc as $a) {
                fputcsv($file, $a);
            }
            
            // Write a header row to the CSV
            $header = array_keys($data[0]);
            fputcsv($file, $header);
            
            // Write the data to the CSV
            foreach ($data as $row) {
                fputcsv($file, $row);
            }
            $conn = null;
            




            include("config.php");
            $sql3 = "SELECT totalattendance FROM $totaltable WHERE subcode = '$subject'";
            $stmt3 = $conn->query($sql3);
            $data3 = $stmt3->fetch_assoc();

            try{
                $ta = array("Total Attendance:".$data3["totalattendance"]);
                }catch(TypeError $e){
                    echo "Error : Either All Subject Marks Not Uploaded OR Incorrect Values Uploaded.";
                    exit;
                }
            
                
                // Write the data to the CSV
                    fputcsv($file, $ta);
                





            
            
            fclose($file);
            
            // Create a download link for the CSV file
            $downloadLink = '<a href="' . $csvFileName . '" download>Download Report</a>';

            echo "<br><br>";
            
            echo "Report Successfully Generated: $csvFileName<br>";
            echo "Click here to download: $downloadLink";

        $conn->close();

        }
?>
    <div id="result"></div>



    
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // On page load, check if there's a draft and populate the form
    loadDraft();
    
    // Set up auto-save every 10 seconds (adjust as needed)
    setInterval(saveDraft, 1000);
});

function saveDraft() {
    // Create an object to store the form data
    var formData = {};
    var form = document.getElementById('markForm');

    // Iterate through form elements and save their values
    for (var i = 0; i < form.elements.length; i++) {
        var element = form.elements[i];
        if (element.name) {
            formData[element.name] = element.value;
        }
    }

    // Save the form data to the server using AJAX
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'save_draft.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log('Draft saved successfully');
        }
    };
    xhr.send(JSON.stringify(formData));
}

function loadDraft() {
    // Retrieve the draft data from the server using AJAX
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'load_draft.php', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var draftData = JSON.parse(xhr.responseText);
            // Populate the form with the draft data
            var form = document.getElementById('markForm');
            for (var key in draftData) {
                var element = form.elements[key];
                if (element) {
                    element.value = draftData[key];
                }
            }
        }
    };
    xhr.send();
}
</script>

</div>
<br>
</body>



<script>
function confirmSubmission() {
  if (confirm("Please Double check the MARKS AND ATTENDANCE of all the Students, Because After Submission YOU CANNOT EDIT OR MODIFY OR UPDATE the Marks or Attendance. So, Double check all the Values.")) {
    // If the user clicks "OK" in the confirmation dialog, the form will be submitted
    return true;
  } else {
    // If the user clicks "Cancel," the form submission will be canceled
    return false;
  }
}
</script>
</html>
<?php



?>