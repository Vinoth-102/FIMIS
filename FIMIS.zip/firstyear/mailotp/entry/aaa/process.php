<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Mark and Attendance Entry</title>
    <style>
        table,tr,td,th{
            border:2px solid black;
            border-collapse:collapse;
            padding:5px;
            text-align:center;
        }
        input{
            width:100px;
        }
        .inp{
            width:50px;
            
        }
    </style>
</head>
</html>

<?php
// process.php

    // Include your database connection code here
    include("config.php");


    $marks = $_POST["marks"];
    $attendance = $_POST["attendance"];
    $cl = $_POST["cl"];
    $sb = $_POST["sb"];
    $ma = $_POST["ma"];
    $at = $_POST["at"];

    $tb = $cl.$sb;
    $t = strtolower($tb);
    $s = str_replace("-", "", $t);

    $tt = "total".$cl;
    $ttt = strtolower($tt);
    $totaltable = str_replace("-", "", $ttt);




    $col1 = strtolower($sb)."_mark";
    $col2 = strtolower($sb)."_attendance";

    $query = "SELECT * FROM $s";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
    if($row){
        echo "Marks already submitted if you want to update contact Admin.<br><br>";
        details_display();
    }
    else{
        mainfunc();
    }

    function mainfunc(){

    global $conn,$clshandle,$subject,$marks,$attendance,$s,$col1,$col2,$col3,$col4,$ma,$at,$sb,$totaltable;

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    

    // Retrieve marks data from the form
    


    // Iterate through posted data (marks and attendance)
    foreach ($marks as $regno => $mark) {
        $regno = $conn->real_escape_string($regno);
        $mark = $conn->real_escape_string($mark);
        $attendanceValue = $conn->real_escape_string($attendance[$regno]);

        // Insert data into the database
        $q = "SELECT name from studentdetails WHERE regno = '$regno'";
        $result = $conn->query($q);
        while ($row = $result->fetch_assoc()){
            $nam = $row["name"];
        }
        $sql = "INSERT INTO $s (regno, $col1, $col2,name) VALUES ('$regno', '$mark', '$attendanceValue','$nam')";

        if ($conn->query($sql) !== TRUE) {
            echo "Error: Marks and Attendance not Submitted.";
            $conn->close();
            exit;
        }
    }
    $sql1 = "INSERT INTO $totaltable (subcode,totalmark,totalattendance) VALUES ('$sb','$ma','$at')";
    $conn->query($sql1);

    $conn->close();

    echo "<center><span class='tick-symbol' style='color:green;font-size:62px'>&#10004;</span><br>
            <h2 style='color:green;font-family:Arial;font-weight:bold;'>Details Saved Successfully.</h2></center>";
}
function details_display(){
    global $col1;
    global $col2;
    global $col3;
    global $col4;
    global $s;
    global $conn;
    global $clshandle;
    global $subject;
    global $cl,$sb;
    global $servername;
    global $dbname;
    global $username;
    global $password;
    global $totaltable;

    echo "<table><tr>
    <th>Name</th>
    <th>Regno</th>
    <th>Mark</th>
    <th>Attendance</th></tr>";
    $dis = "SELECT name,regno,$col1,$col2 FROM $s";
    $result = $conn->query($dis);
    echo "Class : ".$cl;
    echo "<br>";
    echo "Subject : ".$sb;
    echo "<br><br>";

    

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["name"]."</td>";
        echo "<td>".$row["regno"]."</td>";
        echo "<td>".$row[$col1]."</td>";
        echo "<td>".$row[$col2]."</td>";
        echo "</tr>";
    }
    echo "</table>";

$dis1 = "SELECT * FROM $totaltable WHERE subcode = '$sb'";
$result1 = $conn->query($dis1);
while ($row1 = $result1->fetch_assoc()){
echo "<br>";

echo "Total Mark : ".$row1["totalmark"];
echo "<br>";

echo "Total Attendance : ".$row1["totalattendance"];
break;
}
echo "<br><br>";

try {
    // Create a database connection
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit();
}


$tableName = $s; // Replace with your table name

// SQL query to fetch data from the table
$sql = "SELECT * FROM $tableName";
$stmt = $conn->query($sql);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// CSV file name
$csvFileName = $s.".csv";

// Open a new CSV file for writing
$file = fopen($csvFileName, 'w');

// Write a header row to the CSV
$header = array_keys($data[0]);
fputcsv($file, $header);

// Write the data to the CSV
foreach ($data as $row) {
    fputcsv($file, $row);
}
$conn = null;

include("config.php");
            $sql3 = "SELECT totalattendance FROM $totaltable WHERE subcode = '$sb'";
            $stmt3 = $conn->query($sql3);
            $data3 = $stmt3->fetch_assoc();

            try{
                $ta = array("Total Attendance:".$data3["totalattendance"]);
                }catch(TypeError $e){
                    echo "<center><span class='cross-symbol' style='color:red;font-size:62px'>&#10007;</span><br>
                    <h2 style='color:red;font-family:Arial;font-weight:bold;'>Error : Either All Subject Marks Not Uploaded OR Incorrect Values Uploaded.</h2></center>";
                    exit;
                }
            
                
                // Write the data to the CSV
                
                    fputcsv($file, $ta);
                
fclose($file);

// Create a download link for the CSV file
$downloadLink = '<a href="' . $csvFileName . '" download>Download Report</a>';

echo "Report Successfully Generated: $csvFileName<br>";
echo "Click here to download: $downloadLink";

$conn->close();

}

    
?>
