<?php

include("config.php");

$class = $_POST["clshandle"];
$subcode = $_POST["sub"];
$name = $_POST["name"];
$email = $_POST["email"];


$tbname = $class.$subcode;
$t = strtolower($tbname);
$s = str_replace("-", "", $t);



try{
$q1 = "DELETE FROM faculty WHERE email='$email' AND clshandle = '$class' AND subcode='$subcode'";
//$q2 = "DROP table $s";
$res1 = $conn->query($q1);
//$res2 = $conn->query($q2);
if($res1){
    echo "<center><span class='tick-symbol' style='color:green;font-size:62px'>&#10004;</span><br>
    <h2 style='color:green;font-family:Arial;font-weight:bold;'>Successfully Deleted.</h2>";
}
else{
    echo "<center><span class='cross-symbol' style='color:red;font-size:62px'>&#10007;</span><br>
    <h2 style='color:red;font-family:Arial;font-weight:bold;'>Error : Either Staff not Available or Incorrect Data Entered.</h2>";
}
}
catch(Exception $e){
    echo "<center><span class='cross-symbol' style='color:red;font-size:62px'>&#10007;</span><br>
    <h2 style='color:red;font-family:Arial;font-weight:bold;'>Error : Either Staff not Available or Incorrect Data Entered.</h2>";
}
$conn->close();

?>