<?php
function check()
{
    $conn = mysqli_connect("localhost", "root", "", "student");
    $r = $_POST['usname'];
    $s = $_POST['passwor'];
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM studentdetails WHERE regno = $r";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    if ($row['regno'] == $r && $row['dob'] == $s) {
        mainfunc();
    } else {
        echo "<script>alert('Invalid Username or Password');</script>";
        echo "<script>window.location.href='staff_login.html';</script>";
    }
}
check();

function mainfunc()
{
    $r = $_POST['usname'];
    $s = $_POST['passwor'];
    $conn = mysqli_connect("localhost", "root", "", "student");
    $tablename='itb_final_report';
    $tablename1='totalita';
    $sql1 = mysqli_query($conn, "SELECT * FROM studentdetails WHERE regno = $r");
    $sql2 = mysqli_query($conn, "SELECT * FROM $tablename WHERE regno = $r");
    $row2 = mysqli_fetch_array($sql2); 
    $sql3 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='CY3151'");
    $row3 = mysqli_fetch_array($sql3);
    $sql4 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='PH3151'");
    $row4 = mysqli_fetch_array($sql4);
    $sql5 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='HS3152'");
    $row5 = mysqli_fetch_array($sql5);
    $sql6 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='MA3151'");
    $row6 = mysqli_fetch_array($sql6);
    $sql7 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='GE3151'");
    $row7 = mysqli_fetch_array($sql7);
    $sql8 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='GE3152'");
    $row8 = mysqli_fetch_array($sql8);
    $sql9 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='GE3171'");
    $row9 = mysqli_fetch_array($sql9);
    $sql10 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='BS3171'");
    $row10 = mysqli_fetch_array($sql10);
    $sql11 = mysqli_query($conn, "SELECT totalattendance FROM $tablename1  WHERE subcode='GE3172'");
    $row11= mysqli_fetch_array($sql11);
?>

<style>
/* Style for the table */
.data-table {
    
    width: 70%;
    border-collapse: collapse;
    margin-top: 20px;
    
}

.data-table th,
.data-table td {
    border: 1px solid #ddd;
    padding: 8px;
 
    
}

.data-table th {
    background-color: #f2f2f2;
}

.data-table tr:nth-child(even) {
    background-color: #f2f2f2;
}

.data-table tr:nth-child(odd) {
    background-color: #ffffff;
}

/* Additional styling for the table */
.ad h2 {
    font-size: 20px;
    margin-top: 20px;
}





</style>

    <form action="entry/aaa/index.php" method="post">
        <div class="ad">
            <div class="container">
            
                <table class="data-table" align="center" cellspacing="0" >
                    
                    <tr>
                        <th colspan="4">MARKSHEET</th>
                    </tr>       
                    <?php
                    while ($row = mysqli_fetch_array($sql1)) {
                    ?>
                    <tr>
                        <td colspan="4"><h2>Name</h2> <?php echo $row['name']; ?></td>
                    </tr>
                    <tr>
                        <td colspan="2"><h2>Date of Birth</h2> <?php echo $row['dob']; ?></td>
                        <td colspan="2"><h2>Register Number</h2> <?php echo $row['regno']; ?></td>
                    </tr>
                    
                    <?php
                    }
                    ?>
                    <tr>
                        <th>Sub name</th>
                        <th>Marks</th>
                        <th>attendance</th>
                        <th>Total attendance</th>
                    </tr>
                   

                        <tr>
                            <td>CY3151</td>
                            <td><?php echo $row2['cy3151_mark']; ?></td>
                            <td><?php echo $row2['cy3151_attendance']; ?></td>
                            <td><?php echo $row3['totalattendance']; ?></td>
                        </tr >
                        
                        <tr>
                            <td>PH3151</td>
                            <td><?php echo $row2['ph3151_mark']; ?></td>
                            <td><?php echo $row2['ph3151_attendance']; ?></td>
                            <td><?php  echo $row4['totalattendance']; ?></td>
                            
                        </tr>

                        <tr>
                        
                        <td>HS3152</td>
                        <td><?php echo $row2['hs3152_mark']; ?></td>
                        <td><?php echo $row2['hs3152_attendance']; ?></td>
                        <td><?php  echo $row5['totalattendance']; ?></td>
                        
                        </tr>

                        <tr>
                        <td>MA3151</td>
                        <td><?php echo $row2['ma3151_mark']; ?></td>
                        <td><?php echo $row2['ma3151_attendance']; ?></td>
                        <td><?php  echo $row6['totalattendance']; ?></td>
                        </tr>

                        <tr>
                        <td>GE3151</td>
                        <td><?php echo $row2['ge3151_mark']; ?></td>
                        <td><?php echo $row2['ge3151_attendance']; ?></td>
                        <td><?php  echo $row7['totalattendance']; ?></td>
                        
                        </tr>

                        <tr>
                        <td>GE3152</td>
                        <td><?php echo $row2['ge3152_mark']; ?></td>
                        <td><?php echo $row2['ge3152_attendance']; ?></td>
                        <td><?php  echo $row8['totalattendance']; ?></td>
                        
                        </tr>

                        <tr>
                        <td>GE3171</td>
                        <td><?php echo $row2['ge3171_mark']; ?></td>
                        <td><?php echo $row2['ge3171_attendance']; ?></td>
                        <td><?php  echo $row9['totalattendance']; ?></td>
                        
                        </tr>

                        <tr>
                        <td>BS3171</td>
                        <td><?php echo $row2['bs3171_mark']; ?></td>
                        <td><?php echo $row2['bs3171_attendance']; ?></td>
                        <td><?php  echo $row10['totalattendance']; ?></td>
                        
                        </tr>

                        <tr>
                        <td>GE3172</td>
                        <td><?php echo $row2['ge3172_mark']; ?></td>
                        <td><?php echo $row2['ge3172_attendance']; ?></td>
                        <td><?php echo $row11['totalattendance']; ?></td>
                        
                        </tr>

                        <tr>
                            <td>Total</td>
                            <td><?php echo $row2['cy3151_mark']+$row2['ph3151_mark']+$row2['hs3152_mark']+$row2['ma3151_mark']+$row2['ge3151_mark']+$row2['ge3152_mark']+$row2['ge3171_mark']+$row2['bs3171_mark']+$row2['ge3172_mark'];?></td>
                            <td><?php echo $row2['cy3151_attendance']+$row2['ph3151_attendance']+$row2['hs3152_attendance']+$row2['ma3151_attendance']+$row2['ge3151_attendance']+$row2['ge3152_attendance']+$row2['ge3171_attendance']+$row2['bs3171_attendance']+$row2['ge3172_attendance'];?></td>                   
                            <td><?php echo $row3['totalattendance']+$row4['totalattendance']+$row5['totalattendance']+$row6['totalattendance']+$row7['totalattendance']+$row8['totalattendance']+$row9['totalattendance']+$row10['totalattendance']+$row11['totalattendance'];?></td>
                        </tr>
                    
                    
                </table>
            </div>
        </div>
    </form>
<?php
}
?>
