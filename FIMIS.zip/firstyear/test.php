<?php
include('smtp/PHPMailerAutoload.php');
$receiver = $_POST["usname"];
$num=6;
$n=generate_otp($num);
echo smtp_mailer($receiver,'First year Portal', 'Access OTP is:'.$n);
function smtp_mailer($to,$subject, $msg){
	$mail = new PHPMailer(); 
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'tls'; 
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 587; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	//$mail->SMTPDebug = 2; 
	$mail->Username = "vinothkumar0743@gmail.com";
	$mail->Password = "iypv cotv owou ieav";
	$mail->SetFrom("vinothkumar0743@gmail.com");
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){
		echo $mail->ErrorInfo;
	}
}

	function generate_otp($n)
	{
   		$gen = "1357902468";
   		$res = "";
   		for ($i = 1; $i <= $n; $i++)
		{
   			$res .= substr($gen, (rand()%(strlen($gen))), 1);
		}
   		return $res;
	}
?>
<html>
<body>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        label {
            display: block;
            margin-bottom: 6px;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            padding: 8px 16px;
            background-color: #4caf50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>

<div>

    <h2 style="text-align: center;">Enter OTP</h2>

    <form action="check.php" method="post">
        <label for="otp">OTP:</label>
        <input type="text" id="otp" name="otp" required>
        <?php echo "<input type='text' id='otp' name='n' value=".$n." style='display:none;'>";?>
        <?php echo "<input type='text' id='usname' name='usname' value=".$receiver." style='display:none;'>";?>




        <input type="submit" value="Submit OTP">
    </form>
</div>

</body>
</html>



