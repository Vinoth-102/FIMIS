<?php
error_reporting(0);

include("config.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to get all table names
$sql = "SHOW TABLES";
$result = $conn->query($sql);

$tables = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_row()) {
        $tables[] = $row[0];
    }
} else {
    echo "No tables found in the database.";
}

// Close the database connection


// Print the array of table names




$len = count($tables);
for($i=0;$i<$len;$i++){
    $pos = strpos($tables[$i],'total');
    if($tables[$i]=="login" || $tables[$i]=="studentdetails")
    {
        echo "<br>";
    }

    
    elseif ($tables[$i]=="faculty" || $tables[$i]=="totalautomobile" || $tables[$i]=="totalbiotech"
     || $tables[$i]=="totalcivila" || $tables[$i]=="totalcivilb" || $tables[$i]=="totalcsea" || $tables[$i]=="totalcseb" 
     || $tables[$i]=="totalecea" || $tables[$i]=="totaleceb" || $tables[$i]=="totaleeea" || $tables[$i]=="totaleeeb" 
     || $tables[$i]=="totalmechanicala" || $tables[$i]=="totalmechanicalb" || $tables[$i]=="totalpetro" || $tables[$i]=="totalpharma"
     || $tables[$i]=="totalita" || $tables[$i]=="totalitb" || $tables[$i]=="totalcivilmechanicaltm")
     {
        $sql2 = "TRUNCATE TABLE $tables[$i]";
        $res2 = mysqli_query($conn,$sql2);
    }

    else{
        $sql3 = "DROP TABLE $tables[$i]";
        $res3 = mysqli_query($conn,$sql3);
    }
    
}
if($res2 & $res3){
    echo "<center><h2>Reset Success</h2></center>";
    
}
else{
    echo "<center><h2>Website is Already Reset.</h2></center>";

}
$conn->close();
?>

