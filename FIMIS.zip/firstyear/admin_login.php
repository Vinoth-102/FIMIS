<?php
  function check()
  {
      include("config.php");
      $r=$_POST['usname'];
      $s=$_POST['passwor'];
	    
	    if ($conn->connect_error) 
      {
		    die("Connection failed: " . $conn->connect_error);
	    }

	    $sql = "SELECT * FROM login WHERE username = '$r'";
	    $result = $conn->query($sql);
      $row = $result->fetch_assoc();
      if($row['username']==$r and $row['password']==$s)
      {
        echo "<script>window.location.href='admin.html';</script>";
      }
      else
      {
        echo "<script>alert('Invalid Username or Password');</script>";
        echo "<script>window.location.href='admin_login.html';</script>";
      }
      $conn->close();
  }
  check();
?>